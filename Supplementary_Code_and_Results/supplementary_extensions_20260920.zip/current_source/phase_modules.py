"""Exploratory P2-to-P3 phase detail injection; prior space-to-depth is not novel."""
import torch
from torch import nn
from torch.nn import functional as F
from ultralytics.nn.modules import Conv
from ultralytics.models.yolo.detect import DetectionTrainer


class PhaseInjection(nn.Module):
    def __init__(self, shallow_channels, channels, mode):
        super().__init__()
        self.mode = mode
        hidden = max(8, channels // 4)
        self.compress = Conv(shallow_channels, hidden, 1)
        self.refine = nn.Sequential(Conv(hidden * 4, hidden * 4, 3, g=hidden * 4),
                                    Conv(hidden * 4, channels, 1, act=False))
        self.gamma = nn.Parameter(torch.zeros(1, channels, 1, 1))
        if mode in ('phase', 'phase_uncentered', 'phase_content', 'phase_self'):
            self.condition = nn.Conv2d(channels, hidden * 4, 1)
            nn.init.zeros_(self.condition.weight)
            nn.init.zeros_(self.condition.bias)

    def packed(self, shallow, semantic):
        packed = F.pixel_unshuffle(self.compress(shallow), 2)
        b, c, h, w = packed.shape
        assert (h, w) == semantic.shape[-2:], 'P2/P3 spatial sizes differ'
        phases = packed.reshape(b, c // 4, 4, h, w)
        mean = phases.mean(2, keepdim=True)
        if self.mode == 'phase_avg':
            # Same trainable branch capacity, but remove intra-cell phase differences.
            phases = mean.expand_as(phases)
        elif self.mode in ('phase', 'phase_uncentered', 'phase_content', 'phase_self'):
            # Preserve the phase mean. Modulate only centered intra-cell detail.
            condition = F.avg_pool2d(shallow, 2) if self.mode == 'phase_self' else semantic
            weights = 1 + .5 * self.condition(condition).reshape_as(phases).tanh()
            detail = (phases - mean) * weights
            if self.mode == 'phase_content':
                phases = phases * weights
            elif self.mode == 'phase_uncentered':
                phases = mean + detail
            else:
                phases = mean + detail - detail.mean(2, keepdim=True)
        elif self.mode != 'phase_uniform':
            raise ValueError(self.mode)
        return phases.reshape(b, c, h, w)

    def forward(self, semantic, shallow):
        return semantic + self.gamma * self.refine(self.packed(shallow, semantic))


class PhaseBlock(nn.Module):
    def __init__(self, original, addition):
        super().__init__()
        self.original, self.addition = original, addition
        self.i, self.f, self.type = original.i, [-1, 2], 'PhaseBlock'
        self.np = sum(p.numel() for p in self.parameters())

    def forward(self, inputs):
        return self.addition(self.original(inputs[0]), inputs[1])


def attach_phase(model, variant):
    original = model.model[16]
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(1016)
        addition = PhaseInjection(model.model[2].cv2.conv.out_channels,
                                  original.cv2.conv.out_channels, variant)
    model.model[16] = PhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    return model


class PhaseTrainer(DetectionTrainer):
    variant = 'phase'

    def get_model(self, cfg=None, weights=None, verbose=True):
        if weights is not None and isinstance(weights.model[16], PhaseBlock):
            assert weights.refinement_variant == self.variant
            model = attach_phase(super().get_model(cfg, None, verbose), self.variant)
            model.load(weights)
            return model
        return attach_phase(super().get_model(cfg, weights, verbose), self.variant)


class PhaseUniformTrainer(PhaseTrainer):
    variant = 'phase_uniform'


class PhaseAverageTrainer(PhaseTrainer):
    variant = 'phase_avg'


PHASE_TRAINERS = {'phase': PhaseTrainer, 'phase_uniform': PhaseUniformTrainer,
                  'phase_avg': PhaseAverageTrainer}


class PhaseUncenteredTrainer(PhaseTrainer):
    variant = 'phase_uncentered'


class PhaseContentTrainer(PhaseTrainer):
    variant = 'phase_content'


class PhaseSelfTrainer(PhaseTrainer):
    variant = 'phase_self'


PHASE_TRAINERS.update(phase_uncentered=PhaseUncenteredTrainer,
                      phase_content=PhaseContentTrainer, phase_self=PhaseSelfTrainer)
