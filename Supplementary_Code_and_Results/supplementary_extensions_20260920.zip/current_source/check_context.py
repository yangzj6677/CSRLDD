"""Check context-condition initialization, gradients, CUDA and serialization."""
import io
import json
from pathlib import Path

import torch
from ultralytics import YOLO
from phase_modules import attach_phase
from context_modules import attach_context_phase


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/context_experiment"


def main():
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    report = {}
    for variant in ("phase_p4ctx", "phase_se"):
        phase_model = attach_phase(YOLO(str(ROOT / "models/yolo11n.pt")).model, "phase")
        candidate = attach_context_phase(
            YOLO(str(ROOT / "models/yolo11n.pt")).model, variant
        )
        phase_model = phase_model.to(device).eval()
        candidate = candidate.to(device).eval()
        input_tensor = torch.rand(1, 3, 320, 320, device=device)
        with torch.no_grad():
            phase_output = phase_model(input_tensor)[0]
            candidate_output = candidate(input_tensor)[0]
        identity_error = float((phase_output - candidate_output).abs().max())
        if variant == "phase_p4ctx":
            candidate.model[16].addition.context.conv.weight.data.normal_(0, 0.02)
            if candidate.model[16].addition.context.conv.bias is not None:
                candidate.model[16].addition.context.conv.bias.data.zero_()
        else:
            candidate.model[16].addition.se[-1].conv.weight.data.normal_(0, 0.02)
            if candidate.model[16].addition.se[-1].conv.bias is not None:
                candidate.model[16].addition.se[-1].conv.bias.data.zero_()
        candidate.model[16].addition.condition.weight.data.normal_(0, 0.02)
        if candidate.model[16].addition.condition.bias is not None:
            candidate.model[16].addition.condition.bias.data.zero_()
        candidate.model[16].addition.gamma.data.fill_(0.1)
        changed_output = candidate(input_tensor)[0]
        changed = not torch.equal(phase_output, changed_output)
        loss = changed_output.square().mean()
        loss.backward()
        gradients_finite = all(
            parameter.grad is None or torch.isfinite(parameter.grad).all()
            for parameter in candidate.parameters()
        )
        stream = io.BytesIO()
        torch.save(candidate, stream)
        stream.seek(0)
        loaded = torch.load(stream, weights_only=False).to(device).eval()
        with torch.no_grad():
            restored_output = loaded(input_tensor)[0]
        serialization_error = float((changed_output - restored_output).abs().max())
        report[variant] = {
            "identity_max_abs_error": identity_error,
            "changed_after_nonzero_context": changed,
            "finite_gradients": gradients_finite,
            "serialization_max_abs_error": serialization_error,
            "parameters": sum(
                parameter.numel() for parameter in candidate.parameters()
            ),
            "context_parameters": sum(
                parameter.numel()
                for parameter in candidate.model[16].addition.parameters()
            ),
            "device": device,
        }
        print(json.dumps(report[variant], indent=2), flush=True)
        assert identity_error < 1e-6
        assert changed and gradients_finite and serialization_error < 1e-6
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "prototype_checks.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
