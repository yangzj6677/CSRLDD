"""Serial, locked queue. Retry only transient JSON replace, never failed training."""
import json
import os
import hashlib
import subprocess
import sys
import time
import msvcrt
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/frontier'

def main():
    lock=(OUT/'queue.lock').open('a+b')
    lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
    msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    plan=json.loads((OUT/'plan.json').read_text())
    for path,digest in plan['source_hashes'].items():
        assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
    state=dict(status='starting',total=len(plan['jobs']),completed=[],active=None,failures=[],pid=os.getpid())
    def save():
        state['updated_utc']=datetime.now(timezone.utc).isoformat()
        tmp=OUT/f'state.{os.getpid()}.tmp'
        tmp.write_text(json.dumps(state,indent=2),encoding='utf-8')
        for attempt in range(10):
            try:
                tmp.replace(OUT/'state.json');return
            except PermissionError:
                if attempt==9: raise
                time.sleep(.2*(attempt+1))
    try:
        for job in plan['jobs']:
            target=ROOT/job['run']/'val_summary.json'
            if target.exists():
                assert json.loads(target.read_text())['job']==job
                state['completed'].append(job['id']);continue
            state.update(status='running',active=job['id']);save()
            with (OUT/(job['id']+'.log')).open('a',encoding='utf-8') as log:
                process=subprocess.Popen([sys.executable,str(ROOT/'run_frontier_job.py'),'--job',job['id']],
                                         cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
                state['child_pid']=process.pid;save()
                try:
                    code=process.wait(timeout=12*3600)
                except subprocess.TimeoutExpired:
                    state['failures'].append(dict(job=job['id'],reason='12h timeout; child left running for inspection'))
                    state.update(status='timeout');save();return 1
            if code or not target.exists():
                state['failures'].append(dict(job=job['id'],exit_code=code))
                state.update(status='failed');save();return 1
            assert json.loads(target.read_text())['job']==job
            state['completed'].append(job['id']);state.update(active=None,child_pid=None);save()
        state.update(status='complete_validation_screen',active=None);save()
    except Exception as exc:
        state['failures'].append(dict(reason=repr(exc)))
        state.update(status='failed');save();raise
    return 0

if __name__=='__main__':
    raise SystemExit(main())
