"""Freeze post-hoc test evaluation for the completed phase_self screen."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/self_condition"


def main():
    assert not (OUT / "test_plan.json").exists(), "Do not overwrite frozen test plan"
    validation_plan = json.loads(
        (OUT / "plan.json").read_text(encoding="utf-8")
    )
    jobs = []
    for job in validation_plan["jobs"]:
        test_control = job["phase_control"]
        if job["dataset"] == "neu" and job["seed"] == 42:
            test_control = "runs/publication/phase_s42_120e"
        assert (ROOT / test_control / "test_summary.json").exists(), test_control
        assert (ROOT / job["run"] / "val_summary.json").exists()
        assert (ROOT / job["run"] / "weights/best.pt").exists()
        jobs.append({**job, "test_control": test_control})
    sources = {
        "prepare_self_condition_test.py",
        "run_self_condition_tests.py",
        "report_self_condition_test.py",
        "reports/self_condition/plan.json",
        "phase_modules.py",
        "data/neu_yolo/data.yaml",
        "data/deeppcb_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/manifest.json",
    }
    for job in jobs:
        sources.add(job["run"] + "/weights/best.pt")
        sources.add(job["test_control"] + "/test_summary.json")
    test_plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "posthoc_phase_self_test_evaluation",
        "jobs": jobs,
        "selection": "all six validation-frozen checkpoints; no model selection on test",
        "disclosure": {
            "known_test_reuse": True,
            "validation_gate_passed_before_test": True,
            "no_training_or_hyperparameter_change_after_test": True,
        },
        "primary_comparison": "phase - phase_self",
        "primary_endpoint": "test mAP50-95",
        "gate": {
            "both_datasets_min_pp": 0.0,
            "at_least_one_dataset_min_pp": 0.5,
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sorted(sources)
        },
    }
    (OUT / "test_plan.json").write_text(
        json.dumps(test_plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(jobs)} known-test evaluations")


if __name__ == "__main__":
    main()
