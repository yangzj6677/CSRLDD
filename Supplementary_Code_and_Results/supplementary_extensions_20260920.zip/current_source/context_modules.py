"""P4-context calibration for the existing P3-conditioned phase branch."""
import torch
from torch import nn
from torch.nn import functional as F
from ultralytics.nn.modules import Conv
from ultralytics.models.yolo.detect import DetectionTrainer

from phase_modules import PhaseInjection


class ContextPhaseInjection(PhaseInjection):
    """Modulate the P3 condition with a zero-initialized context correction."""

    def __init__(self, shallow_channels, channels, context_channels, variant):
        super().__init__(shallow_channels, channels, "phase")
        if variant not in ("phase_p4ctx", "phase_se"):
            raise ValueError(variant)
        self.variant = variant
        if variant == "phase_p4ctx":
            self.context = Conv(context_channels, channels, 1, act=False)
            nn.init.zeros_(self.context.conv.weight)
            if self.context.conv.bias is not None:
                nn.init.zeros_(self.context.conv.bias)
        else:
            hidden = channels * 2
            self.se = nn.Sequential(
                Conv(channels, hidden, 1),
                Conv(hidden, channels, 1, act=False),
            )
            nn.init.zeros_(self.se[-1].conv.weight)
            if self.se[-1].conv.bias is not None:
                nn.init.zeros_(self.se[-1].conv.bias)

    def adjusted_condition(self, semantic, context):
        if self.variant == "phase_p4ctx":
            if context.shape[-2:] != semantic.shape[-2:]:
                context = F.interpolate(
                    context, size=semantic.shape[-2:], mode="nearest"
                )
            correction = self.context(context).tanh()
        else:
            pooled = F.adaptive_avg_pool2d(semantic, 1) + F.adaptive_max_pool2d(
                semantic, 1
            )
            correction = self.se(pooled).tanh()
        return semantic * (1.0 + 0.5 * correction)

    def forward(self, semantic, shallow, context):
        condition = self.adjusted_condition(semantic, context)
        return semantic + self.gamma * self.refine(
            super().packed(shallow, condition)
        )


class ContextPhaseBlock(nn.Module):
    """Keep the original P3 block and route P2 plus deep context into it."""

    def __init__(self, original, addition):
        super().__init__()
        self.original = original
        self.addition = addition
        self.i = original.i
        self.f = [-1, 2, 8]
        self.type = "ContextPhaseBlock"
        self.np = sum(parameter.numel() for parameter in self.parameters())

    def forward(self, inputs):
        return self.addition(
            self.original(inputs[0]),
            inputs[1],
            inputs[2],
        )


def attach_context_phase(model, variant, init_seed=1016):
    original = model.model[16]
    assert not isinstance(original, ContextPhaseBlock)
    context_channels = model.model[8].cv2.conv.out_channels
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        addition = ContextPhaseInjection(
            model.model[2].cv2.conv.out_channels,
            original.cv2.conv.out_channels,
            context_channels,
            variant,
        )
    model.model[16] = ContextPhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2, 8]))
    model.refinement_variant = variant
    model.branch_init_seed = init_seed
    return model


class ContextPhaseTrainer(DetectionTrainer):
    variant = "phase_p4ctx"
    init_seed = 1016

    def get_model(self, cfg=None, weights=None, verbose=True):
        wrapped = weights is not None and isinstance(
            weights.model[16], ContextPhaseBlock
        )
        if wrapped:
            assert weights.refinement_variant == self.variant
            assert weights.branch_init_seed == self.init_seed
        model = attach_context_phase(
            super().get_model(
                cfg, None if wrapped else weights, verbose
            ),
            self.variant,
            self.init_seed,
        )
        if wrapped:
            model.load(weights)
        return model
