"""Exploratory task-specific shallow detail injection; validated for YOLO11n only."""
import torch
from ultralytics.nn.modules.head import Detect
from ultralytics.models.yolo.detect import DetectionTrainer
from phase_modules import PhaseInjection


class DetailDetect(Detect):
    def forward_head(self, x, box_head=None, cls_head=None):
        if box_head is None or cls_head is None:
            return {}
        features, shallow = x[:self.nl], x[self.nl]
        refined = self.addition(features[0], shallow)
        regression = [refined, *features[1:]]
        classification = regression if self.detail_variant == 'phase_head' else features
        bs = features[0].shape[0]
        boxes = torch.cat([box_head[i](regression[i]).view(bs, 4*self.reg_max, -1)
                           for i in range(self.nl)], dim=-1)
        scores = torch.cat([cls_head[i](classification[i]).view(bs, self.nc, -1)
                            for i in range(self.nl)], dim=-1)
        return {'boxes': boxes, 'scores': scores, 'feats': features}


def attach_head_detail(model, variant):
    assert variant in ('phase_box', 'phase_head')
    head = model.model[-1]
    assert isinstance(head, Detect) and not head.end2end and head.nl == 3
    assert list(head.f) == [16, 19, 22], 'This adapter is validated only for the YOLO11n head routing'
    # Preserve all pretrained head tensors and framework metadata.
    head.__class__ = DetailDetect
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(1016)
        head.addition = PhaseInjection(model.model[2].cv2.conv.out_channels,
                                       model.model[16].cv2.conv.out_channels, 'phase')
    head.detail_variant = variant
    head.f = [*head.f, 2]
    head.np = sum(p.numel() for p in head.parameters())
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    return model


class HeadDetailTrainer(DetectionTrainer):
    variant = 'phase_box'

    def get_model(self, cfg=None, weights=None, verbose=True):
        if weights is not None and isinstance(weights.model[-1], DetailDetect):
            assert weights.refinement_variant == self.variant
            model = attach_head_detail(super().get_model(cfg, None, verbose), self.variant)
            model.load(weights)
            return model
        return attach_head_detail(super().get_model(cfg, weights, verbose), self.variant)


class BothHeadDetailTrainer(HeadDetailTrainer):
    variant = 'phase_head'


HEAD_TRAINERS = {'phase_box': HeadDetailTrainer, 'phase_head': BothHeadDetailTrainer}
