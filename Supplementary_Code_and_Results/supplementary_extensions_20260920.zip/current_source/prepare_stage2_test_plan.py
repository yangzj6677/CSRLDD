"""Freeze all-or-none post-hoc test reuse before reading any stage-two test outputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'
target=OUT/'test_plan.json'
assert not target.exists(), 'Stage-two test plan is immutable once created.'
plan=json.loads((OUT/'plan.json').read_text())
assert len(plan['jobs'])==39
sources=('evaluate_stage2_tests.py','run_stage2_test_job.py')
source_hashes={source:hashlib.sha256((ROOT/source).read_bytes()).hexdigest() for source in sources}
for source in sources: shutil.copy2(ROOT/source,OUT/'source_snapshot'/source)
record={'created_utc':datetime.now(timezone.utc).isoformat(),
        'training_plan_sha256':hashlib.sha256((OUT/'plan.json').read_bytes()).hexdigest(),
        'source_hashes':source_hashes,'jobs':[j['id'] for j in plan['jobs']],
        'gate':'Run only after all 39 validation summaries exist and no training failure is recorded.',
        'selection':'Evaluate the saved validation-selected EMA best checkpoint for every planned job; no winner filtering.',
        'endpoint':'Pooled test mAP50-95 primary; mAP50 and per-class AP auxiliary.',
        'interpretation':'Secondary reuse of already known benchmark tests after stage-one and mechanism design; not independent confirmation.',
        'analysis':['All individual results and mean/sample-SD by pre-defined family/model.',
                    'Same-seed conditioned-minus-control contrasts.',
                    'For resolution, paired difference-in-differences: (phase-uniform)640 minus (phase-uniform)320.',
                    'For initialization, compare alternative initialization with fixed 1016 and report branch contrast under both.'],
        'stop_rule':'All 39 jobs or documented technical failure; do not revise architectures or report only favorable tests.'}
target.write_text(json.dumps(record,indent=2))
print('Frozen stage-two all-model test plan; no test inference performed.')
