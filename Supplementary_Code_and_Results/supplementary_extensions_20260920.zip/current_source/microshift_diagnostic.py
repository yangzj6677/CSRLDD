"""Run the frozen validation-only micro-shift prediction diagnostic."""
import json
from pathlib import Path

import cv2
import numpy as np
import torch
from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/microshift"


def load_plan():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    for path, expected in plan["source_hashes"].items():
        actual = __import__("hashlib").sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == expected, path
    return plan


def load_images(dataset):
    image_dir = ROOT / "data" / f"{dataset}_yolo/images/val"
    paths = sorted(
        path
        for path in image_dir.iterdir()
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}
    )
    images = []
    for path in paths:
        image = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if image is None:
            raise RuntimeError(f"Could not read {path}")
        images.append(image)
    return paths, images


def predict_boxes(model, images, batch):
    rows = []
    for start in range(0, len(images), batch):
        results = model.predict(
            list(images[start : start + batch]),
            imgsz=320,
            conf=0.25,
            iou=0.7,
            max_det=300,
            device=0,
            workers=0,
            batch=batch,
            verbose=False,
        )
        for result in results:
            boxes = result.boxes
            if boxes is None or len(boxes) == 0:
                rows.append(np.empty((0, 6), dtype=np.float32))
                continue
            rows.append(
                np.column_stack(
                    [
                        boxes.xyxy.detach().cpu().numpy(),
                        boxes.conf.detach().cpu().numpy(),
                        boxes.cls.detach().cpu().numpy(),
                    ]
                ).astype(np.float32)
            )
    return rows


def translate_boxes(boxes, dx, dy):
    if len(boxes) == 0:
        return boxes.copy()
    translated = boxes.copy()
    translated[:, [0, 2]] -= dx
    translated[:, [1, 3]] -= dy
    return translated


def iou_matrix(left, right):
    if len(left) == 0 or len(right) == 0:
        return np.empty((len(left), len(right)), dtype=np.float32)
    lt = np.maximum(left[:, None, :2], right[None, :, :2])
    rb = np.minimum(left[:, None, 2:4], right[None, :, 2:4])
    wh = np.clip(rb - lt, 0, None)
    intersection = wh[..., 0] * wh[..., 1]
    left_area = np.clip(left[:, 2] - left[:, 0], 0, None) * np.clip(
        left[:, 3] - left[:, 1], 0, None
    )
    right_area = np.clip(right[:, 2] - right[:, 0], 0, None) * np.clip(
        right[:, 3] - right[:, 1], 0, None
    )
    union = left_area[:, None] + right_area[None, :] - intersection
    return intersection / np.clip(union, 1e-9, None)


def match_metrics(reference, candidate, threshold):
    ious = iou_matrix(reference, candidate)
    pairs = []
    for left_index, right_index in np.argwhere(ious >= threshold):
        if int(reference[left_index, 5]) == int(candidate[right_index, 5]):
            pairs.append((float(ious[left_index, right_index]), left_index, right_index))
    pairs.sort(reverse=True)
    used_left = set()
    used_right = set()
    matched = []
    for iou, left_index, right_index in pairs:
        if left_index in used_left or right_index in used_right:
            continue
        used_left.add(left_index)
        used_right.add(right_index)
        matched.append((iou, left_index, right_index))
    count = len(reference) + len(candidate)
    f1 = 2.0 * len(matched) / count if count else 1.0
    mean_iou = float(np.mean([item[0] for item in matched])) if matched else 0.0
    if matched:
        coordinate_error = float(
            np.mean(
                np.abs(
                    reference[[item[1] for item in matched], :4]
                    - candidate[[item[2] for item in matched], :4]
                )
            )
        )
        score_error = float(
            np.mean(
                np.abs(
                    reference[[item[1] for item in matched], 4]
                    - candidate[[item[2] for item in matched], 4]
                )
            )
        )
    else:
        coordinate_error = None
        score_error = None
    return {
        "f1": f1,
        "matched": len(matched),
        "reference_count": int(len(reference)),
        "candidate_count": int(len(candidate)),
        "mean_matched_iou": mean_iou,
        "matched_coordinate_mae_px": coordinate_error,
        "matched_score_mae": score_error,
    }


def shift_image(image, dx, dy):
    height, width = image.shape[:2]
    matrix = np.float32([[1, 0, dx], [0, 1, dy]])
    return cv2.warpAffine(
        image,
        matrix,
        (width, height),
        flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_REPLICATE,
    )


def main():
    torch.set_num_threads(4)
    plan = load_plan()
    batch = plan["protocol"]["batch"]
    records = []
    determinism = {}

    for dataset, model_specs in plan["models"].items():
        paths, images = load_images(dataset)
        for model_name, checkpoint in model_specs.items():
            model = YOLO(str(ROOT / checkpoint))
            model.model.cuda().float().eval()
            original = predict_boxes(model, images, batch)
            repeated = predict_boxes(model, images, batch)
            determinism[f"{dataset}/{model_name}"] = {
                "images": len(paths),
                "exact_box_arrays": sum(
                    np.array_equal(left, right)
                    for left, right in zip(original, repeated)
                ),
            }
            for dx, dy in plan["shifts_pixels"]:
                shifted_images = [shift_image(image, dx, dy) for image in images]
                shifted = predict_boxes(model, shifted_images, batch)
                shifted = [
                    translate_boxes(boxes, dx, dy) for boxes in shifted
                ]
                for path, reference, candidate in zip(paths, original, shifted):
                    metric_50 = match_metrics(reference, candidate, 0.50)
                    metric_75 = match_metrics(reference, candidate, 0.75)
                    records.append(
                        {
                            "dataset": dataset,
                            "model": model_name,
                            "dx": dx,
                            "dy": dy,
                            "image": str(path.relative_to(ROOT)),
                            "f1_50": metric_50["f1"],
                            "f1_75": metric_75["f1"],
                            "iou_50": metric_50["mean_matched_iou"],
                            "iou_75": metric_75["mean_matched_iou"],
                            "coordinate_mae_50": metric_50[
                                "matched_coordinate_mae_px"
                            ],
                            "score_mae_50": metric_50["matched_score_mae"],
                            "reference_count": metric_50["reference_count"],
                            "candidate_count": metric_50["candidate_count"],
                        }
                    )
            print(f"completed {dataset}/{model_name}", flush=True)

    result = {
        "plan_sha256": __import__("hashlib").sha256(
            (OUT / "plan.json").read_bytes()
        ).hexdigest(),
        "determinism": determinism,
        "records": records,
    }
    (OUT / "raw_results.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(f"wrote {len(records)} image-shift records")


if __name__ == "__main__":
    main()
