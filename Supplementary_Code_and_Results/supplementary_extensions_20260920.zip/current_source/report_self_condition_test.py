"""Report the frozen known-test comparison of phase and phase_self."""
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/self_condition"


def main():
    plan = json.loads((OUT / "test_plan.json").read_text(encoding="utf-8"))
    records = []
    for job in plan["jobs"]:
        candidate = json.loads(
            (ROOT / job["run"] / "posthoc_test_summary.json").read_text(
                encoding="utf-8"
            )
        )
        control = json.loads(
            (ROOT / job["test_control"] / "test_summary.json").read_text(
                encoding="utf-8"
            )
        )
        candidate_ap = 100.0 * candidate["metrics"]["metrics/mAP50-95(B)"]
        control_ap = 100.0 * control["metrics"]["metrics/mAP50-95(B)"]
        records.append(
            {
                "job": job,
                "phase_map5095": control_ap,
                "phase_self_map5095": candidate_ap,
                "phase_minus_self_pp": control_ap - candidate_ap,
            }
        )
    summary = {}
    for dataset in sorted({record["job"]["dataset"] for record in records}):
        subset = [
            record for record in records if record["job"]["dataset"] == dataset
        ]
        values = [record["phase_minus_self_pp"] for record in subset]
        summary[dataset] = {
            "per_seed_pp": {
                str(record["job"]["seed"]): record["phase_minus_self_pp"]
                for record in subset
            },
            "mean_pp": statistics.fmean(values),
            "sample_sd_pp": statistics.stdev(values),
            "positive_seeds": sum(value > 0.0 for value in values),
        }
    gate_config = plan["gate"]
    passed = (
        all(
            result["mean_pp"] >= gate_config["both_datasets_min_pp"]
            for result in summary.values()
        )
        and any(
            result["mean_pp"] >= gate_config["at_least_one_dataset_min_pp"]
            for result in summary.values()
        )
    )
    result = {
        "records": records,
        "summary": summary,
        "gate": {"passed": passed, **gate_config},
        "disclosure": plan["disclosure"],
    }
    (OUT / "test_results.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    lines = [
        "# P2自条件机制消融：固定测试集",
        "",
        "对 `phase - phase_self` 进行逐训练种子配对比较。"
        "测试集在验证门槛通过后才冻结、评估，属于已知测试集复用，不是独立确认。",
        "",
        "|数据集|逐种子差值(pp)|均值±样本SD(pp)|正向种子|",
        "|---|---|---:|---:|",
    ]
    for dataset, values in sorted(summary.items()):
        per_seed = ", ".join(
            f"{value:+.3f}" for value in values["per_seed_pp"].values()
        )
        lines.append(
            f"|{dataset}|{per_seed}|"
            f"{values['mean_pp']:+.3f} ± {values['sample_sd_pp']:.3f}|"
            f"{values['positive_seeds']}/3|"
        )
    lines.extend(
        [
            "",
            f"事后门槛结果：{'支持' if passed else '不支持'}。",
            "",
            "该结果不能消除测试集复用，也不替代独立采集数据或独立划分验证。",
        ]
    )
    (OUT / "测试结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(result["gate"], indent=2))


if __name__ == "__main__":
    main()
