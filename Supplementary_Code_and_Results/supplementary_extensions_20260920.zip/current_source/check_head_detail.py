"""Identity, serialization, branch isolation and backward checks on CPU."""
import copy
import io
import json
from pathlib import Path
import torch
from ultralytics import YOLO
from head_detail_modules import attach_head_detail

torch.set_num_threads(4)
torch.manual_seed(42)
base = YOLO('models/yolo11n.pt').model.eval()
x = torch.rand(2, 3, 320, 320)
records = {}
with torch.no_grad():
    reference, raw = base(x)
for variant in ('phase_box', 'phase_head'):
    model = attach_head_detail(copy.deepcopy(base), variant).eval()
    with torch.no_grad():
        assert torch.equal(reference, model(x)[0])
    module = model.model[-1].addition
    module.gamma.data.fill_(.1)
    with torch.no_grad():
        changed = model(x)[1]
        assert not torch.equal(raw['boxes'], changed['boxes'])
        same_scores = torch.equal(raw['scores'], changed['scores'])
        assert same_scores == (variant == 'phase_box')
    buffer = io.BytesIO()
    torch.save(model, buffer)
    buffer.seek(0)
    restored = torch.load(buffer, weights_only=False)
    with torch.no_grad():
        assert torch.equal(model(x)[0], restored(x)[0])
        fused = copy.deepcopy(model).fuse(verbose=False)
        assert torch.allclose(model(x)[0], fused(x)[0], atol=1e-3, rtol=1e-4)
    model.train()
    output = model(x)
    (output['boxes'].square().mean() + output['scores'].square().mean()).backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum() > 0
               for p in module.parameters())
    records[variant] = {'identity': True, 'serialization': True, 'gradients': True, 'fused_equivalence': True,
                        'classification_unchanged_with_nonzero_injection': same_scores,
                        'added_parameters': sum(p.numel() for p in module.parameters())}
Path('reports/publication/head_detail_checks.json').write_text(json.dumps(records, indent=2))
print(records)
