"""Read-only artifact audit and descriptive latency measurement; no training."""
import csv, hashlib, json, random, statistics, time
from pathlib import Path
import torch
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'reports/multiscale_experiment'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    plan = json.loads((OUT/'plan.json').read_text(encoding='utf-8'))
    for p, h in plan['source_hashes'].items(): assert sha(ROOT/p) == h, p
    rows=[]
    for j in plan['jobs']:
        run=ROOT/j['run']; s=json.loads((run/'val_summary.json').read_text())
        assert s['job']==j and s['split']=='val'
        assert s['source_hashes']==plan['source_hashes']
        assert s['plan_sha256']==sha(OUT/'plan.json')
        assert s['checkpoint_sha256']==sha(run/'weights/best.pt')
        history=list(csv.DictReader((run/'results.csv').open()))
        assert int(history[-1]['epoch'])==120
        rows.append(dict(dataset=j['dataset'],variant=j['variant'],seed=j['seed'],map5095=100*s['metrics']['metrics/mAP50-95(B)']))
    (OUT/'artifact_audit.json').write_text(json.dumps(dict(rows=rows,source_hashes_match=True,checkpoint_hashes_match=True,script_sha256=sha(Path(__file__))),indent=2))
    torch.set_num_threads(4)
    models={}; meta={}
    for j in plan['jobs']:
        if j['seed']!=42: continue
        for variant,run in [(j['variant'],j['run']),('phase',j['phase_control'])]:
            key=j['dataset']+'_'+variant
            if key in models: continue
            p=ROOT/run/'weights/best.pt'; m=YOLO(str(p)).model.cuda().float().eval()
            meta[key]=dict(checkpoint=str(p),sha256=sha(p),parameters=sum(x.numel() for x in m.parameters()))
            models[key]=m.fuse()
    x=torch.rand(1,3,320,320,device='cuda'); trials={k:[] for k in models}; orders=[]
    rng=random.Random(20260920)
    with torch.inference_mode():
        for m in models.values():
            for _ in range(30): m(x)
        for cycle in range(7):
            order=list(models); rng.shuffle(order); orders.append(order)
            for k in order:
                m=models[k]
                for _ in range(5): m(x)
                torch.cuda.synchronize(); a=torch.cuda.Event(enable_timing=True); b=torch.cuda.Event(enable_timing=True)
                t=time.perf_counter(); a.record()
                for _ in range(100): m(x)
                b.record(); torch.cuda.synchronize()
                trials[k].append(dict(event_ms=a.elapsed_time(b)/100,wall_ms=(time.perf_counter()-t)*10))
            print('cycle',cycle+1,flush=True)
    for k in models:
        v=[r['event_ms'] for r in trials[k]]
        meta[k].update(trials=trials[k],median_ms=statistics.median(v),cv=statistics.pstdev(v)/statistics.mean(v),drift=statistics.mean(v[-2:])/statistics.mean(v[:2])-1)
    reliable=all(r['cv']<=.05 and abs(r['drift'])<=.05 for r in meta.values())
    result=dict(protocol='seed42 checkpoints, FP32 fused batch1 320; 30 warmup; 7 randomized cycles x100 forwards; no preprocessing/NMS',reliability_rule='every model CV and absolute first/last-two drift <=5%; fixed before timing',timing_reliable=reliable,models=meta,orders=orders,gpu=torch.cuda.get_device_name(),torch=torch.__version__,script_sha256=sha(Path(__file__)))
    (OUT/'latency_audit.json').write_text(json.dumps(result,indent=2))
    print('timing_reliable',reliable)
if __name__=='__main__': main()
