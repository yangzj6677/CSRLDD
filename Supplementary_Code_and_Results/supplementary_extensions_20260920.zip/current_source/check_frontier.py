"""Meaningful operator, gradient, integration and serialization checks."""
import io
import json
from pathlib import Path
import torch
from ultralytics import YOLO
from phase_modules import PhaseInjection
from frontier_modules import FrontierInjection, attach_frontier

def main():
    torch.set_num_threads(4)
    torch.manual_seed(1016)
    ref=PhaseInjection(16,64,'phase').double()
    torch.nn.init.normal_(ref.condition.weight,std=.1)
    shallow=torch.randn(2,16,12,12,dtype=torch.float64)
    semantic=torch.randn(2,64,6,6,dtype=torch.float64)
    results={}
    for variant in ('phase','rotation_static','rotation_dynamic','direction_gain'):
        mod=FrontierInjection(16,64,variant).double()
        mod.load_state_dict(ref.state_dict(),strict=False)
        q=ref.packed(shallow,semantic).reshape(2,16,4,6,6)
        initial=mod.packed(shallow,semantic).reshape_as(q)
        identity=(initial-q).abs().max().item()
        assert identity<1e-12
        if variant!='phase':
            torch.nn.init.normal_(mod.angle.weight,std=.1)
        new=mod.packed(shallow,semantic).reshape_as(q)
        mean_error=(new.mean(2)-q.mean(2)).abs().max().item()
        norm_error=((new-new.mean(2,keepdim=True)).norm(dim=2)-(q-q.mean(2,keepdim=True)).norm(dim=2)).abs().max().item()
        assert mean_error<1e-12
        if variant.startswith('rotation'): assert norm_error<1e-12
        # A non-isotropic linear probe avoids the rotation-invariant norm loss.
        (new*torch.randn_like(new)).sum().backward()
        if variant!='phase':
            assert torch.isfinite(mod.angle.weight.grad).all() and mod.angle.weight.grad.abs().max()>0
        results[variant]=dict(initial_identity_error=identity,mean_error=mean_error,detail_norm_error=norm_error,
                              parameters=sum(p.numel() for p in mod.parameters()))
    device='cuda' if torch.cuda.is_available() else 'cpu'
    baseline=YOLO('models/yolo11n.pt').model.to(device).eval()
    x=torch.rand(1,3,320,320,device=device)
    with torch.no_grad(): expected=baseline(x)[0].clone()
    attach_frontier(baseline,'rotation_dynamic')
    baseline.to(device).eval()
    with torch.no_grad(): actual=baseline(x)[0]
    error=(expected-actual).abs().max().item()
    assert error==0, error
    stream=io.BytesIO();torch.save(baseline,stream);stream.seek(0)
    loaded=torch.load(stream,weights_only=False).eval()
    with torch.no_grad(): assert torch.equal(actual,loaded(x)[0])
    results['detector']=dict(device=device,initial_identity_error=error,serialization='pass')
    out=Path('reports/frontier');out.mkdir(parents=True,exist_ok=True)
    (out/'prototype_checks.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2))

if __name__=='__main__': main()
