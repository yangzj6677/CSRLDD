"""Report the frozen full-budget head-detail validation screen."""
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/head_detail_experiment"


def map5095(path):
    return 100.0 * json.loads(
        path.read_text(encoding="utf-8")
    )["metrics"]["metrics/mAP50-95(B)"]


def summarize(candidate_jobs, control_jobs, dataset, variant):
    rows = [
        job
        for job in candidate_jobs
        if job["dataset"] == dataset and job["variant"] == variant
    ]
    per_seed = {}
    values = []
    for job in sorted(rows, key=lambda item: item["seed"]):
        phase = next(
            item
            for item in control_jobs
            if item["dataset"] == dataset and item["seed"] == job["seed"]
        )
        difference = (
            map5095(ROOT / job["run"] / "val_summary.json")
            - map5095(ROOT / phase["run"] / "val_summary.json")
        )
        per_seed[str(job["seed"])] = difference
        values.append(difference)
    return {
        "per_seed_pp": per_seed,
        "mean_pp": statistics.fmean(values),
        "sample_sd_pp": statistics.stdev(values),
        "positive_seeds": sum(value > 0.0 for value in values),
    }


def main():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    phase_jobs = [
        {**job, "run": job["phase_control"]} for job in plan["jobs"]
    ]
    results = {}
    for variant in ("phase_box", "phase_head"):
        results[variant] = {}
        for dataset in ("deeppcb", "neu"):
            results[variant][dataset] = summarize(
                plan["jobs"], phase_jobs, dataset, variant
            )
    gate = {}
    for variant, dataset_results in results.items():
        gate[variant] = {
            "passed": (
                all(
                    result["mean_pp"] >= plan["gate"]["both_datasets_min_pp"]
                    for result in dataset_results.values()
                )
                and any(
                    result["mean_pp"]
                    >= plan["gate"]["at_least_one_dataset_min_pp"]
                    for result in dataset_results.values()
                )
            ),
            **plan["gate"],
        }
    output = {"results": results, "gate": gate}
    (OUT / "results.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )
    lines = [
        "# 检测头定向细节注入：120轮验证筛选",
        "",
        "比较 `phase_box - phase` 与 `phase_head - phase`，仅使用验证集。",
        "",
        "|候选|数据集|逐种子差值(pp)|均值±样本SD|正向种子|",
        "|---|---|---|---:|---:|",
    ]
    for variant, dataset_results in results.items():
        for dataset, result in dataset_results.items():
            values = ", ".join(
                f"{value:+.3f}" for value in result["per_seed_pp"].values()
            )
            lines.append(
                f"|{variant}|{dataset}|{values}|"
                f"{result['mean_pp']:+.3f} ± "
                f"{result['sample_sd_pp']:.3f}|"
                f"{result['positive_seeds']}/3|"
            )
    lines.extend(
        [
            "",
            f"phase_box 门槛：{'支持' if gate['phase_box']['passed'] else '不支持'}。",
            f"phase_head 门槛：{'支持' if gate['phase_head']['passed'] else '不支持'}。",
            "",
            "门槛要求两个数据集均值不下降，且至少一个数据集提高0.5个百分点。",
            "本轮不接触测试集；只有通过验证门槛的候选才单独进入测试阶段。",
        ]
    )
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
