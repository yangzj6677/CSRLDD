"""Execute one immutable stage-two job; validation only, never test selection."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parent
os.environ.setdefault('YOLO_CONFIG_DIR', str(ROOT/'.yolo_config'))
import torch
from ultralytics import YOLO
from alignment_modules import AlignmentTrainer


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--job',required=True)
    args=parser.parse_args()
    plan=json.loads((ROOT/'reports/alignment/plan.json').read_text())
    job=next(j for j in plan['jobs'] if j['id']==args.job)
    for filename, expected in plan['source_hashes'].items():
        assert hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()==expected, filename
    torch.set_num_threads(4)
    assert torch.cuda.is_available()
    run=ROOT/job['run']
    if (run/'val_summary.json').exists():
        raise RuntimeError('Completed run must not be overwritten')
    data=ROOT/'data'/f"{job['dataset']}_yolo/data.yaml"
    AlignmentTrainer.variant=job['variant']
    AlignmentTrainer.init_seed=job['init_seed']
    trainer={} if job['variant']=='baseline' else {'trainer':AlignmentTrainer}
    start=time.time()
    import csv
    rows=list(csv.DictReader((run/'results.csv').open())) if (run/'results.csv').exists() else []
    if rows and int(rows[-1]['epoch'])==job['epochs'] and (run/'weights/best.pt').exists():
        pass
    elif (run/'weights/last.pt').exists():
        model=YOLO(str(run/'weights/last.pt'))
        model.train(**trainer,resume=True,device=0,workers=0)
    else:
        assert not run.exists(), f'Incomplete run without resumable weights: {run}'
        model=YOLO(str(ROOT/'models/yolo11n.pt'))
        model.train(**trainer,data=str(data),epochs=job['epochs'],imgsz=job['imgsz'],batch=16,
                    device=0,workers=0,seed=job['seed'],deterministic=True,optimizer='AdamW',
                    lr0=.001,patience=0,amp=False,cache=False,project=str(run.parent),name=run.name,
                    exist_ok=False,plots=False,hsv_h=0,hsv_s=0,hsv_v=.2,close_mosaic=5)
        assert Path(model.trainer.save_dir).resolve()==run.resolve()
    best=YOLO(str(run/'weights/best.pt'))
    assert getattr(best.model,'refinement_variant','baseline')==job['variant']
    assert best.ckpt['train_args']['seed']==job['seed']
    assert best.ckpt['train_args']['imgsz']==job['imgsz']
    metrics=best.val(data=str(data),split='val',imgsz=job['imgsz'],batch=16,device=0,workers=0,
                     plots=False,save_json=True,project=str(run.parent),name=run.name+'_val',exist_ok=False)
    result={'job':job,'split':'val','metrics':metrics.results_dict,'per_class':metrics.summary(),
            'elapsed_seconds_this_invocation':time.time()-start,
            'checkpoint_sha256':hashlib.sha256((run/'weights/best.pt').read_bytes()).hexdigest(),
            'source_hashes':plan['source_hashes'],'evaluation_dir':str(metrics.save_dir),
            'plan_sha256':hashlib.sha256((ROOT/'reports/alignment/plan.json').read_bytes()).hexdigest()}
    (run/'val_summary.json').write_text(json.dumps(result,indent=2,default=str))
    print(json.dumps(result,indent=2,default=str),flush=True)


if __name__=='__main__':
    main()
