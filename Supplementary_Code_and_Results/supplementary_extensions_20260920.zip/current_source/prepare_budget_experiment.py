"""Freeze the prospective validation comparison, retaining known-test disclosure."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
out = root/'reports/budget_experiment'
out.mkdir(parents=True, exist_ok=True)
assert not (out/'plan.json').exists(), 'Do not overwrite a frozen plan'
source = (root/'run_stage2_job.py').read_text()
source = source.replace('from stage2_modules import Stage2Trainer', 'from budget_modules import BudgetTrainer')
source = source.replace('Stage2Trainer', 'BudgetTrainer').replace('reports/stage2', 'reports/budget_experiment')
(root/'run_budget_job.py').write_text(source)
jobs = []
for seed in (42,43,44):
    for dataset in ('deeppcb','neu'):
        for variant in ('budget_full','budget_gate','budget_project','budget_constant'):
            name = f'{dataset}_{variant}_s{seed}_r320_120e'
            jobs.append(dict(id=name,dataset=dataset,variant=variant,seed=seed,
                             init_seed=1016,imgsz=320,epochs=120,batch=16,
                             run=f'runs/budget_experiment/{name}'))
old = json.loads((root/'reports/stage2/plan.json').read_text())
refs = [j for j in old['jobs'] if j['family']=='mechanism' and j['variant']=='phase']
reference_hashes = {j['run']+'/val_summary.json':hashlib.sha256((root/j['run']/'val_summary.json').read_bytes()).hexdigest() for j in refs}
files = ('budget_modules.py','phase_modules.py','run_budget_job.py','run_budget_queue.py',
         'models/yolo11n.pt','data/neu_yolo/data.yaml','data/deeppcb_yolo/data.yaml')
plan = dict(created_utc=datetime.now(timezone.utc).isoformat(),jobs=jobs,reused_reference_jobs=refs,
            reference_hashes=reference_hashes,
            source_hashes={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},
            endpoint='validation mAP50-95 of best validation-selected EMA checkpoint',
            limitations=['Post-test-informed exploration','validation selects and measures checkpoint',
                         '3 seeds, fixed partitions; no independent population inference'],
            contrasts=['full-phase','full-gate','full-project','full-constant'],
            stop_rule='All 24 runs retained; stop on failure; no result-driven changes',
            rho=.25,notes='constant gate 0.5 implies norm <=0.25||d||; its projection is mathematically redundant')
(out/'plan.json').write_text(json.dumps(plan,indent=2))
print(f'Frozen {len(jobs)} new jobs and {len(refs)} existing phase references')
