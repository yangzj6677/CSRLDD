"""Exploratory local semantic conditioning; preserves the existing phase cell."""
import torch
from torch import nn
from torch.nn import functional as F
from phase_modules import PhaseInjection, PhaseBlock
from ultralytics.models.yolo.detect import DetectionTrainer

class AlignmentInjection(PhaseInjection):
    def __init__(self, shallow_channels, channels, variant):
        super().__init__(shallow_channels,channels,'phase')
        self.variant=variant
        assert variant in ('phase','align_uniform','align_self','align_cross','align_dw')
        if variant!='phase':
            self.beta=nn.Parameter(torch.zeros(1))
        if variant in ('align_self','align_cross'):
            self.query=nn.Conv2d(shallow_channels if variant=='align_cross' else channels,8,1)
            self.key=nn.Conv2d(channels,8,1)
        elif variant=='align_dw':
            self.context=nn.Conv2d(channels,channels,3,padding=1,groups=channels)

    def aligned(self, shallow, semantic):
        if self.variant=='phase':return semantic
        if self.variant=='align_dw':
            delta=self.context(semantic)
        else:
            b,c,h,w=semantic.shape
            # Replicate padding avoids spurious zero-valued edge neighbors.
            values=F.unfold(F.pad(semantic,(1,1,1,1),mode='replicate'),3).reshape(b,c,9,h,w)
            if self.variant=='align_uniform':
                pooled=values.mean(2)
            else:
                source=F.avg_pool2d(shallow,2) if self.variant=='align_cross' else semantic
                q=self.query(source)
                keys=F.unfold(F.pad(self.key(semantic),(1,1,1,1),mode='replicate'),3).reshape(b,8,9,h,w)
                weights=((q[:,:,None]*keys).sum(1)/(8**.5)).softmax(1)
                pooled=(values*weights[:,None]).sum(2)
            delta=pooled-semantic
        return semantic+self.beta.tanh()*delta

    def packed(self, shallow, semantic):
        return super().packed(shallow,self.aligned(shallow,semantic))

def attach_alignment(model,variant,init_seed=1016):
    original=model.model[16]
    assert not isinstance(original,PhaseBlock)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        addition=AlignmentInjection(model.model[2].cv2.conv.out_channels,original.cv2.conv.out_channels,variant)
    model.model[16]=PhaseBlock(original,addition)
    model.save=sorted(set(model.save+[2]))
    model.refinement_variant=variant;model.branch_init_seed=init_seed
    return model

class AlignmentTrainer(DetectionTrainer):
    variant='align_cross'
    init_seed=1016
    def get_model(self,cfg=None,weights=None,verbose=True):
        wrapped=weights is not None and isinstance(weights.model[16],PhaseBlock)
        if wrapped: assert weights.refinement_variant==self.variant
        model=attach_alignment(super().get_model(cfg,None if wrapped else weights,verbose),self.variant,self.init_seed)
        if wrapped:model.load(weights)
        return model
