"""Freeze the first eight validation-only screening jobs."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'reports/frontier'

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT/'plan.json').exists(), 'Do not overwrite frozen plan'
    # Keep all existing training settings and checkpoint selection semantics.
    runner = (ROOT/'run_budget_job.py').read_text(encoding='utf-8')
    runner = runner.replace('budget_experiment', 'frontier').replace('budget_modules', 'frontier_modules').replace('BudgetTrainer', 'FrontierTrainer')
    (ROOT/'run_frontier_job.py').write_text(runner, encoding='utf-8')
    jobs = []
    for dataset in ('deeppcb','neu'):
        for variant in ('phase','rotation_static','rotation_dynamic','direction_gain'):
            name = f'{dataset}_{variant}_s42_r320_120e'
            jobs.append(dict(id=name,dataset=dataset,variant=variant,seed=42,init_seed=1016,imgsz=320,
                             epochs=120,batch=16,run=f'runs/frontier/{name}'))
    sources=['frontier_modules.py','phase_modules.py','run_frontier_job.py','run_frontier_queue.py',
             'check_frontier.py','requirements-lock.txt','models/yolo11n.pt',
             'data/neu_yolo/data.yaml','data/deeppcb_yolo/data.yaml']
    hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources}
    plan=dict(created_utc=datetime.now(timezone.utc).isoformat(),stage='rotation_screen',jobs=jobs,
              source_hashes=hashes,selection='validation only; no test evaluation',
              continuation=['local semantic alignment after rotation screen review','micro-shift diagnostics before consistency training'],
              gate=dict(dynamic_minus_phase_both_datasets_min_pp=0.0,at_least_one_dataset_min_pp=0.5,
                        forward_latency_increase_max_fraction=0.1),
              caveats=['single seed exploratory screen','195 stored parameters in each added head; static effective freedom lower',
                       'existing tests already known; not independent confirmation'])
    (OUT/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
    print('Frozen 8 jobs; validation only')

if __name__=='__main__':
    main()
