"""Aggregate subgroup recall and evaluate the frozen paired-seed gate."""
import json
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/subgroups"


def load_results():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    raw = json.loads((OUT / "raw_results.json").read_text(encoding="utf-8"))
    return plan, raw


def group_membership(record, group):
    if group == "all":
        return True
    if group == "other":
        return "other" in record["groups"]
    return group in record["groups"]


def aggregate(records):
    totals = defaultdict(lambda: {"n": 0, "m50": 0, "m75": 0, "iou": 0.0})
    for record in records:
        key = (
            record["dataset"],
            record["split"],
            record["variant"],
            record["seed"],
        )
        groups = ["all"] + list(record["groups"])
        for group in set(groups):
            row = totals[(*key, group)]
            row["n"] += 1
            row["m50"] += int(record["matched_50"])
            row["m75"] += int(record["matched_75"])
            row["iou"] += float(record["best_iou"])
    output = {}
    for key, row in totals.items():
        n = row["n"]
        output[key] = {
            "n": n,
            "recall_at_iou_50": row["m50"] / n if n else None,
            "recall_at_iou_75": row["m75"] / n if n else None,
            "mean_best_iou": row["iou"] / n if n else None,
        }
    return output


def paired_differences(aggregates, plan, split, left, right, group, metric):
    datasets = {}
    for dataset in sorted({job["dataset"] for job in plan["models"]}):
        deltas = []
        per_seed = {}
        for seed in (42, 43, 44):
            left_row = aggregates.get((dataset, split, left, seed, group))
            right_row = aggregates.get((dataset, split, right, seed, group))
            if left_row is None or right_row is None:
                continue
            left_value = left_row[metric]
            right_value = right_row[metric]
            delta = 100.0 * (left_value - right_value)
            deltas.append(delta)
            per_seed[str(seed)] = delta
        datasets[dataset] = {
            "n_seeds": len(deltas),
            "positive_seeds": sum(value > 0.0 for value in deltas),
            "per_seed_pp": per_seed,
            "mean_pp": statistics.fmean(deltas) if deltas else None,
            "sample_sd_pp": statistics.stdev(deltas) if len(deltas) > 1 else None,
        }
    return datasets


def main():
    plan, raw = load_results()
    aggregates = aggregate(raw["records"])
    primary = plan["primary_comparison"]
    paired = {}
    for split in plan["splits"]:
        paired[f"{split}/primary"] = paired_differences(
            aggregates,
            plan,
            split,
            primary["left"],
            primary["right"],
            primary["group"],
            primary["metric"],
        )
        for right in ("baseline", "plain"):
            paired[f"{split}/{primary['left']}_minus_{right}"] = paired_differences(
                aggregates,
                plan,
                split,
                primary["left"],
                right,
                primary["group"],
                primary["metric"],
            )

    gate_results = {}
    for dataset, result in paired["val/primary"].items():
        gate_results[dataset] = {
            "mean_delta_pp": result["mean_pp"],
            "positive_seeds": result["positive_seeds"],
            "passes": (
                result["mean_pp"] is not None
                and result["mean_pp"] >= plan["gate"]["both_datasets_min_mean_delta_pp"]
                and result["positive_seeds"]
                >= plan["gate"]["minimum_positive_seeds_per_dataset"]
            ),
        }
    gate_passed = all(result["passes"] for result in gate_results.values())

    summary = {
        "plan_sha256": raw["plan_sha256"],
        "aggregates": {
            "/".join(map(str, key)): value for key, value in aggregates.items()
        },
        "paired": paired,
        "gate": {
            "passed": gate_passed,
            "datasets": gate_results,
            "rule": plan["gate"],
            "scope": "validation primary group; test remains descriptive post-hoc",
        },
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    lines = [
        "# 困难组分层召回诊断",
        "",
        "阈值完全来自训练集框几何，未根据本轮结果调整。"
        "验证集用于冻结门槛，测试集结果仅作事后描述。",
        "",
        "## 主比较",
        "",
        "`phase - phase_uniform`，`narrow_or_elongated` 组，IoU=0.50。",
        "",
        "|划分|数据集|三种子差值(pp)|均值±样本SD(pp)|正向种子|",
        "|---|---|---|---:|---:|",
    ]
    for split in plan["splits"]:
        for dataset, result in paired[f"{split}/primary"].items():
            values = ", ".join(
                f"{value:+.3f}" for value in result["per_seed_pp"].values()
            )
            mean = result["mean_pp"]
            sd = result["sample_sd_pp"]
            lines.append(
                f"|{split}|{dataset}|{values}|"
                f"{mean:+.3f} ± {sd:.3f}|"
                f"{result['positive_seeds']}/{result['n_seeds']}|"
            )
    lines.extend(
        [
            "",
            f"冻结验证门槛结果：{'支持' if gate_passed else '不支持'}。",
            "",
            "门槛要求两个数据集验证集均值至少 +0.5 个百分点，"
            "且每个数据集至少 2/3 种子为正。",
            "",
            "这里的 recall 不是 mAP 的替代，也不排除置信度阈值和预测排序的影响。",
            "小框组数量过少时只作描述，不单独用于机制结论。",
        ]
    )
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(summary["gate"], indent=2))


if __name__ == "__main__":
    main()
