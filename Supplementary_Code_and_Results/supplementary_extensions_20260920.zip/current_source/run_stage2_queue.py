"""Serial resumable stage-two queue. Stop on error; never change the frozen budget."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'


def main():
    plan=json.loads((OUT/'plan.json').read_text())
    for name,expected in plan['source_hashes'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
    state={'started_utc':datetime.now(timezone.utc).isoformat(),'total':len(plan['jobs']),
           'completed':[],'active':None,'failures':[]}
    def save():
        state['updated_utc']=datetime.now(timezone.utc).isoformat()
        tmp=OUT/'state.tmp'
        tmp.write_text(json.dumps(state,indent=2))
        tmp.replace(OUT/'state.json')
    for job in plan['jobs']:
        result=ROOT/job['run']/'val_summary.json'
        if result.exists():
            assert json.loads(result.read_text())['job']==job
            state['completed'].append(job['id'])
            continue
        state['active']=job['id']
        save()
        print('Starting '+job['id'],flush=True)
        with (OUT/(job['id']+'.log')).open('a',encoding='utf-8') as log:
            code=subprocess.call([sys.executable,str(ROOT/'run_stage2_job.py'),'--job',job['id']],
                                 cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if code or not result.exists():
            state['failures'].append({'job':job['id'],'exit_code':code})
            save()
            raise SystemExit('Stopped on technical failure; consult job log before any amendment.')
        state['completed'].append(job['id'])
        state['active']=None
        save()
        print(f'Completed {len(state["completed"])}/{state["total"]}: '+job['id'],flush=True)
    state['active']=None
    state['status']='validation matrix complete; no test automatically evaluated'
    save()


if __name__=='__main__':
    main()
