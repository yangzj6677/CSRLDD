"""Bounded two-dataset validation-only screen after localization regression was observed."""
import csv
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for dataset in ('deeppcb', 'neu'):
    for variant in ('phase_box', 'phase_head'):
        name = f'{"deeppcb_" if dataset == "deeppcb" else ""}{variant}_s42_30e'
        run = ROOT / 'runs/publication' / name
        if (run / 'val_summary.json').exists():
            continue
        command = [sys.executable, 'run_innovation.py', '--variant', variant, '--dataset', dataset,
                   '--seed', '42', '--epochs', '30', '--project', str(ROOT / 'runs/publication')]
        rows = list(csv.DictReader((run/'results.csv').open())) if (run/'results.csv').exists() else []
        if rows and int(rows[-1]['epoch']) >= 30 and (run/'weights/best.pt').exists():
            command += ['--evaluate', str(run/'weights/best.pt')]
        elif (run/'weights/last.pt').exists():
            command += ['--resume', str(run/'weights/last.pt')]
        elif run.exists():
            raise RuntimeError(f'Incomplete checkpointless run: {run}')
        print(f'Starting {name}', flush=True)
        with (ROOT/f'publication_{name}_head.log').open('a', encoding='utf-8') as log:
            subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True)
        print(f'Completed {name}', flush=True)
    subprocess.run([sys.executable, 'report_supplement.py'], cwd=ROOT, check=True)
