"""Randomized repeated fused FP32 forward-only timings, no test data."""
import json, random, time, statistics
from pathlib import Path
import torch
from ultralytics import YOLO
import frontier_modules

torch.set_num_threads(4)
out=Path('reports/frontier')
plan=json.loads((out/'plan.json').read_text())
models={j['variant']:YOLO(str(Path(j['run'])/'weights/best.pt')).model.cuda().float().eval().fuse()
        for j in plan['jobs'] if j['dataset']=='neu'}
x=torch.rand(1,3,320,320,device='cuda')
times={k:[] for k in models}
rng=random.Random(20260915)
with torch.inference_mode():
    for model in models.values():
        for _ in range(30): model(x)
    for trial in range(5):
        order=list(models);rng.shuffle(order)
        for key in order:
            for _ in range(5): models[key](x)
            torch.cuda.synchronize();start=time.perf_counter()
            for _ in range(100): models[key](x)
            torch.cuda.synchronize()
            times[key].append((time.perf_counter()-start)*10)
result={'protocol':'NEU seed42; batch1 320 FP32 fused;30 warmup;5 randomized trials x100; forward only',
        'gpu':torch.cuda.get_device_name(),'trials_ms':times,
        'median_ms':{k:statistics.median(v) for k,v in times.items()}}
result['dynamic_relative_latency']=result['median_ms']['rotation_dynamic']/result['median_ms']['phase']-1
(out/'latency.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
