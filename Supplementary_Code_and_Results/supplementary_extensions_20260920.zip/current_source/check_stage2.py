"""CPU verification before freezing the expanded training matrix."""
import copy
import io
import json
from pathlib import Path
import torch
from ultralytics import YOLO
from stage2_modules import attach_stage2

torch.set_num_threads(4)
torch.manual_seed(123)
base = YOLO('models/yolo11n.pt').model.eval()
x = torch.rand(1, 3, 320, 320)
with torch.no_grad():
    expected = base(x)[0]
records = {}
modules = {}
for variant in ('phase_uniform', 'phase', 'phase_capacity', 'phase_uncentered'):
    model = attach_stage2(copy.deepcopy(base), variant).eval()
    with torch.no_grad():
        assert torch.equal(expected, model(x)[0])
    b = io.BytesIO()
    torch.save(model, b)
    b.seek(0)
    restored = torch.load(b, weights_only=False).eval()
    with torch.no_grad():
        assert torch.equal(expected, restored(x)[0])
    module = model.model[16].addition.train()
    modules[variant] = copy.deepcopy(module)
    s, p = torch.randn(2,64,20,20), torch.randn(2,64,40,40)
    module(s,p).square().mean().backward()
    assert module.gamma.grad.abs().sum() > 0
    with torch.no_grad():
        module.gamma.fill_(.01)
    module.zero_grad(set_to_none=True)
    module(s,p).square().mean().backward()
    assert all(t.grad is not None and torch.isfinite(t.grad).all() and t.grad.abs().sum()>0 for t in module.parameters())
    records[variant] = {'initial_identity': True, 'serialization': True, 'gradient_reachability': True,
                        'added_parameters':sum(t.numel() for t in module.parameters())}
assert records['phase']['added_parameters'] == records['phase_capacity']['added_parameters'] == records['phase_uncentered']['added_parameters'] == 10208
for name, value in modules['phase_uniform'].state_dict().items():
    for variant in ('phase','phase_capacity','phase_uncentered'):
        assert torch.equal(value, modules[variant].state_dict()[name]), name
other = attach_stage2(copy.deepcopy(base), 'phase', 2042).model[16].addition
assert not torch.equal(other.compress.conv.weight, modules['phase'].compress.conv.weight)
out = Path('reports/stage2')
out.mkdir(parents=True, exist_ok=True)
(out/'module_checks.json').write_text(json.dumps({'variants':records,'common_initialization_equal':True,'alternative_initialization_differs':True},indent=2))
print(records)
