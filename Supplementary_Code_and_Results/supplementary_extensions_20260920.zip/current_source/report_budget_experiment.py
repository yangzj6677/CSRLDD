"""Report only completed budget runs and matched frozen phase references."""
import csv
import json
import statistics as st
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/budget_experiment'
plan=json.loads((OUT/'plan.json').read_text())
rows=[]
progress=[]
for job in plan['jobs']:
    run=ROOT/job['run']
    history=list(csv.DictReader((run/'results.csv').open())) if (run/'results.csv').exists() else []
    item={'job':job,'epochs_observed':int(history[-1]['epoch']) if history else 0,
          'validation_complete':(run/'val_summary.json').exists(),
          'test_complete':(run/'posthoc_test_summary.json').exists()}
    for split,name in (('val','val_summary.json'),('test','posthoc_test_summary.json')):
        path=run/name
        if path.exists():
            record=json.loads(path.read_text()); assert record['job']==job
            rows.append({'stage':'budget','dataset':job['dataset'],'variant':job['variant'],
                         'seed':job['seed'],'split':split,
                         'map5095':100*record['metrics']['metrics/mAP50-95(B)'],
                         'map50':100*record['metrics']['metrics/mAP50(B)']})
    progress.append(item)

# Frozen phase validation references.
for ref in plan['reused_reference_jobs']:
    record=json.loads((ROOT/ref['run']/'val_summary.json').read_text())
    assert record['job']==ref
    rows.append({'stage':'reference','dataset':ref['dataset'],'variant':'phase','seed':ref['seed'],
                 'split':'val','map5095':100*record['metrics']['metrics/mAP50-95(B)'],
                 'map50':100*record['metrics']['metrics/mAP50(B)']})

# Phase test references from the completed main study.
main=json.loads((ROOT/'reports/submission/confirmation_results.json').read_text())
for record in main['records']:
    if record['variant']=='phase' and record['split']=='test':
        rows.append({'stage':'reference','dataset':record['dataset'],'variant':'phase','seed':record['seed'],
                     'split':'test','map5095':100*record['metrics']['metrics/mAP50-95(B)'],
                     'map50':100*record['metrics']['metrics/mAP50(B)']})

indexed={(r['dataset'],r['variant'],r['seed'],r['split']):r for r in rows}
groups={}
for r in rows:
    groups.setdefault((r['dataset'],r['variant'],r['split']),[]).append(r)
aggregates=[]
for key,values in groups.items():
    vals=[v['map5095'] for v in values]
    aggregates.append({'dataset':key[0],'variant':key[1],'split':key[2],'n':len(vals),
                       'mean_map5095':st.mean(vals),'sd_map5095':st.stdev(vals) if len(vals)>1 else None,
                       'complete_three_seeds':len(vals)==3})
contrasts=[]
for dataset in ('neu','deeppcb'):
  for split in ('val','test'):
    for candidate in ('budget_full','budget_gate','budget_project','budget_constant'):
      for control in ('phase','budget_gate','budget_project','budget_constant'):
        if candidate==control: continue
        diffs=[]
        for seed in (42,43,44):
            a=indexed.get((dataset,candidate,seed,split)); b=indexed.get((dataset,control,seed,split))
            if a and b: diffs.append(a['map5095']-b['map5095'])
        if diffs:
            contrasts.append({'dataset':dataset,'split':split,'candidate':candidate,'control':control,
                              'differences_pp':diffs,'n':len(diffs),'mean_pp':st.mean(diffs),
                              'sd_pp':st.stdev(diffs) if len(diffs)>1 else None,
                              'complete_three_seeds':len(diffs)==3})
result={'updated_utc':datetime.now(timezone.utc).isoformat(),'planned':24,
        'validation_completed':sum(p['validation_complete'] for p in progress),
        'test_completed':sum(p['test_complete'] for p in progress),
        'records':rows,'aggregates':aggregates,'paired_contrasts':contrasts,'progress':progress,
        'units':'mAP values are percentages; differences are percentage points'}
(OUT/'results.json').write_text(json.dumps(result,indent=2))
md=['# 预算机制实验结果','',f'完整验证：{result["validation_completed"]}/24；测试：{result["test_completed"]}/24。',
    '', '均值±样本SD；仅三种子完整组给出定稿汇总。测试均为已知测试集复用。','',
    '|数据集|划分|模型|n|mAP50–95|','|---|---|---|---:|---:|']
for a in sorted(aggregates,key=lambda x:(x['dataset'],x['split'],x['variant'])):
    summary=f'{a["mean_map5095"]:.3f} ± {a["sd_map5095"]:.3f}' if a['complete_three_seeds'] else '待完整三种子'
    md.append(f'|{a["dataset"]}|{a["split"]}|{a["variant"]}|{a["n"]}|{summary}|')
md += ['', '## 配对差值', '', '|数据集|划分|比较|n|逐种子差值|均值±SD|',
       '|---|---|---|---:|---|---:|']
for c in contrasts:
    summary=f'{c["mean_pp"]:+.3f} ± {c["sd_pp"]:.3f}' if c['complete_three_seeds'] else '待完整三种子'
    md.append(f'|{c["dataset"]}|{c["split"]}|{c["candidate"]}−{c["control"]}|{c["n"]}|'+
              ', '.join(f'{x:+.3f}' for x in c['differences_pp'])+f'|{summary}|')
(OUT/'实验结果.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(f'validation {result["validation_completed"]}/24; test {result["test_completed"]}/24')
