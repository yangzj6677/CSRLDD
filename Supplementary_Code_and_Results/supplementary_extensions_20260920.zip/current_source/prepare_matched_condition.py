"""Freeze contemporaneous condition-source comparison before training."""
import hashlib,json,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/matched_condition'
OUT.mkdir(exist_ok=True)
assert not (OUT/'plan.json').exists()
source=(ROOT/'run_self_condition_queue.py').read_text(encoding='utf-8')
source=source.replace('reports/self_condition','reports/matched_condition').replace('"phase_self",','job["variant"],')
# Incomplete runs require a deliberate recovery decision, never implicit resume.
source=source.replace('if run.exists() and not (run / "weights/last.pt").exists():','if run.exists():')
(ROOT/'run_matched_condition_queue.py').write_text(source,encoding='utf-8')
jobs=[]
for dataset in ('deeppcb','neu'):
    for seed in (42,43,44):
        for variant in ('phase','phase_self'):
            name=('deeppcb_' if dataset=='deeppcb' else '')+f'{variant}_s{seed}_120e'
            jobs.append(dict(id=f'{dataset}_{variant}_s{seed}',dataset=dataset,variant=variant,seed=seed,epochs=120,run='runs/matched_condition/'+name))
paths=['run_matched_condition_queue.py','prepare_matched_condition.py','run_innovation.py','innovation_modules.py','phase_modules.py','head_detail_modules.py','requirements-lock.txt','models/yolo11n.pt']
paths += [f'data/{d}_yolo/{f}' for d in ('neu','deeppcb') for f in ('data.yaml','manifest.json')]
hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
plan=dict(created_utc=datetime.now(timezone.utc).isoformat(),jobs=jobs,source_hashes=hashes,endpoint='validation mAP50-95; phase minus phase_self; report all paired seeds',purpose='Contemporaneous environment comparison replacing historical-control ambiguity; no new independent data',gate=dict(both_datasets_min_pp=0,at_least_one_dataset_min_pp=.5),protocol='120 epochs, 320 input, init1016, existing frozen runner settings; alternating variants within seed; no test; no automatic retries',environment_overrides={'POLARS_FORCE_PKG':'compat','POLARS_SKIP_CPU_CHECK':'1'})
(OUT/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
env=subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True)
(OUT/'installed_packages.txt').write_text(env,encoding='utf-8')
print('Frozen 12 jobs')
