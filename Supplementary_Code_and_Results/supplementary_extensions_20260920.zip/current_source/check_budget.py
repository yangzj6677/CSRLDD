"""CPU-only mathematical and detector-integration checks; not training."""
import io
import json
from pathlib import Path
import torch
from ultralytics import YOLO
from budget_modules import BudgetInjection, attach_budget, budget_correction

torch.set_num_threads(2)
torch.manual_seed(42)
d = torch.randn(2, 16, 4, 8, 8)
d = d - d.mean(2, keepdim=True)
delta = torch.randn_like(d) * 5
delta -= delta.mean(2, keepdim=True)
out = budget_correction(d, delta)
assert out.mean(2).abs().max() < 1e-6
assert (out.norm(dim=2) <= .25 * d.norm(dim=2) + 1e-6).all()
assert torch.equal(budget_correction(torch.zeros_like(d), delta), torch.zeros_like(d))
records = {}
for variant in ('budget_full', 'budget_gate', 'budget_project', 'budget_constant'):
    m = BudgetInjection(64, 64, variant).eval()
    shallow, semantic = torch.randn(2, 64, 16, 16), torch.randn(2, 64, 8, 8)
    assert torch.equal(m(semantic, shallow), semantic)
    with torch.no_grad():
        m.gamma.fill_(.1)
        m.condition.weight.normal_(0, .2)
    packed = torch.nn.functional.pixel_unshuffle(m.compress(shallow), 2)
    actual = m.packed(shallow, semantic)
    error = (actual.reshape(2,16,4,8,8).mean(2) - packed.reshape(2,16,4,8,8).mean(2)).abs().max()
    assert error < 1e-6
    m(semantic, shallow).square().mean().backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for n,p in m.named_parameters()
               if not n.startswith('gate.') or variant in ('budget_full','budget_gate'))
    records[variant] = {'parameters':sum(p.numel() for p in m.parameters()), 'mean_error':float(error.detach())}
base = YOLO('models/yolo11n.pt').model.eval()
x = torch.rand(1,3,64,64)
with torch.no_grad():
    expected = base(x)[0]
    model = attach_budget(base).eval()
    assert torch.equal(expected, model(x)[0])
    buf = io.BytesIO()
    torch.save(model, buf)
    buf.seek(0)
    restored = torch.load(buf, weights_only=False).eval()
    assert torch.equal(expected, restored(x)[0])
records['detector_initial_identity_and_serialization'] = True
dest = Path('reports/innovation')
dest.mkdir(parents=True, exist_ok=True)
(dest/'prototype_checks.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))
