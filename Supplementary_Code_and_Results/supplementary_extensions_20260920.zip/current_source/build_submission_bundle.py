"""Build a portable, allow-listed supplement without changing original experiments.

Original hashes and relative source identifiers are retained beside exported hashes.
Only explicit text/code/metric files are included; no images, datasets or weights.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'reports/submission'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def relative(path):
    return Path(path).resolve().relative_to(ROOT).as_posix()


def redact(value):
    if isinstance(value, dict):
        return {redact(k): redact(v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str):
        normalized = value.replace('\\', '/')
        prefix = ROOT.as_posix()
        if normalized == prefix:
            return '.'
        if normalized.startswith(prefix + '/'):
            return normalized[len(prefix) + 1:]
        for old in (str(ROOT).replace('\\', '\\\\'), str(ROOT), ROOT.as_posix()):
            value = value.replace(old, '<WORKSPACE>')
    return value


def portable_bytes(path):
    original = path.read_bytes()
    text = original.decode('utf-8-sig')
    # Fast path preserves code snapshots and potentially large predictions byte-for-byte.
    candidates = (str(ROOT), ROOT.as_posix(), str(ROOT).replace('\\', '\\\\'))
    if not any(prefix in text for prefix in candidates):
        return original, 'none'
    if path.suffix == '.json':
        exported = json.dumps(redact(json.loads(text)), indent=2, ensure_ascii=False) + '\n'
    elif path.suffix in ('.yaml', '.yml'):
        import yaml
        exported = yaml.safe_dump(redact(yaml.safe_load(text)), sort_keys=False)
    else:
        exported = redact(text)
    return exported.encode('utf-8'), 'workspace paths replaced by relative paths or <WORKSPACE>; text serialization normalized'


def ensure_clean(name, data):
    allowed = {'.py', '.json', '.yaml', '.yml', '.csv', '.txt', '.md', '.bib'}
    path = Path(name)
    assert path.suffix in allowed, name
    assert not path.is_absolute() and '..' not in path.parts, name
    forbidden = {'.venv', '.git', '.ssh', '.aws', '.yolo_config', 'weights', '__pycache__'}
    assert not set(path.parts) & forbidden, name
    text = data.decode('utf-8-sig')
    assert not re.search(r'(?i)\b[a-z]:[\\/]{1,2}(?:Users|Documents and Settings)[\\/]', text), name
    assert str(ROOT) not in text and ROOT.as_posix() not in text, name
    assert not re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|AKIA[A-Z0-9]{16}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{32,}', text), name


class Bundle:
    def __init__(self, path):
        self.zip = zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9)
        self.files = []
        self.names = set()

    def add_bytes(self, name, data, source=None, original_hash=None, transformation='generated'):
        if name in self.names:
            return
        ensure_clean(name, data)
        self.zip.writestr(name, data)
        self.names.add(name)
        self.files.append({'bundle_path': name, 'source_relative': source,
                           'original_sha256': original_hash, 'export_sha256': sha(data),
                           'export_bytes': len(data), 'transformation': transformation})

    def add_file(self, path, name):
        path = Path(path)
        data, transformation = portable_bytes(path)
        self.add_bytes(name, data, relative(path), sha(path.read_bytes()), transformation)

    def add_json(self, name, value):
        self.add_bytes(name, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


def dataset_integrity():
    result = {'hash_policy': 'Raw source hashes verify original bytes; label_normalized_lf_sha256 ignores OS newline convention.',
              'split_policy': 'Use listed membership exactly; do not redraw a random split.', 'datasets': {}}
    neu = read_json(ROOT / 'data/neu_yolo/manifest.json')
    pcb = read_json(ROOT / 'data/deeppcb_yolo/manifest.json')
    specs = {'neu': (neu, ['crazing', 'inclusion', 'patches', 'pitted_surface', 'rolled-in_scale', 'scratches']),
             'deeppcb': (pcb['rows'], pcb['classes'])}
    for dataset, (rows, names) in specs.items():
        output = []
        for row in rows:
            identity = Path(row['filename']).stem if dataset == 'neu' else row['id']
            raw_image = (ROOT / 'data/raw/NEU-DET/IMAGES' / row['filename']) if dataset == 'neu' else Path(row['image'])
            annotation = (ROOT / 'data/raw/NEU-DET/ANNOTATIONS' / f'{identity}.xml') if dataset == 'neu' else Path(row['annotation'])
            label = ROOT / 'data' / f'{dataset}_yolo/labels' / row['split'] / f'{identity}.txt'
            normalized = label.read_text(encoding='utf-8').replace('\r\n', '\n').encode()
            record = {'id': identity, 'split': row['split'], 'raw_image': relative(raw_image),
                      'raw_annotation': relative(annotation), 'image_file_sha256': sha(raw_image.read_bytes()),
                      'raw_annotation_sha256': sha(annotation.read_bytes()),
                      'decoded_sha256': row['pixel_sha256'] if dataset == 'neu' else row['sha256_decoded'],
                      'original_label_sha256': sha(label.read_bytes()), 'label_normalized_lf_sha256': sha(normalized)}
            if dataset == 'deeppcb':
                record.update(group=row['group'], official_split=row['official_split'])
            output.append(record)
        result['datasets'][dataset] = {'classes': names, 'counts': dict(Counter(r['split'] for r in rows)), 'rows': output}
    return result


def data_sources():
    neu = read_json(ROOT / 'data/raw/neu_provenance.json')
    pcb = read_json(ROOT / 'data/raw/provenance.json')
    weights = read_json(ROOT / 'models/provenance.json')
    return {
        'neu': {'source': neu['source_page'], 'download_url': neu['download_url'],
                'download_target': 'data/raw/NEU-DET.zip', 'archive_or_checkpoint_sha256': neu['sha256'],
                'bytes': neu['bytes'], 'retrieved_utc': neu['retrieved_utc'],
                'license_note': 'No separate dataset redistribution license was verified in the downloaded NEU archive; obtain data from its author. No raw data redistributed here.'},
        'deeppcb': {'source': 'https://github.com/tangsanli5201/DeepPCB', 'download_url': pcb['url'],
                    'download_target': 'data/raw/DeepPCB-master.zip', 'archive_or_checkpoint_sha256': pcb['sha256'],
                    'bytes': pcb['bytes'], 'retrieved_utc': pcb['retrieved_utc'],
                    'license_note': 'Repository LICENSE is MIT; dataset README separately states research purpose only. The MIT software license must not be assumed to override the dataset restriction.'},
        'pretrained': {'source': 'https://github.com/ultralytics/assets', 'download_url': weights['url'],
                       'download_target': 'models/yolo11n.pt', 'archive_or_checkpoint_sha256': weights['sha256'],
                       'bytes': weights['bytes'], 'license_note': 'Follow upstream Ultralytics terms; no weights redistributed in this package.'},
        'software': {'ultralytics': '8.4.144', 'license_observed_in_installed_metadata': 'AGPL-3.0',
                     'license_source': 'https://github.com/ultralytics/ultralytics/blob/main/LICENSE',
                     'python_recorded': '3.12.11', 'torch_recorded': '2.7.1+cu128',
                     'platform_recorded': 'Windows, NVIDIA GeForce RTX 5060, 8 GB'},
        'publication_status': 'Local supplementary archive prepared for review; no public repository or data deposition is claimed.',
        'project_script_rights': 'No new blanket license is assigned by this archive. Upstream rights and notices remain applicable; authors must establish compatible release terms before public distribution.'}


def geometry_distribution():
    """Unlinked aggregate distributions only, without boxes or annotation coordinates."""
    import numpy as np
    result = {'policy': 'Training labels; identical lines within each image counted once, as in make_sci_figures.py. Only aggregate shortest-side frequencies are exported.', 'datasets': {}}
    for dataset in ('neu_yolo', 'deeppcb_yolo'):
        wh = []
        for path in sorted((ROOT / 'data' / dataset / 'labels/train').glob('*.txt')):
            wh.extend([list(map(float, line.split()))[3:5] for line in set(path.read_text().splitlines())])
        wh = np.asarray(wh) * 320
        values, counts = np.unique(wh.min(1), return_counts=True)
        result['datasets'][dataset] = {'boxes': len(wh), 'shorter_side_px': values.tolist(),
            'frequency': counts.tolist(), 'small_fraction_percent': float(100 * np.mean(wh.prod(1) < 32**2))}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=OUT / 'supplementary_code_data.zip')
    parser.add_argument('--require-complete', action='store_true')
    parser.add_argument('--prediction-budget-mb', type=float, default=75)
    args = parser.parse_args()
    plan = read_json(OUT / 'confirmation_plan.json')
    test_plan = read_json(OUT / 'test_analysis_plan.json')
    plan_sha256 = sha((OUT / 'confirmation_plan.json').read_bytes())
    assert test_plan['matrix_plan_sha256'] == plan_sha256, 'Frozen plan hash changed'
    history = read_json(ROOT / 'reports/publication/supplement_catalog.json')
    mains = {(ROOT / job['run']).resolve(): job for job in plan['jobs']}
    historical = {Path(record['source']).resolve().parent: record for record in history}
    runs = sorted(set(mains) | set(historical))
    assert len(mains) == 24 and len(historical) == 27 and len(runs) == 47
    assert len(set(mains) & set(historical)) == 4
    pending, records, predictions = [], [], {}
    for run in runs:
        main_job = mains.get(run)
        if main_job:
            required = ['val', 'test'] + (['test_source_seen', 'test_source_unseen'] if main_job['dataset'] == 'deeppcb' else [])
            pending.extend({'run': relative(run), 'split': split} for split in required if not (run / f'{split}_summary.json').exists())
        summaries = []
        for path in sorted(run.glob('*_summary.json')):
            summary = read_json(path)
            summaries.append(path)
            prediction = Path(summary['evaluation_dir']) / 'predictions.json'
            if prediction.exists():
                priority = 0 if main_job and path.name == 'test_summary.json' else 1 if main_job else 2
                predictions[prediction.resolve()] = min(priority, predictions.get(prediction.resolve(), priority))
        assert (run / 'args.yaml').exists() and (run / 'results.csv').exists() and summaries, relative(run)
        records.append({'run': relative(run), 'stage': 'main' if main_job else 'exploratory_only',
                        'also_in_historical_27': run in historical, 'summary_files': [p.name for p in summaries]})
    if args.require_complete:
        assert not pending, f'{len(pending)} main evaluations remain'
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix('.building.tmp')
    bundle = Bundle(temporary)
    try:
        snapshot = OUT / 'source_snapshot_20260913'
        for name, expected in plan['source_hashes'].items():
            source = snapshot / name
            assert sha(source.read_bytes()) == expected, name
            bundle.add_file(source, 'frozen_source/' + name)
        support = ['download_neu.py', 'download_weights.py', 'evaluate_confirmation.py', 'evaluate_source_groups.py',
                   'collect_confirmation.py', 'check_phase.py', 'check_head_detail.py', 'check_innovation.py',
                   'audit_confirmation_integrity.py', 'make_submission_tables.py', 'make_submission_figures.py',
                   'make_sci_figures.py', 'profile_submission_resources.py', 'benchmark_supplement.py']
        for name in support:
            bundle.add_file(ROOT / name, 'support_source/' + name)
        bundle.add_file(Path(__file__), 'support_source/build_submission_bundle.py')
        for path in sorted((OUT / 'reproducibility_tools').glob('*.py')):
            bundle.add_file(path, 'tools/' + path.name)
        bundle.add_file(OUT / 'reproducibility_README.md', 'README.md')
        for name in ['confirmation_plan.json', 'test_analysis_plan.json']:
            bundle.add_file(OUT / name, 'plans/' + name)
        for dataset in ['neu', 'deeppcb']:
            bundle.add_file(ROOT / 'data' / f'{dataset}_yolo/manifest.json', f'data/{dataset}_yolo/manifest.json')
        bundle.add_file(ROOT / 'data/neu_yolo/audit.json', 'data/neu_yolo/audit.json')
        bundle.add_json('data/data_integrity.json', dataset_integrity())
        bundle.add_json('data/data_sources.json', data_sources())
        bundle.add_json('catalogs/training_geometry_distribution.json', geometry_distribution())
        bundle.add_file(ROOT / 'data/raw/DeepPCB-master/LICENSE', 'licenses/DeepPCB_MIT.txt')
        license_file = next((ROOT / '.venv/Lib/site-packages/ultralytics-8.4.144.dist-info').rglob('LICENSE'))
        # Store a public package identifier instead of an environment directory in provenance.
        license_data = license_file.read_bytes()
        bundle.add_bytes('licenses/ultralytics_AGPL-3.0.txt', license_data,
                         'installed-package:ultralytics-8.4.144/LICENSE', sha(license_data), 'none')
        notice = ('DeepPCB official README, Notification section:\n'
                  'https://github.com/tangsanli5201/DeepPCB\n\n'
                  '"You can only use this dataset for research purpose."\n\n'
                  'This dataset statement is separate from the repository MIT software license.\n')
        bundle.add_bytes('licenses/DeepPCB_dataset_notice.txt', notice.encode())
        for run in runs:
            for path in [run / 'args.yaml', run / 'results.csv', *sorted(run.glob('*_summary.json'))]:
                bundle.add_file(path, 'records/' + relative(path))
        # Snapshot metric catalogs as available; status below is computed directly from run files.
        for path in [ROOT / 'reports/publication/supplement_catalog.json', OUT / 'confirmation_results.json',
                     ROOT / 'reports/publication/supplement_latency.json', ROOT / 'reports/publication/phase_checks.json',
                     ROOT / 'reports/publication/head_detail_checks.json', ROOT / 'reports/publication/phase_operator_checks.json',
                     OUT / 'resource_profile.json', OUT / 'numerical_integrity_audit.json']:
            if path.exists():
                bundle.add_file(path, 'catalogs/' + path.name)
        included, omitted, compressed_predictions = [], [], 0
        budget = int(args.prediction_budget_mb * 1024 * 1024)
        import zlib
        for path, priority in sorted(predictions.items(), key=lambda pair: (pair[1], str(pair[0]))):
            data, transformation = portable_bytes(path)
            estimate = len(zlib.compress(data, 9))
            item = {'source_relative': relative(path), 'original_sha256': sha(path.read_bytes()),
                    'uncompressed_bytes': len(data), 'priority': priority}
            if compressed_predictions + estimate > budget:
                omitted.append({**item, 'reason': 'Compressed prediction budget exceeded; metric summaries retained.'})
                continue
            destination = 'predictions/' + relative(path)
            bundle.add_bytes(destination, data, relative(path), item['original_sha256'], transformation)
            included.append({**item, 'bundle_path': destination})
            compressed_predictions += estimate
        status = {'built_utc': datetime.now(timezone.utc).isoformat(), 'main_training_runs': 24,
                  'historical_catalog_runs': 27, 'overlap_runs': 4, 'exploratory_only_runs': 23,
                  'unique_training_runs': 47, 'main_evaluations_complete': not pending, 'pending_main_evaluations': pending,
                  'main_evaluations_expected': 72, 'main_evaluations_present': 72 - len(pending),
                  'original_confirmation_plan_sha256': plan_sha256, 'source_snapshot_hashes_verified': True,
                  'status': 'complete main evaluations' if not pending else 'draft: evaluations still pending',
                  'runs': records, 'predictions_included': included, 'predictions_omitted': omitted,
                  'exclusions': ['raw images and annotations', 'dataset archives', 'checkpoints and pretrained weights',
                                 'virtual environment', 'credentials', 'author information', 'cached journal articles'],
                  'notes': ['Included prediction tables are model outputs, not official raw annotations.',
                            'A metric catalog may be an earlier snapshot; individual run records and pending list are authoritative.']}
        bundle.add_json('bundle_status.json', status)
        manifest = {'format_version': 1, 'workspace_mapping': {'<WORKSPACE>': 'original experiment workspace (local prefix removed)'},
                    'path_rule': 'source_relative identifiers refer to original workspace; exported records use records/ and predictions/ prefixes.',
                    'hash_rule': 'original_sha256 preserves original bytes provenance; export_sha256 verifies the portable copy. Null source/hash denotes generated metadata.',
                    'frozen_source_rule': 'Frozen training source copies are byte-identical to the confirmation plan hashes.',
                    'files': bundle.files}
        manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
        ensure_clean('bundle_manifest.json', manifest_bytes)
        bundle.zip.writestr('bundle_manifest.json', manifest_bytes)
    finally:
        bundle.zip.close()
    assert temporary.stat().st_size < 100_000_000, 'Supplement must be below 100 MB'
    with zipfile.ZipFile(temporary) as archive:
        assert archive.testzip() is None
        verified = read_json_bytes(archive.read('bundle_manifest.json'))
        for item in verified['files']:
            data = archive.read(item['bundle_path'])
            assert sha(data) == item['export_sha256']
            ensure_clean(item['bundle_path'], data)
        assert len(archive.namelist()) == len(set(archive.namelist()))
    temporary.replace(output)
    audit = {'zip_filename': output.name, 'zip_bytes': output.stat().st_size, 'zip_sha256': sha(output.read_bytes()),
             'entries': len(bundle.files) + 1, 'all_zip_crcs_valid': True, 'all_export_hashes_valid': True,
             'allowlist_and_sensitive_path_scan_passed': True, 'unique_training_runs': 47,
             'main_training_runs': 24, 'main_evaluations_present': 72 - len(pending),
             'original_confirmation_plan_sha256': plan_sha256, 'source_snapshot_hashes_verified': True,
             'main_evaluations_complete': not pending, 'pending_count': len(pending),
             'prediction_files_included': len(included), 'prediction_files_omitted': len(omitted)}
    (OUT / 'bundle_audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit, indent=2))


def read_json_bytes(data):
    return json.loads(data.decode('utf-8'))


if __name__ == '__main__':
    main()
