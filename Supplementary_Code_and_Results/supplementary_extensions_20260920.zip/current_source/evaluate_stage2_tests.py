"""Evaluate every frozen stage-two model after the validation matrix is complete."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'
os.environ.setdefault('YOLO_CONFIG_DIR',str(ROOT/'.yolo_config'))


def main():
    plan=json.loads((OUT/'plan.json').read_text())
    test_plan=json.loads((OUT/'test_plan.json').read_text())
    for source,expected in test_plan['source_hashes'].items():
        assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest()==expected,source
    assert test_plan['jobs']==[j['id'] for j in plan['jobs']]
    missing=[j['id'] for j in plan['jobs'] if not (ROOT/j['run']/'val_summary.json').exists()]
    assert not missing,f'Validation matrix incomplete: {len(missing)} jobs'
    state=json.loads((OUT/'state.json').read_text())
    assert not state['failures'] and len(state['completed'])==39
    status={'total':39,'completed':[],'active':None,'failures':[]}
    def save():
        tmp=OUT/'test_state.tmp';tmp.write_text(json.dumps(status,indent=2));tmp.replace(OUT/'test_state.json')
    for job in plan['jobs']:
        target=ROOT/job['run']/'posthoc_test_summary.json'
        if target.exists():
            assert json.loads(target.read_text())['job']==job
            status['completed'].append(job['id']);continue
        status['active']=job['id'];save()
        cmd=[sys.executable,'run_stage2_test_job.py','--job',job['id']]
        with (OUT/(job['id']+'_test.log')).open('a',encoding='utf-8') as log:
            code=subprocess.call(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if code or not target.exists():
            status['failures'].append({'job':job['id'],'exit_code':code});save()
            raise SystemExit('Stopped on test-evaluation failure.')
        status['completed'].append(job['id']);status['active']=None;save()
        print(f'Test {len(status["completed"])}/39: '+job['id'],flush=True)
    status['status']='all frozen stage-two models evaluated on reused tests';save()


if __name__=='__main__':main()
