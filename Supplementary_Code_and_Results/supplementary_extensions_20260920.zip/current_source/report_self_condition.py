"""Report the frozen phase-versus-phase-self mechanism screen."""
import json
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/self_condition"


def main():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    records = []
    for job in plan["jobs"]:
        candidate = json.loads(
            (ROOT / job["run"] / "val_summary.json").read_text(encoding="utf-8")
        )
        control = json.loads(
            (ROOT / job["phase_control"] / "val_summary.json").read_text(
                encoding="utf-8"
            )
        )
        candidate_ap = 100.0 * candidate["metrics"]["metrics/mAP50-95(B)"]
        control_ap = 100.0 * control["metrics"]["metrics/mAP50-95(B)"]
        records.append(
            {
                "job": job,
                "phase_map5095": control_ap,
                "phase_self_map5095": candidate_ap,
                "phase_minus_self_pp": control_ap - candidate_ap,
            }
        )

    summary = {}
    for dataset in sorted({record["job"]["dataset"] for record in records}):
        subset = [
            record for record in records if record["job"]["dataset"] == dataset
        ]
        values = [record["phase_minus_self_pp"] for record in subset]
        summary[dataset] = {
            "per_seed_pp": {
                str(record["job"]["seed"]): record["phase_minus_self_pp"]
                for record in subset
            },
            "mean_pp": statistics.fmean(values),
            "sample_sd_pp": statistics.stdev(values),
            "positive_seeds": sum(value > 0.0 for value in values),
        }

    gate = plan["gate"]
    passed = (
        all(result["mean_pp"] >= gate["both_datasets_min_pp"] for result in summary.values())
        and any(
            result["mean_pp"] >= gate["at_least_one_dataset_min_pp"]
            for result in summary.values()
        )
    )
    result = {
        "records": records,
        "summary": summary,
        "gate": {"passed": passed, **gate},
    }
    (OUT / "results.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    lines = [
        "# P2自条件机制消融",
        "",
        "比较 `phase - phase_self`，均为验证集、320输入、120轮、同训练种子。",
        "",
        "|数据集|逐种子差值(pp)|均值±样本SD(pp)|正向种子|",
        "|---|---|---:|---:|",
    ]
    for dataset, values in sorted(summary.items()):
        per_seed = ", ".join(
            f"{value:+.3f}" for value in values["per_seed_pp"].values()
        )
        lines.append(
            f"|{dataset}|{per_seed}|"
            f"{values['mean_pp']:+.3f} ± {values['sample_sd_pp']:.3f}|"
            f"{values['positive_seeds']}/3|"
        )
    lines.extend(
        [
            "",
            f"冻结门槛结果：{'支持' if passed else '不支持'}。",
            "",
            "支持要求两个数据集均不下降，且至少一个数据集平均提高0.5个百分点。",
            "本轮只报告验证集，不根据该门槛扩展测试集或补其他随机种子。",
        ]
    )
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(result["gate"], indent=2))


if __name__ == "__main__":
    main()
