"""Package extension evidence separately from the original main-study archive."""
import json, zipfile
from pathlib import Path
from build_submission_bundle import Bundle, sha, ensure_clean

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/submission'
def main():
    target=OUT/'supplementary_extensions_20260920.zip'
    temporary=target.with_suffix('.building.tmp')
    bundle=Bundle(temporary); stages={}
    try:
        for stage in ('stage2','budget_experiment','frontier','alignment','microshift','multiscale_experiment','self_condition','context_experiment','head_detail_experiment','subgroups','matched_condition'):
            folder=ROOT/'reports'/stage
            plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
            for p in sorted(folder.iterdir()):
                if p.is_file() and p.suffix in ('.json','.md') or (p.is_file() and p.name == 'installed_packages.txt'):
                    bundle.add_file(p,p.relative_to(ROOT).as_posix())
            for p in sorted((folder/'source_snapshot').rglob('*')):
                if p.is_file() and p.suffix in ('.py','.json','.txt','.yaml'):
                    bundle.add_file(p,p.relative_to(ROOT).as_posix())
            jobs=plan.get('jobs',[]); count=0
            for j in jobs:
                if not isinstance(j,dict) or 'run' not in j: continue
                run=ROOT/j['run']
                assert (run/'val_summary.json').exists(),run
                for p in [run/'args.yaml',run/'results.csv',*sorted(run.glob('*summary.json'))]:
                    if p.exists(): bundle.add_file(p,p.relative_to(ROOT).as_posix())
                count+=1
                if j.get('phase_control'):
                    p=ROOT/j['phase_control']/'val_summary.json'
                    bundle.add_file(p,p.relative_to(ROOT).as_posix())
            stages[stage]={'planned_jobs_with_run':count,'scope':'saved plans and metric records; no rerun or independent confirmation'}
        prefixes=('stage2','budget','frontier','alignment','microshift','multiscale','self_condition','context','head_detail','subgroup','matched_condition')
        for p in ROOT.glob('*.py'):
            if any(word in p.stem for word in prefixes) or p.name in ('phase_modules.py','export_stage2_evidence.py','audit_negative_validation.py','build_extension_bundle.py','build_submission_bundle.py'):
                bundle.add_file(p,'current_source/'+p.name)
        for name in ('manuscript.md','supplementary_information.md','extension_supplement.md','stage2_complete_tables.md','stage2_table_provenance.json','evidence_index_20260920.md','update_record_20260920.md','pdf_qa_20260920.md','omitted_stage_addendum_20260920.md','method_consistency_audit_20260920.md','numeric_audit_20260920.md','numeric_audit_20260920.json','negative_numeric_audit_20260920.md','negative_numeric_audit_20260920.json','citation_audit_20260920.md','claim_citation_audit_20260920.md','internal_claim_evidence_audit_20260922.md'):
            p=OUT/name; bundle.add_file(p,'manuscript_records/'+name)
        bundle.add_bytes('README.md',('''# Extension evidence archive

Use alongside the original supplementary_code_data.zip, which covers the main study.
This archive contains subsequent exploratory plans, metric summaries, training histories,
current support code, and available frozen snapshots. It excludes images, annotations,
weights, full prediction arrays, and full console logs. All omitted originals remain local.
It is not a self-contained runnable environment or a claim of independent replication.
Do not launch queues merely to inspect this archive.

Current_source is a packaging-time copy; plan hashes and stage snapshots govern training
provenance. Source hashes are recorded before path portability transformations. Differences
between original and export hashes are documented in the manifest. Do not substitute
portable plan bytes for the original frozen plan hash. See execution notes for environment
changes and recovery. Known test reuse and failed candidates remain disclosed.

PDFs are distributed separately. Author declarations and final release rights still need
author confirmation; this local archive assigns no new software or dataset license.
''').encode())
        bundle.add_json('stage_inventory.json',stages)
        manifest={'files':bundle.files,'exclusions':['images','raw annotations','weights','full predictions','console logs'],'status':'local extension evidence; not submission-ready certification'}
        data=json.dumps(manifest,indent=2,ensure_ascii=False).encode()
        ensure_clean('manifest.json',data); bundle.zip.writestr('manifest.json',data)
    finally: bundle.zip.close()
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        for item in manifest['files']:
            data=z.read(item['bundle_path']); assert sha(data)==item['export_sha256']; ensure_clean(item['bundle_path'],data)
    temporary.replace(target)
    audit=dict(file=target.name,bytes=target.stat().st_size,sha256=sha(target.read_bytes()),entries=len(manifest['files'])+1,crc_valid=True,export_hashes_valid=True,stages=stages)
    (OUT/'extension_bundle_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2))
if __name__=='__main__': main()
