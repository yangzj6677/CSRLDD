"""Train or resume one frozen parallel-scale phase job."""
import argparse
import csv
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/multiscale_experiment"
os.environ.setdefault("YOLO_CONFIG_DIR", str(ROOT / ".yolo_config"))

import torch
from ultralytics import YOLO
from multiscale_modules import MultiScaleTrainer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    args = parser.parse_args()
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    job = next(item for item in plan["jobs"] if item["id"] == args.job)
    for path, expected in plan["source_hashes"].items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == expected, path
    torch.set_num_threads(4)
    assert torch.cuda.is_available()
    run = ROOT / job["run"]
    if (run / "val_summary.json").exists():
        raise RuntimeError("Completed run must not be overwritten")
    MultiScaleTrainer.variant = job["variant"]
    MultiScaleTrainer.init_seed = job["init_seed"]
    started = time.time()
    rows = (
        list(csv.DictReader((run / "results.csv").open()))
        if (run / "results.csv").exists()
        else []
    )
    if rows and int(rows[-1]["epoch"]) >= job["epochs"] and (run / "weights/best.pt").exists():
        pass
    elif (run / "weights/last.pt").exists():
        model = YOLO(str(run / "weights/last.pt"))
        model.train(trainer=MultiScaleTrainer, resume=True, device=0, workers=0)
    else:
        assert not run.exists(), f"Incomplete run without resumable weights: {run}"
        model = YOLO(str(ROOT / "models/yolo11n.pt"))
        model.train(
            trainer=MultiScaleTrainer,
            data=str(ROOT / "data" / f"{job['dataset']}_yolo/data.yaml"),
            epochs=job["epochs"],
            imgsz=job["imgsz"],
            batch=16,
            device=0,
            workers=0,
            seed=job["seed"],
            deterministic=True,
            optimizer="AdamW",
            lr0=0.001,
            patience=0,
            amp=False,
            cache=False,
            project=str(run.parent),
            name=run.name,
            exist_ok=False,
            plots=False,
            hsv_h=0,
            hsv_s=0,
            hsv_v=0.2,
            close_mosaic=5,
        )
        assert Path(model.trainer.save_dir).resolve() == run.resolve()
    best = YOLO(str(run / "weights/best.pt"))
    assert best.model.refinement_variant == job["variant"]
    assert best.ckpt["train_args"]["seed"] == job["seed"]
    assert best.ckpt["train_args"]["imgsz"] == job["imgsz"]
    metrics = best.val(
        data=str(ROOT / "data" / f"{job['dataset']}_yolo/data.yaml"),
        split="val",
        imgsz=job["imgsz"],
        batch=16,
        device=0,
        workers=0,
        plots=False,
        save_json=True,
        project=str(run.parent),
        name=run.name + "_val",
        exist_ok=False,
    )
    result = {
        "job": job,
        "split": "val",
        "metrics": metrics.results_dict,
        "per_class": metrics.summary(),
        "elapsed_seconds_this_invocation": time.time() - started,
        "checkpoint_sha256": hashlib.sha256((run / "weights/best.pt").read_bytes()).hexdigest(),
        "source_hashes": plan["source_hashes"],
        "evaluation_dir": str(metrics.save_dir),
        "plan_sha256": hashlib.sha256((OUT / "plan.json").read_bytes()).hexdigest(),
    }
    (run / "val_summary.json").write_text(
        json.dumps(result, indent=2, default=str), encoding="utf-8"
    )
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
