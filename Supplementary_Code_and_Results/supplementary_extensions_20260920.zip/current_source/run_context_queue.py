"""Serial immutable queue for the P4-context condition screen."""
import csv
import hashlib
import json
import msvcrt
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/context_experiment"


def main():
    lock = (OUT / "queue.lock").open("a+b")
    lock.seek(0)
    lock.write(b"0")
    lock.flush()
    lock.seek(0)
    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    for path, expected in plan["source_hashes"].items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == expected, path
    state = {
        "status": "starting",
        "total": len(plan["jobs"]),
        "completed": [],
        "active": None,
        "failures": [],
        "pid": os.getpid(),
    }

    def save():
        state["updated_utc"] = datetime.now(timezone.utc).isoformat()
        temporary = OUT / f"state.{os.getpid()}.tmp"
        temporary.write_text(json.dumps(state, indent=2), encoding="utf-8")
        for attempt in range(10):
            try:
                temporary.replace(OUT / "state.json")
                return
            except PermissionError:
                if attempt == 9:
                    raise
                time.sleep(0.2 * (attempt + 1))

    try:
        for job in plan["jobs"]:
            run = ROOT / job["run"]
            target = run / "val_summary.json"
            if target.exists():
                summary = json.loads(target.read_text(encoding="utf-8"))
                assert summary["job"] == job
                state["completed"].append(job["id"])
                continue
            if run.exists() and not (run / "weights/last.pt").exists():
                raise RuntimeError(f"Incomplete checkpointless run: {run}")
            state.update(status="running", active=job["id"])
            save()
            with (OUT / f"{job['id']}.log").open("a", encoding="utf-8") as log:
                process = subprocess.Popen(
                    [
                        sys.executable,
                        str(ROOT / "run_context_job.py"),
                        "--job",
                        job["id"],
                    ],
                    cwd=ROOT,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                )
                state["child_pid"] = process.pid
                save()
                try:
                    code = process.wait(timeout=12 * 3600)
                except subprocess.TimeoutExpired:
                    state["failures"].append(
                        {
                            "job": job["id"],
                            "reason": "12h timeout; child left running for inspection",
                        }
                    )
                    state.update(status="timeout")
                    save()
                    return 1
            if code or not target.exists():
                state["failures"].append(
                    {"job": job["id"], "exit_code": code}
                )
                state.update(status="failed")
                save()
                return 1
            state["completed"].append(job["id"])
            state.update(active=None, child_pid=None)
            save()
        state.update(status="complete_validation_screen", active=None)
        save()
    except Exception as error:
        state["failures"].append({"reason": repr(error)})
        state.update(status="failed")
        save()
        raise
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
