"""Evaluate one frozen budget model on a previously known fixed test split."""
import argparse
import hashlib
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/budget_experiment'
os.environ.setdefault('YOLO_CONFIG_DIR',str(ROOT/'.yolo_config'))
from ultralytics import YOLO
import budget_modules  # required when loading serialized custom modules

p=argparse.ArgumentParser()
p.add_argument('--job',required=True)
a=p.parse_args()
plan=json.loads((OUT/'plan.json').read_text())
test_plan=json.loads((OUT/'test_plan.json').read_text())
for source,expected in test_plan['source_hashes'].items():
    assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest()==expected,source
job=next(j for j in plan['jobs'] if j['id']==a.job)
assert job['id'] in test_plan['jobs']
run=ROOT/job['run']
best=run/'weights/best.pt'
assert (run/'val_summary.json').exists() and best.exists()
target=run/'posthoc_test_summary.json'
assert not target.exists(),'Completed test evaluation must not be overwritten'
model=YOLO(str(best))
assert model.model.refinement_variant==job['variant']
assert model.model.branch_init_seed==job['init_seed']
data=ROOT/'data'/f"{job['dataset']}_yolo/data.yaml"
metrics=model.val(data=str(data),split='test',imgsz=job['imgsz'],batch=16,device=0,
                  workers=0,plots=False,save_json=True,project=str(ROOT/'runs/budget_tests'),
                  name=job['id'],exist_ok=False)
result={'job':job,'split':'test','known_test_reuse':True,
        'metrics':metrics.results_dict,'per_class':metrics.summary(),
        'checkpoint_sha256':hashlib.sha256(best.read_bytes()).hexdigest(),
        'test_plan_sha256':hashlib.sha256((OUT/'test_plan.json').read_bytes()).hexdigest(),
        'evaluation_dir':str(metrics.save_dir)}
target.write_text(json.dumps(result,indent=2,default=str))
print(json.dumps(result,indent=2,default=str))
