"""Freeze the all-model test evaluation before any new-model test result exists."""
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/budget_experiment'
target=OUT/'test_plan.json'
assert not target.exists(),'Do not overwrite frozen test plan'
plan=json.loads((OUT/'plan.json').read_text())
files=('budget_modules.py','run_budget_test_job.py','evaluate_budget_tests.py',
       'reports/budget_experiment/plan.json','data/neu_yolo/data.yaml',
       'data/deeppcb_yolo/data.yaml')
record={'created_utc':datetime.now(timezone.utc).isoformat(),
        'jobs':[j['id'] for j in plan['jobs']],
        'gate':'Evaluate every model only after all 24 validation summaries exist',
        'selection':'Best validation-fitness EMA checkpoint fixed by the training plan',
        'endpoint':'pooled fixed-test mAP50-95; mAP50, mAP75 and per-class AP auxiliary',
        'disclosure':'Both benchmark tests were known before this mechanism was designed; results are posthoc confirmation, not untouched external validation',
        'reporting':'Report every seed and unfavorable result; no test-driven model or rho selection',
        'source_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files}}
target.write_text(json.dumps(record,indent=2))
print('Frozen test plan for',len(record['jobs']),'jobs')
