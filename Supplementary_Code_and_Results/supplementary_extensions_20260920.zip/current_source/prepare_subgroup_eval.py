"""Freeze a validation/test subgroup-recall analysis of the main model matrix."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/subgroups"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    confirmation = json.loads(
        (ROOT / "reports/submission/confirmation_plan.json").read_text(
            encoding="utf-8"
        )
    )
    models = []
    for job in confirmation["jobs"]:
        if job["variant"] not in {"baseline", "plain", "phase_uniform", "phase"}:
            continue
        checkpoint = ROOT / job["run"] / "weights/best.pt"
        assert checkpoint.exists(), checkpoint
        assert (ROOT / job["run"] / "val_summary.json").exists()
        assert (ROOT / job["run"] / "test_summary.json").exists()
        models.append(job)

    assert len(models) == 24
    sources = {
        "prepare_subgroup_eval.py",
        "run_subgroup_eval.py",
        "report_subgroup_eval.py",
        "reports/submission/confirmation_plan.json",
        "reports/publication/training_geometry.json",
        "data/neu_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/data.yaml",
        "data/deeppcb_yolo/manifest.json",
    }
    sources.update(job["run"] + "/weights/best.pt" for job in models)
    raw_geometry = json.loads(
        (ROOT / "reports/publication/training_geometry.json").read_text(
            encoding="utf-8"
        )
    )
    geometry = {
        key.removesuffix("_yolo"): values
        for key, values in raw_geometry.items()
    }
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "subgroup_recall_diagnostic",
        "models": models,
        "splits": ["val", "test"],
        "reference_input": 320,
        "groups": {
            "all": "all ground-truth boxes",
            "narrow": "shorter reference side <= training 10th-percentile threshold",
            "elongated": "reference aspect ratio >= training 90th-percentile threshold",
            "narrow_or_elongated": "union of narrow and elongated",
            "small_area": "reference box area < 32^2 px^2",
            "other": "boxes in none of the narrow, elongated, or small-area groups",
        },
        "thresholds": {
            dataset: {
                "narrow_min_side_px": values["frozen_narrow_threshold_px"],
                "elongated_aspect_ratio": values[
                    "frozen_elongated_aspect_threshold"
                ],
            }
            for dataset, values in geometry.items()
        },
        "protocol": {
            "imgsz": 320,
            "confidence": 0.25,
            "iou_nms": 0.7,
            "max_det": 300,
            "batch": 16,
            "matching": "class-aware one-to-one greedy matching by descending IoU",
            "metrics": [
                "recall_at_iou_50",
                "recall_at_iou_75",
                "mean_best_iou",
            ],
            "selection": "all frozen main-matrix checkpoints retained",
        },
        "primary_comparison": {
            "left": "phase",
            "right": "phase_uniform",
            "group": "narrow_or_elongated",
            "metric": "recall_at_iou_50",
        },
        "gate": {
            "both_datasets_min_mean_delta_pp": 0.5,
            "minimum_positive_seeds_per_dataset": 2,
            "require_both_datasets": True,
        },
        "disclosure": {
            "val": "development split used for checkpoint selection",
            "test": "post-hoc analysis of already frozen main-matrix test summaries",
            "thresholds": "derived only from training geometry before this analysis",
            "not_ap": "subgroup recall does not replace the primary mAP50-95 endpoint",
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sorted(sources)
        },
        "caveats": [
            "three training seeds are paired runs, not independent image samples",
            "box geometry is not defect contrast, width, or causal difficulty",
            "small-area NEU groups may contain too few boxes for stable interpretation",
            "predictions use a fixed confidence threshold and are not full AP",
            "test results are post-hoc and do not restore independent confirmation",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen subgroup diagnostic for {len(models)} checkpoints")


if __name__ == "__main__":
    main()
