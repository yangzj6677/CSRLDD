"""Read-only arithmetic audit of saved validation summaries; no inference."""
import json,hashlib,statistics
from pathlib import Path
sources={};rows=[]
def read(p):
 p=Path(p);b=p.read_bytes();sources[p.as_posix()]=hashlib.sha256(b).hexdigest();return json.loads(b)
def ap(run):return 100*read(Path(run)/'val_summary.json')['metrics']['metrics/mAP50-95(B)']
def check(stage,dataset,label,ds,expected,sdkey):
 mean=statistics.mean(ds);sd=statistics.stdev(ds)
 assert abs(mean-expected['mean_pp'])<1e-10 and abs(sd-expected[sdkey])<1e-10
 rows.append(dict(stage=stage,dataset=dataset,contrast=label,seed_order=[42,43,44],differences_pp=ds,mean_pp=mean,sample_sd_pp=sd,negative_seeds=sum(x<0 for x in ds)))
p=read('reports/multiscale_experiment/plan.json');r=read('reports/multiscale_experiment/results.json')
v={(j['dataset'],j['variant'],j['seed']):ap(j['run']) for j in p['jobs']}
for d in ['deeppcb','neu']:
 controls={j['seed']:ap(j['phase_control']) for j in p['jobs'] if j['dataset']==d}
 for label,c in [('msd_minus_phase',controls),('msd_minus_control',{s:v[d,'phase_msd_control',s] for s in [42,43,44]})]:
  check('multiscale',d,label,[v[d,'phase_msd',s]-c[s] for s in [42,43,44]],r['results'][d][label],'sample_sd_pp')
p=read('reports/budget_experiment/plan.json');r=read('reports/budget_experiment/results.json')
v={(j['dataset'],j['variant'],j['seed']):ap(j['run']) for j in p['jobs']+p['reused_reference_jobs']}
for c in r['paired_contrasts']:
 if c['split']!='val':continue
 d=c['dataset'];a=c['candidate'];b=c['control'];check('budget',d,a+' - '+b,[v[d,a,s]-v[d,b,s] for s in [42,43,44]],c,'sd_pp')
main=Path('reports/submission/manuscript.md').read_text(encoding='utf-8')
for r in rows:
 if r['stage']=='multiscale' or r['contrast']=='budget_full - phase':assert f"{abs(r['mean_pp']):.3f} ± {r['sample_sd_pp']:.3f}" in main
out=Path('reports/submission');(out/'negative_numeric_audit_20260920.json').write_text(json.dumps({'scope':'Validation arithmetic only, no independent experiment; test values not covered','contrasts':rows,'input_sha256':sources},indent=2),encoding='utf-8')
lines=['# 多尺度与预算验证数值核查','','Origin Skill: academic-research-suite。逐模型验证摘要重算，保留输入SHA256。未修改冻结文件，未重新推理。','',f'共{len(rows)}项比较与既有报告匹配（容差1e-10 pp）。正文引用的多尺度和预算full对phase均值/样本SD三位小数一致。','', '|阶段|数据集|比较|均值±样本SD（pp）|负向种子|','|---|---|---|---:|---:|']
for r in rows:lines.append(f"|{r['stage']}|{r['dataset']}|{r['contrast']}|{r['mean_pp']:+.3f} ± {r['sample_sd_pp']:.3f}|{r['negative_seeds']}/3|")
lines+=['','预算full对phase在NEU为2/3负向，不能写成所有种子下降；当前正文只写平均下降，符合结果。多尺度对phase两数据集各3/3负向。既有ars_validation.md的历史文字问题不改写原记录。','', '本核查不覆盖测试集数值、文献、时延或全部论文数值；不是独立重复实验。']
(out/'negative_numeric_audit_20260920.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('contrasts',len(rows),'inputs',len(sources))
