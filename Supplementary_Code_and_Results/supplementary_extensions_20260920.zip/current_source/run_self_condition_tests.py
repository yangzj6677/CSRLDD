"""Evaluate all frozen phase_self checkpoints on the fixed test splits."""
import hashlib
import json
import os
from pathlib import Path

import torch

os.environ.setdefault("YOLO_CONFIG_DIR", str(Path(__file__).resolve().parent / ".yolo_config"))
from ultralytics import YOLO

import phase_modules  # noqa: F401 - required when loading serialized custom modules


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/self_condition"


def main():
    torch.set_num_threads(4)
    plan = json.loads((OUT / "test_plan.json").read_text(encoding="utf-8"))
    for path, expected in plan["source_hashes"].items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == expected, path
    for job in plan["jobs"]:
        run = ROOT / job["run"]
        checkpoint = run / "weights/best.pt"
        target = run / "posthoc_test_summary.json"
        assert not target.exists(), f"Completed test must not be overwritten: {target}"
        model = YOLO(str(checkpoint))
        assert model.model.refinement_variant == "phase_self"
        data = ROOT / "data" / f"{job['dataset']}_yolo/data.yaml"
        metrics = model.val(
            data=str(data),
            split="test",
            imgsz=job["imgsz"],
            batch=16,
            device=0,
            workers=0,
            plots=False,
            save_json=True,
            project=str(ROOT / "runs/self_condition_tests"),
            name=job["id"],
            exist_ok=False,
        )
        result = {
            "job": job,
            "split": "test",
            "known_test_reuse": True,
            "metrics": metrics.results_dict,
            "per_class": metrics.summary(),
            "checkpoint_sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
            "test_plan_sha256": hashlib.sha256(
                (OUT / "test_plan.json").read_bytes()
            ).hexdigest(),
            "evaluation_dir": str(metrics.save_dir),
        }
        target.write_text(
            json.dumps(result, indent=2, default=str), encoding="utf-8"
        )
        print(f"completed {job['id']}", flush=True)


if __name__ == "__main__":
    main()
