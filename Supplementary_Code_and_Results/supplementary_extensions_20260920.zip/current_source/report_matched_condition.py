"""Report all contemporaneous condition-source pairs only after completion."""
import hashlib,json,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/matched_condition'
def main():
    plan=json.loads((OUT/'plan.json').read_text())
    state=json.loads((OUT/'state.json').read_text())
    assert state['status']=='complete_validation_screen' and not state['failures'], 'Queue incomplete or failed'
    for p,h in plan['source_hashes'].items(): assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    index={}; records=[]
    for j in plan['jobs']:
        p=ROOT/j['run']/'val_summary.json';r=json.loads(p.read_text())
        assert (r['dataset'],r['variant'],r['seed'],r['epochs'],r['split'],r['imgsz'])==(j['dataset'],j['variant'],j['seed'],120,'val',320)
        ap=100*r['metrics']['metrics/mAP50-95(B)'];index[j['dataset'],j['variant'],j['seed']]=ap
        records.append(dict(job=j,map5095=ap,summary_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    results={}
    for d in ('deeppcb','neu'):
        v=[index[d,'phase',s]-index[d,'phase_self',s] for s in (42,43,44)]
        results[d]=dict(differences_pp=v,mean_pp=statistics.mean(v),sample_sd_pp=statistics.stdev(v))
    passed=all(r['mean_pp']>=plan['gate']['both_datasets_min_pp'] for r in results.values()) and any(r['mean_pp']>=plan['gate']['at_least_one_dataset_min_pp'] for r in results.values())
    (OUT/'results.json').write_text(json.dumps(dict(records=records,paired=results,gate_passed=passed),indent=2))
    lines=['# 同环境条件来源对照结果','','仅验证集；同一固定划分上的训练重复，非独立数据确认。均值±样本SD，不作显著性判断。','','|数据集|phase−self逐种子差值(pp)|均值±SD|','|---|---|---:|']
    for d,r in results.items():lines.append(f"|{d}|"+', '.join(f'{x:+.3f}' for x in r['differences_pp'])+f"|{r['mean_pp']:+.3f} ± {r['sample_sd_pp']:.3f}|")
    lines+=['',f'冻结描述性门槛：{"通过" if passed else "未通过"}。不自动启动测试。']
    (OUT/'结论.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
