"""Freeze a separate, explicitly post-test extension without replacing stage one."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'
OUT.mkdir(exist_ok=True)
assert not (OUT/'plan.json').exists(), 'An existing plan is immutable; amend explicitly instead.'
assert json.loads((OUT/'module_checks.json').read_text())['common_initialization_equal']
jobs=[]
def add(family,dataset,variant,seed,size,init=1016):
    name=f'{family}_{dataset}_{variant}_s{seed}_i{init}_r{size}_120e'
    jobs.append(dict(id=name,family=family,dataset=dataset,variant=variant,seed=seed,init_seed=init,
                     imgsz=size,epochs=120,batch=16,run='runs/stage2/'+name))
# Finish matched seed blocks before advancing; every model remains eligible for reporting.
for seed in (42,43,44):
    for dataset in ('deeppcb','neu'):
        for variant in ('phase_uniform','phase','phase_capacity','phase_uncentered'):
            add('mechanism',dataset,variant,seed,320)
for seed in (42,43,44):
    for variant in ('baseline','phase_uniform','phase'):
        add('resolution','deeppcb',variant,seed,640)
for seed in (42,43,44):
    for variant in ('phase_uniform','phase'):
        add('initialization','deeppcb',variant,seed,320,2000+seed)
assert len(jobs)==39
sources=['stage2_modules.py','run_stage2_job.py','prepare_stage2.py','run_stage2_queue.py','check_stage2.py',
         'phase_modules.py','requirements-lock.txt']
snapshot=OUT/'source_snapshot'
snapshot.mkdir(exist_ok=True)
hashes={}
for name in sources:
    shutil.copy2(ROOT/name,snapshot/name)
    hashes[name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
plan={'created_utc':datetime.now(timezone.utc).isoformat(),'jobs':jobs,'source_hashes':hashes,
      'total_new_training_epochs':4680,'parallel_gpu_jobs':1,
      'history':'Post-stage-one test-informed extension; neither fresh untouched tests nor whole-study preregistration.',
      'primary_endpoint':'Validation mAP50-95, paired within training seed; all individual results, means and sample SD.',
      'primary_contrasts':['phase - phase_capacity (equal parameter counts; operation AND input differ)',
                           'phase - phase_uncentered (mean-centering subtraction intervention)',
                           'phase - phase_uniform (conditioning plus 4160 parameters)'],
      'resolution_analysis':'Within DeepPCB, compare (phase-uniform) at640 versus320 for each seed using new stage-two runs; baseline640 is context only.',
      'initialization_analysis':'Within each training seed, compare fixed1016 and alternative2042/2043/2044 branch initialization; not a full crossed seed factorial.',
      'test_policy':'Do not read test during training. Any eventual evaluation on existing tests is secondary reuse and must be disclosed; no winner-only reporting.',
      'stop_rule':'All39jobs or documented technical failure; no score-based early termination, architecture changes or hyperparameter tuning.',
      'selection':'EMA checkpoint with maximum validation mAP50-95, last exact tie; no test-based choice.',
      'risk':'Validation-best selection can be optimistic. Changes in capacity-control inputs/operation prevent attributing its contrast exclusively to conditioning.',
      'manifests':{d:hashlib.sha256((ROOT/f'data/{d}_yolo/manifest.json').read_bytes()).hexdigest() for d in ('neu','deeppcb')}}
(OUT/'plan.json').write_text(json.dumps(plan,indent=2))
print(f'Frozen {len(jobs)} jobs / 4680 epochs; no historical files changed.')
