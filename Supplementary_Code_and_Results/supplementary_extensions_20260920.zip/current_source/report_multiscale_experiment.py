"""Report the frozen parallel-scale phase validation screen."""
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/multiscale_experiment"


def ap(path):
    return 100.0 * json.loads(path.read_text(encoding="utf-8"))["metrics"]["metrics/mAP50-95(B)"]


def paired(candidate_jobs, control_jobs, dataset, variant, control_variant=None):
    rows = [job for job in candidate_jobs if job["dataset"] == dataset and job["variant"] == variant]
    per_seed = {}; values = []
    for job in sorted(rows, key=lambda item: item["seed"]):
        if control_variant is None:
            control = next(item for item in control_jobs if item["dataset"] == dataset and item["seed"] == job["seed"])
            control_path = ROOT / control["run"] / "val_summary.json"
        else:
            control = next(item for item in control_jobs if item["dataset"] == dataset and item["variant"] == control_variant and item["seed"] == job["seed"])
            control_path = ROOT / control["run"] / "val_summary.json"
        difference = ap(ROOT / job["run"] / "val_summary.json") - ap(control_path)
        per_seed[str(job["seed"])] = difference; values.append(difference)
    return {"per_seed_pp": per_seed, "mean_pp": statistics.fmean(values), "sample_sd_pp": statistics.stdev(values), "positive_seeds": sum(v > 0 for v in values)}


def main():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    phase = [{**job, "run": job["phase_control"]} for job in plan["jobs"]]
    results = {}
    for dataset in ("deeppcb", "neu"):
        results[dataset] = {
            "msd_minus_phase": paired(plan["jobs"], phase, dataset, "phase_msd"),
            "msd_minus_control": paired(plan["jobs"], plan["jobs"], dataset, "phase_msd", "phase_msd_control"),
        }
    gate = {}
    for name, key in (("vs_phase", "msd_minus_phase"), ("vs_control", "msd_minus_control")):
        values = {dataset: result[key] for dataset, result in results.items()}
        passed = all(v["mean_pp"] >= plan["gate"][name]["both_datasets_min_pp"] for v in values.values()) and any(v["mean_pp"] >= plan["gate"][name]["at_least_one_dataset_min_pp"] for v in values.values())
        gate[name] = {"passed": passed, **plan["gate"][name]}
    output = {"results": results, "gate": gate}
    (OUT / "results.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    lines = ["# 并行尺度细节细化：验证筛选", "", "比较 `phase_msd - phase` 与 `phase_msd - phase_msd_control`，仅使用验证集。", "", "|数据集|比较|逐种子差值(pp)|均值±样本SD|正向种子|", "|---|---|---|---:|---:|"]
    for dataset, comparisons in results.items():
        for name, result in comparisons.items():
            values = ", ".join(f"{v:+.3f}" for v in result["per_seed_pp"].values())
            lines.append(f"|{dataset}|{name}|{values}|{result['mean_pp']:+.3f} ± {result['sample_sd_pp']:.3f}|{result['positive_seeds']}/3|")
    lines += ["", f"相对 phase：{'支持' if gate['vs_phase']['passed'] else '不支持'}。", f"相对同参数控制：{'支持' if gate['vs_control']['passed'] else '不支持'}。", "", "只有两项门槛都通过，才把增益解释为空洞尺度多样性，而不是并行容量。", "本轮不接触测试集。"]
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
