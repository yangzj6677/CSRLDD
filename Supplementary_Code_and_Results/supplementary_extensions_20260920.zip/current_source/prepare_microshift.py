"""Freeze the validation-only micro-shift diagnostic before execution."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/microshift"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    models = {
        "neu": {
            "baseline": "runs/innovation/baseline_s42_120e/weights/best.pt",
            "phase": "runs/alignment/neu_phase_s42_r320_120e/weights/best.pt",
        },
        "deeppcb": {
            "baseline": "runs/confirmation/deeppcb_baseline_s42_120e/weights/best.pt",
            "phase": "runs/alignment/deeppcb_phase_s42_r320_120e/weights/best.pt",
        },
    }
    shifts = [
        [-2, 0],
        [-1, 0],
        [1, 0],
        [2, 0],
        [0, -2],
        [0, -1],
        [0, 1],
        [0, 2],
    ]
    sources = ["microshift_diagnostic.py", "report_microshift.py", "requirements-lock.txt"]
    for dataset_models in models.values():
        sources.extend(dataset_models.values())
    for dataset in models:
        sources.extend(
            [
                f"data/{dataset}_yolo/data.yaml",
                f"data/{dataset}_yolo/manifest.json",
            ]
        )
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "microshift_diagnostic",
        "selection": "validation only; no test evaluation",
        "models": models,
        "shifts_pixels": shifts,
        "protocol": {
            "imgsz": 320,
            "confidence": 0.25,
            "iou": 0.7,
            "max_det": 300,
            "batch": 16,
            "interpolation": "cv2.INTER_NEAREST",
            "border_mode": "cv2.BORDER_REPLICATE",
            "matching": "class-aware greedy match by descending IoU",
            "primary_metric": "match F1 at IoU 0.5 after inverse translation",
            "secondary_metric": "match F1 at IoU 0.75 after inverse translation",
        },
        "gate": {
            "comparison": "baseline minus phase mean F1 over all eight shifts",
            "both_datasets_min_phase_specific_drop_pp": 0.5,
            "paired_bootstrap_samples": 10000,
            "paired_bootstrap_confidence": 0.95,
            "paired_bootstrap_seed": 20260917,
            "require_ci_lower_above_zero": True,
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sources
        },
        "caveats": [
            "single seed and one checkpoint per model and dataset",
            "bootstrap resamples validation images, not training seeds",
            "prediction matching is diagnostic and not a detection metric",
            "replicate padding changes edge content; no border crop is applied",
            "existing tests are known and are not used in this diagnostic",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(models)} datasets and {len(shifts)} shifts; validation only")


if __name__ == "__main__":
    main()
