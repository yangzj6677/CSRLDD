"""Freeze the parallel-scale phase-refinement validation experiment."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/multiscale_experiment"


def phase_control(dataset, seed):
    if dataset == "neu" and seed == 42:
        return "runs/alignment/neu_phase_s42_r320_120e"
    prefix = "deeppcb_" if dataset == "deeppcb" else ""
    return f"runs/confirmation/{prefix}phase_s{seed}_120e"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    jobs = []
    for dataset in ("deeppcb", "neu"):
        for variant in ("phase_msd", "phase_msd_control"):
            for seed in (42, 43, 44):
                prefix = "deeppcb_" if dataset == "deeppcb" else ""
                jobs.append(
                    {
                        "id": f"{dataset}_{variant}_s{seed}_r320_120e",
                        "dataset": dataset,
                        "variant": variant,
                        "seed": seed,
                        "init_seed": 1016,
                        "imgsz": 320,
                        "epochs": 120,
                        "batch": 16,
                        "run": f"runs/multiscale_experiment/{prefix}{variant}_s{seed}_120e",
                        "phase_control": phase_control(dataset, seed),
                    }
                )
    for job in jobs:
        assert (ROOT / job["phase_control"] / "val_summary.json").exists()
    sources = [
        "prepare_multiscale_experiment.py",
        "multiscale_modules.py",
        "phase_modules.py",
        "check_multiscale.py",
        "run_multiscale_job.py",
        "run_multiscale_queue.py",
        "report_multiscale_experiment.py",
        "requirements-lock.txt",
        "models/yolo11n.pt",
        "data/neu_yolo/data.yaml",
        "data/deeppcb_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/manifest.json",
    ]
    sources.extend(job["phase_control"] + "/val_summary.json" for job in jobs)
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "parallel_scale_phase_refinement_screen",
        "jobs": jobs,
        "selection": "validation only; no test evaluation",
        "primary_comparison": "phase_msd - phase",
        "secondary_comparison": "phase_msd - phase_msd_control",
        "primary_endpoint": "mAP50-95",
        "implementation": (
            "replace the single 3x3 depthwise detail refinement with parallel "
            "3x3 dilation-1 and dilation-2 branches; control uses two "
            "dilation-1 branches with identical parameter count"
        ),
        "gate": {
            "vs_phase": {
                "both_datasets_min_pp": 0.0,
                "at_least_one_dataset_min_pp": 0.5,
            },
            "vs_control": {
                "both_datasets_min_pp": 0.0,
                "at_least_one_dataset_min_pp": 0.5,
            },
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sources
        },
        "caveats": [
            "the parallel branches add capacity relative to the original phase refinement",
            "the control has identical branch parameters but no dilation diversity",
            "phase controls are reused from the frozen main matrix",
            "validation only; failed gates do not advance to test",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(jobs)} parallel-scale jobs")


if __name__ == "__main__":
    main()
