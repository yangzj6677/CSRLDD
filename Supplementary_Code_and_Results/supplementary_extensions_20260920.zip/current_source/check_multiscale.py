"""Prototype checks for parallel-scale phase refinement."""
import io
import json
from pathlib import Path

import torch
from ultralytics import YOLO

from multiscale_modules import attach_multiscale_phase
from phase_modules import attach_phase


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/multiscale_experiment"


def main():
    torch.set_num_threads(4)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    report = {}
    base = attach_phase(YOLO(str(ROOT / "models/yolo11n.pt")).model, "phase")
    base = base.to(device).eval()
    x = torch.rand(1, 3, 320, 320, device=device)
    with torch.no_grad():
        reference = base(x)[0]
    for variant in ("phase_msd", "phase_msd_control"):
        model = attach_multiscale_phase(
            YOLO(str(ROOT / "models/yolo11n.pt")).model, variant
        ).to(device).eval()
        with torch.no_grad():
            initial = model(x)[0]
        initial_error = float((reference - initial).abs().max())
        model.model[16].addition.gamma.data.fill_(0.1)
        output = model(x)[0]
        changed = not torch.equal(reference, output)
        output.square().mean().backward()
        finite = all(
            parameter.grad is None or torch.isfinite(parameter.grad).all()
            for parameter in model.parameters()
        )
        stream = io.BytesIO()
        torch.save(model, stream)
        stream.seek(0)
        restored = torch.load(stream, weights_only=False).to(device).eval()
        with torch.no_grad():
            restored_output = restored(x)[0]
        serialization_error = float((output.detach() - restored_output).abs().max())
        report[variant] = {
            "identity_max_abs_error": initial_error,
            "changed_after_nonzero_gamma": changed,
            "finite_gradients": finite,
            "serialization_max_abs_error": serialization_error,
            "branch_parameters": sum(
                parameter.numel()
                for parameter in model.model[16].addition.branch_1.parameters()
            )
            + sum(
                parameter.numel()
                for parameter in model.model[16].addition.branch_2.parameters()
            )
            + sum(
                parameter.numel()
                for parameter in model.model[16].addition.project.parameters()
            ),
            "device": device,
        }
        assert initial_error < 1e-6
        assert changed and finite and serialization_error < 1e-6
    assert (
        report["phase_msd"]["branch_parameters"]
        == report["phase_msd_control"]["branch_parameters"]
    )
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "prototype_checks.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
