"""Render the completed mechanism block without implying test confirmation."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'
r=json.loads((OUT/'results.json').read_text())
variants=['phase_uniform','phase_capacity','phase_uncentered','phase']
labels=['Unconditional','Capacity-matched','Uncentered','Conditioned']
colors=['#009E73','#0072B2','#CC79A7','#D55E00']
records={(x['job']['dataset'],x['job']['variant'],x['job']['seed']):
         100*x['metrics']['metrics/mAP50-95(B)'] for x in r['records'] if x['job']['family']=='mechanism'}
assert len(records)==24
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
                     'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(8.3,3.7),layout='constrained')
for ax,dataset,title in zip(axes,('neu','deeppcb'),('NEU-DET','DeepPCB')):
    for x,(variant,label,color) in enumerate(zip(variants,labels,colors)):
        vals=[records[dataset,variant,s] for s in (42,43,44)]
        mean=sum(vals)/3
        sd=(sum((v-mean)**2 for v in vals)/2)**.5
        ax.errorbar(x,mean,yerr=sd,fmt='o',color=color,capsize=4,markersize=7)
        ax.scatter([x-.10,x,x+.10],vals,color=color,s=20,alpha=.65,edgecolor='white',linewidth=.3)
    ax.set_xticks(range(4),labels,rotation=17,ha='right')
    ax.set_title(title)
    ax.set_ylabel('Validation mAP50–95 (%)')
    ax.grid(axis='y',alpha=.25)
fig.get_layout_engine().set(rect=(0,.10,1,1))
fig.text(.5,.02,'Dots: training seeds 42–44; error bars: sample SD. Post-test-designed validation experiment.',ha='center',fontsize=8)
for ext in ('pdf','svg','png'):
    fig.savefig(OUT/f'mechanism_validation.{ext}',dpi=600,bbox_inches='tight',pad_inches=.06)
plt.close(fig)

agg={(x['dataset'],x['variant']):x for x in r['aggregates'] if x['family']=='mechanism'}
paired={(x['dataset'],x['candidate'],x['control']):x for x in r['paired'] if x['complete_three_seeds']}
lines=['# Completed mechanism-extension results','','These are validation results from a post-stage-one, test-informed extension. They strengthen mechanism diagnosis but are not a fresh independent test.','','| Dataset | Variant | Validation mAP50–95, mean ± sample SD |','|---|---|---:|']
for dataset in ('neu','deeppcb'):
    for variant,label in zip(variants,labels):
        x=agg[dataset,variant]
        lines.append(f'| {"NEU-DET" if dataset=="neu" else "DeepPCB"} | {label} | {x["mean"]:.3f} ± {x["sd"]:.3f} |')
lines+=['','| Dataset | Paired contrast | Seed differences (pp) | Mean ± sample SD (pp) |','|---|---|---|---:|']
for dataset in ('neu','deeppcb'):
    for candidate,control in (('phase','phase_uniform'),('phase','phase_capacity'),('phase','phase_uncentered')):
        x=paired[dataset,candidate,control]
        diffs=', '.join(f'{v:+.3f}' for v in x['differences_pp'])
        lines.append(f'| {"NEU-DET" if dataset=="neu" else "DeepPCB"} | {candidate} − {control} | {diffs} | {x["mean_pp"]:+.3f} ± {x["sd_pp"]:.3f} |')
lines+=['','DeepPCB conditioned-minus-capacity and conditioned-minus-uncentered differences are positive in all three observed training seeds. NEU differences for the same comparisons are also positive in all three seeds, though smaller. These observations do not establish population-level significance or isolate every architectural difference.']
(OUT/'机制实验结果.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(OUT/'mechanism_validation.pdf')
