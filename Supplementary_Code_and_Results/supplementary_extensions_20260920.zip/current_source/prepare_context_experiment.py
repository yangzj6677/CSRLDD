"""Freeze the P4-context condition experiment."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/context_experiment"


def phase_control(dataset, seed):
    if dataset == "neu" and seed == 42:
        return "runs/alignment/neu_phase_s42_r320_120e"
    prefix = "deeppcb_" if dataset == "deeppcb" else ""
    return f"runs/confirmation/{prefix}phase_s{seed}_120e"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    jobs = []
    for dataset in ("deeppcb", "neu"):
        for variant in ("phase_p4ctx", "phase_se"):
            for seed in (42, 43, 44):
                prefix = "deeppcb_" if dataset == "deeppcb" else ""
                job_id = f"{dataset}_{variant}_s{seed}_r320_120e"
                run_name = f"{prefix}{variant}_s{seed}_120e"
                jobs.append(
                    {
                        "id": job_id,
                        "dataset": dataset,
                        "variant": variant,
                        "seed": seed,
                        "init_seed": 1016,
                        "imgsz": 320,
                        "epochs": 120,
                        "batch": 16,
                        "run": f"runs/context_experiment/{run_name}",
                        "phase_control": phase_control(dataset, seed),
                    }
                )
    for job in jobs:
        assert (ROOT / job["phase_control"] / "val_summary.json").exists()
    sources = [
        "prepare_context_experiment.py",
        "context_modules.py",
        "phase_modules.py",
        "check_context.py",
        "run_context_job.py",
        "run_context_queue.py",
        "report_context_experiment.py",
        "requirements-lock.txt",
        "models/yolo11n.pt",
        "data/neu_yolo/data.yaml",
        "data/deeppcb_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/manifest.json",
    ]
    sources.extend(job["phase_control"] + "/val_summary.json" for job in jobs)
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "p4_context_condition_screen",
        "jobs": jobs,
        "selection": "validation only; no test evaluation",
        "primary_comparison": "phase_p4ctx - phase",
        "secondary_comparison": "phase_p4ctx - phase_se",
        "primary_endpoint": "mAP50-95",
        "implementation": (
            "P3 condition multiplied by a zero-initialized tanh correction "
            "projected from backbone P4; P3-SE control uses both average and "
            "max pooled P3 with nearly matched extra parameters"
        ),
        "gate": {
            "vs_phase": {
                "both_datasets_min_pp": 0.0,
                "at_least_one_dataset_min_pp": 0.5,
            },
            "vs_phase_se": {
                "both_datasets_min_pp": 0.0,
                "at_least_one_dataset_min_pp": 0.5,
            },
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sources
        },
        "caveats": [
            "P4 context is projected to the P3 condition rather than changing the phase operator itself",
            "the P4 path adds more parameters than the original phase condition",
            "the P3-SE control is near matched but not exactly parameter matched",
            "phase controls are reused from the frozen main matrix",
            "validation only; failed gates do not advance to test",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(jobs)} context-condition jobs")


if __name__ == "__main__":
    main()
