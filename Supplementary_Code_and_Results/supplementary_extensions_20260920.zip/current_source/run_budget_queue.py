"""Wait for existing queue, then run the frozen experiment serially."""
import json
import hashlib
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
import msvcrt

root = Path(__file__).resolve().parent
out = root/'reports/budget_experiment'
lock = (out/'queue.lock').open('a+b')
lock.seek(0)
lock.write(b'0')
lock.flush()
lock.seek(0)
msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
plan = json.loads((out/'plan.json').read_text())
state = dict(status='waiting_stage2',completed=[],total=len(plan['jobs']),active=None)
def save():
    state['updated_utc'] = datetime.now(timezone.utc).isoformat()
    (out/'state.tmp').write_text(json.dumps(state,indent=2))
    (out/'state.tmp').replace(out/'state.json')
save()
while True:
    prior = json.loads((root/'reports/stage2/state.json').read_text())
    if prior.get('failures'):
        state['status']='blocked_stage2_failure'
        save()
        sys.exit(1)
    if len(prior['completed']) == prior['total']:
        break
    time.sleep(30)
for path, digest in {**plan['source_hashes'],**plan['reference_hashes']}.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
for job in plan['jobs']:
    result = root/job['run']/'val_summary.json'
    if result.exists():
        assert json.loads(result.read_text())['job']==job
        state['completed'].append(job['id'])
        continue
    state.update(status='running',active=job['id'])
    save()
    with (out/(job['id']+'.log')).open('a',encoding='utf-8') as log:
        code = subprocess.call([sys.executable,str(root/'run_budget_job.py'),'--job',job['id']],
                               cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if code:
        state.update(status='failed',exit_code=code)
        save()
        sys.exit(code)
    state['completed'].append(job['id'])
    save()
state.update(status='complete',active=None)
save()
