"""Exploratory detail rotation; no accuracy or novelty claim."""
import math
import torch
from torch import nn
from phase_modules import PhaseInjection, PhaseBlock
from ultralytics.models.yolo.detect import DetectionTrainer


def rotate_detail(z, angles):
    # z: B,C,3,H,W; angles: B,3,H,W, shared across C.
    parts = list(z.unbind(2))
    for index, (i, j) in enumerate(((0, 1), (0, 2), (1, 2))):
        a = angles[:, index:index+1]
        c, s = a.cos(), a.sin()
        x, y = parts[i], parts[j]
        parts[i], parts[j] = c*x-s*y, s*x+c*y
    return torch.stack(parts, 2)


class FrontierInjection(PhaseInjection):
    def __init__(self, shallow_channels, channels, variant):
        super().__init__(shallow_channels, channels, 'phase')
        assert variant in ('phase', 'rotation_static', 'rotation_dynamic', 'direction_gain')
        self.variant = variant
        self.register_buffer('basis', torch.tensor([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]], dtype=torch.float32)/2)
        if variant != 'phase':
            self.angle = nn.Conv2d(channels, 3, 1)
            nn.init.zeros_(self.angle.weight)
            nn.init.zeros_(self.angle.bias)

    def packed(self, shallow, semantic):
        q = super().packed(shallow, semantic)
        if self.variant == 'phase':
            return q
        b,c,h,w = q.shape
        phases = q.reshape(b,c//4,4,h,w)
        mean = phases.mean(2, keepdim=True)
        z = torch.einsum('pk,bcphw->bckhw', self.basis, phases-mean)
        source = torch.ones_like(semantic) if self.variant == 'rotation_static' else semantic
        control = self.angle(source).tanh()
        angles = (math.pi/4) * control
        if self.variant == 'direction_gain':
            mixed = z * (1 + .5*control)[:,None]
        else:
            mixed = rotate_detail(z, angles)
        return (mean + torch.einsum('pk,bckhw->bcphw', self.basis, mixed)).reshape_as(q)


def attach_frontier(model, variant, init_seed=1016):
    original = model.model[16]
    assert not isinstance(original, PhaseBlock)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        addition = FrontierInjection(model.model[2].cv2.conv.out_channels,
                                     original.cv2.conv.out_channels, variant)
    model.model[16] = PhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    model.branch_init_seed = init_seed
    return model


class FrontierTrainer(DetectionTrainer):
    variant = 'rotation_dynamic'
    init_seed = 1016

    def get_model(self, cfg=None, weights=None, verbose=True):
        wrapped = weights is not None and isinstance(weights.model[16], PhaseBlock)
        if wrapped:
            assert weights.refinement_variant == self.variant
        model = attach_frontier(super().get_model(cfg, None if wrapped else weights, verbose),
                                self.variant, self.init_seed)
        if wrapped:
            model.load(weights)
        return model
