"""Freeze the full-budget validation screen for head-directed detail injection."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/head_detail_experiment"


def phase_control(dataset, seed):
    if dataset == "neu" and seed == 42:
        return "runs/alignment/neu_phase_s42_r320_120e"
    prefix = "deeppcb_" if dataset == "deeppcb" else ""
    return f"runs/confirmation/{prefix}phase_s{seed}_120e"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    jobs = []
    for dataset in ("deeppcb", "neu"):
        for variant in ("phase_box", "phase_head"):
            for seed in (42, 43, 44):
                prefix = "deeppcb_" if dataset == "deeppcb" else ""
                jobs.append(
                    {
                        "id": f"{dataset}_{variant}_s{seed}_r320_120e",
                        "dataset": dataset,
                        "variant": variant,
                        "seed": seed,
                        "imgsz": 320,
                        "epochs": 120,
                        "batch": 16,
                        "run": f"runs/head_detail_experiment/{prefix}{variant}_s{seed}_120e",
                        "phase_control": phase_control(dataset, seed),
                    }
                )
    for job in jobs:
        assert (ROOT / job["phase_control"] / "val_summary.json").exists()
    sources = [
        "prepare_head_detail_experiment.py",
        "head_detail_modules.py",
        "phase_modules.py",
        "run_innovation.py",
        "run_head_detail_queue.py",
        "report_head_detail_experiment.py",
        "requirements-lock.txt",
        "models/yolo11n.pt",
        "data/neu_yolo/data.yaml",
        "data/deeppcb_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/manifest.json",
    ]
    sources.extend(job["phase_control"] + "/val_summary.json" for job in jobs)
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "head_detail_full_budget_screen",
        "jobs": jobs,
        "selection": "validation only; no test evaluation",
        "primary_comparison": "phase_box - phase and phase_head - phase",
        "primary_endpoint": "mAP50-95",
        "gate": {
            "both_datasets_min_pp": 0.0,
            "at_least_one_dataset_min_pp": 0.5,
        },
        "implementation": (
            "P2 detail refinement is injected only into the box branch for "
            "phase_box, or into both head branches for phase_head"
        ),
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sources
        },
        "caveats": [
            "the two head variants remove the original backbone-level phase injection and are not strict location controls",
            "head routing is validated only for the fixed YOLO11n Detect structure",
            "phase controls are reused from the main matrix",
            "validation only; failed gates do not advance to test",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(jobs)} head-detail jobs")


if __name__ == "__main__":
    main()
