"""Create separate frozen validation-only local alignment screen."""
import hashlib,json
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent;out=root/'reports/alignment';out.mkdir(parents=True,exist_ok=True)
assert not (out/'plan.json').exists()
runner=(root/'run_budget_job.py').read_text().replace('budget_experiment','alignment').replace('budget_modules','alignment_modules').replace('BudgetTrainer','AlignmentTrainer')
(root/'run_alignment_job.py').write_text(runner,encoding='utf-8')
queue=(root/'run_frontier_queue.py').read_text().replace('reports/frontier','reports/alignment').replace('run_frontier_job.py','run_alignment_job.py')
(root/'run_alignment_queue.py').write_text(queue,encoding='utf-8')
report=(root/'report_frontier.py').read_text(encoding='utf-8').replace('reports/frontier','reports/alignment').replace('第一轮细节旋转筛选','局部语义对齐筛选')
(root/'report_alignment.py').write_text(report,encoding='utf-8')
jobs=[]
for dataset in ('deeppcb','neu'):
    for variant in ('phase','align_uniform','align_dw','align_self','align_cross'):
        name=f'{dataset}_{variant}_s42_r320_120e'
        jobs.append(dict(id=name,dataset=dataset,variant=variant,seed=42,init_seed=1016,imgsz=320,epochs=120,batch=16,run=f'runs/alignment/{name}'))
sources=['alignment_modules.py','phase_modules.py','run_alignment_job.py','run_alignment_queue.py','check_alignment.py','requirements-lock.txt','models/yolo11n.pt','data/neu_yolo/data.yaml','data/deeppcb_yolo/data.yaml']
plan=dict(created_utc=datetime.now(timezone.utc).isoformat(),stage='local_alignment_screen',jobs=jobs,
          source_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources},
          selection='validation only; no test evaluation',
          implementation='raw P2 average pooled query, P3 key/value, 3x3 replicate window, key dim8, identity value, zero beta with tanh',
          gate=dict(cross_minus_phase_both_min_pp=0,at_least_one_min_pp=.5,forward_latency_increase_max_fraction=.1),
          caveats=['single seed exploratory','controls are not parameter matched; report actual counts',
                   'raw pooled P2 query and identity value are simplified implementation choices frozen before training',
                   'zero beta plus existing zero condition/gamma delays inner gradient activation; tested after activation'])
(out/'plan.json').write_text(json.dumps(plan,indent=2))
print('Frozen 10 local alignment runs')
