"""Report the entire frozen validation screen, including negative results."""
import json
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/frontier'
plan=json.loads((OUT/'plan.json').read_text())
records=[]
for job in plan['jobs']:
    path=ROOT/job['run']/'val_summary.json'
    if path.exists():
        result=json.loads(path.read_text())
        assert result['job']==job
        records.append(dict(job=job,map5095=100*result['metrics']['metrics/mAP50-95(B)']))
index={(r['job']['dataset'],r['job']['variant']):r['map5095'] for r in records}
lines=['# 第一轮细节旋转筛选', '',f'已完成 {len(records)}/{len(plan["jobs"])}；单种子验证，尚不能作为稳定增益结论。', '',
       '|数据集|模型|验证mAP50–95|相对本轮phase差值|','|---|---|---:|---:|']
for r in records:
    j=r['job'];reference=index.get((j['dataset'],'phase'))
    difference='待对照完成' if reference is None else f'{r["map5095"]-reference:+.3f}'
    lines.append(f'|{j["dataset"]}|{j["variant"]}|{r["map5095"]:.3f}|{difference}|')
(OUT/'results.json').write_text(json.dumps(dict(updated_utc=datetime.now(timezone.utc).isoformat(),records=records),indent=2))
(OUT/'实验结果.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(f'{len(records)}/{len(plan["jobs"])} completed')
