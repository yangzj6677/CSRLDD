"""Parallel-scale refinement for the validated phase detail branch."""
import torch
from torch import nn
from ultralytics.nn.modules import Conv
from ultralytics.models.yolo.detect import DetectionTrainer

from phase_modules import PhaseBlock, PhaseInjection


class MultiScalePhaseInjection(PhaseInjection):
    """Replace the single detail conv with two parallel depthwise branches."""

    def __init__(self, shallow_channels, channels, variant):
        super().__init__(shallow_channels, channels, "phase")
        if variant not in ("phase_msd", "phase_msd_control"):
            raise ValueError(variant)
        width = max(8, channels // 4) * 4
        self.variant = variant
        self.branch_1 = Conv(width, width, 3, g=width, d=1)
        dilation = 2 if variant == "phase_msd" else 1
        self.branch_2 = Conv(width, width, 3, g=width, d=dilation)
        self.project = Conv(width, channels, 1, act=False)
        # The original single refinement is intentionally replaced.
        self.refine = nn.Identity()

    def forward(self, semantic, shallow):
        packed = super().packed(shallow, semantic)
        refined = self.branch_1(packed) + self.branch_2(packed)
        return semantic + self.gamma * self.project(refined)


def attach_multiscale_phase(model, variant, init_seed=1016):
    original = model.model[16]
    assert not isinstance(original, PhaseBlock)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        addition = MultiScalePhaseInjection(
            model.model[2].cv2.conv.out_channels,
            original.cv2.conv.out_channels,
            variant,
        )
    model.model[16] = PhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    model.branch_init_seed = init_seed
    return model


class MultiScaleTrainer(DetectionTrainer):
    variant = "phase_msd"
    init_seed = 1016

    def get_model(self, cfg=None, weights=None, verbose=True):
        wrapped = weights is not None and isinstance(weights.model[16], PhaseBlock)
        if wrapped:
            assert weights.refinement_variant == self.variant
            assert weights.branch_init_seed == self.init_seed
        model = attach_multiscale_phase(
            super().get_model(cfg, None if wrapped else weights, verbose),
            self.variant,
            self.init_seed,
        )
        if wrapped:
            model.load(weights)
        return model
