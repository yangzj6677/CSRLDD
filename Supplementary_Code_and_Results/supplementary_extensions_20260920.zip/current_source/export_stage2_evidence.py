"""Recompute descriptive extension tables from all saved summaries, without inference."""
import hashlib, json, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/submission'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    plan=json.loads((ROOT/'reports/stage2/plan.json').read_text())
    rows=[]; provenance={}; indexed={}
    for j in plan['jobs']:
        for split,name in [('val','val_summary.json'),('test','posthoc_test_summary.json')]:
            p=ROOT/j['run']/name; r=json.loads(p.read_text())
            assert r['job']==j and r['split']==split
            v=100*r['metrics']['metrics/mAP50-95(B)']
            indexed[j['family'],j['dataset'],split,j['variant'],j['seed']]=v
            rows.append((j,split,v)); provenance[str(p.relative_to(ROOT))]=digest(p)
    assert len(rows)==78
    lines=['# Stage-two complete descriptive tables','','All 39 validation and 39 reused-test summaries; post-exploration evidence, not independent confirmation. AP and differences are in percentage units. Seeds are 42, 43, 44; SD is sample SD.','','|Family|Dataset|Split|Variant|Input|Seed 42|Seed 43|Seed 44|Mean ± SD|','|---|---|---|---|---:|---:|---:|---:|---:|']
    groups={}
    for j,s,v in rows: groups.setdefault((j['family'],j['dataset'],s,j['variant'],j['imgsz']),{})[j['seed']]=v
    for k,g in sorted(groups.items()):
        v=[g[s] for s in (42,43,44)]
        lines.append('|'+ '|'.join(map(str,k))+'|'+'|'.join(f'{x:.3f}' for x in v)+f'|{statistics.mean(v):.3f} ± {statistics.stdev(v):.3f}|')
    lines+=['','## Resolution interaction and initialization sensitivity','','|Split|Contrast|Seed differences (42,43,44)|Mean ± SD (pp)|','|---|---|---|---:|']
    contrasts=[]
    for split in ('val','test'):
        def get(f,v,s): return indexed[f,'deeppcb',split,v,s]
        definitions=[('resolution interaction (640−320)',[(get('resolution','phase',s)-get('resolution','phase_uniform',s))-(get('mechanism','phase',s)-get('mechanism','phase_uniform',s)) for s in (42,43,44)])]
        for v in ('phase_uniform','phase'):
            definitions.append((v+' alternative−fixed initialization',[get('initialization',v,s)-get('mechanism',v,s) for s in (42,43,44)]))
        definitions.append(('phase−uniform with alternative initialization',[get('initialization','phase',s)-get('initialization','phase_uniform',s) for s in (42,43,44)]))
        for label,values in definitions:
            mean=statistics.mean(values); sd=statistics.stdev(values)
            contrasts.append(dict(split=split,contrast=label,values=values,mean=mean,sd=sd))
            lines.append(f'|{split}|{label}|'+', '.join(f'{x:+.3f}' for x in values)+f'|{mean:+.3f} ± {sd:.3f}|')
    (OUT/'stage2_complete_tables.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    (OUT/'stage2_table_provenance.json').write_text(json.dumps(dict(source_hashes=provenance,script_sha256=digest(Path(__file__)),rows=len(rows),contrasts=contrasts),indent=2))
    print(json.dumps(contrasts,indent=2))
if __name__=='__main__':main()
