"""One pooled-test evaluation from the immutable stage-two plan."""
import argparse
import hashlib
import json
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('YOLO_CONFIG_DIR',str(ROOT/'.yolo_config'))
from ultralytics import YOLO
import stage2_modules  # make serialized wrapper classes importable

p=argparse.ArgumentParser();p.add_argument('--job',required=True);a=p.parse_args()
plan=json.loads((ROOT/'reports/stage2/plan.json').read_text())
test_plan=json.loads((ROOT/'reports/stage2/test_plan.json').read_text())
for source,expected in test_plan['source_hashes'].items():
    assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest()==expected,source
job=next(j for j in plan['jobs'] if j['id']==a.job)
run=ROOT/job['run'];best=run/'weights/best.pt'
assert best.exists()
model=YOLO(str(best))
assert getattr(model.model,'refinement_variant','baseline')==job['variant']
data=ROOT/'data'/f"{job['dataset']}_yolo/data.yaml"
metrics=model.val(data=str(data),split='test',imgsz=job['imgsz'],batch=16,device=0,workers=0,
                  plots=False,save_json=True,project=str(ROOT/'runs/stage2_tests'),name=job['id'],exist_ok=False)
result={'job':job,'split':'test','known_test_reuse':True,'metrics':metrics.results_dict,
        'per_class':metrics.summary(),'checkpoint_sha256':hashlib.sha256(best.read_bytes()).hexdigest(),
        'test_plan_sha256':hashlib.sha256((ROOT/'reports/stage2/test_plan.json').read_bytes()).hexdigest(),
        'evaluation_dir':str(metrics.save_dir)}
(run/'posthoc_test_summary.json').write_text(json.dumps(result,indent=2,default=str))
print(json.dumps(result,indent=2,default=str))
