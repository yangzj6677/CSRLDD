import io,json
from pathlib import Path
import torch
from ultralytics import YOLO
from phase_modules import PhaseInjection
from alignment_modules import AlignmentInjection,attach_alignment

torch.set_num_threads(4);torch.manual_seed(1016)
ref=PhaseInjection(16,64,'phase').double()
torch.nn.init.normal_(ref.condition.weight,std=.1)
x=torch.randn(2,16,12,12,dtype=torch.float64);s=torch.randn(2,64,6,6,dtype=torch.float64)
q=ref.packed(x,s)
report={}
for variant in ('phase','align_uniform','align_self','align_cross','align_dw'):
    mod=AlignmentInjection(16,64,variant).double();mod.load_state_dict(ref.state_dict(),strict=False)
    assert torch.equal(mod.packed(x,s),q)
    if variant!='phase':mod.beta.data.fill_(.2)
    y=mod.packed(x,s)
    error=(y.reshape(2,16,4,6,6).mean(2)-q.reshape(2,16,4,6,6).mean(2)).abs().max().item()
    assert error<1e-12
    (y*torch.randn_like(y)).sum().backward()
    if variant!='phase':assert mod.beta.grad.abs().item()>0
    if variant in ('align_self','align_cross'):
        assert mod.query.weight.grad.abs().max()>0 and torch.isfinite(mod.query.weight.grad).all()
    report[variant]={'mean_error':error,'parameters':sum(p.numel() for p in mod.parameters()),'identity':'pass','gradient':'pass'}
base=YOLO('models/yolo11n.pt').model.cuda().eval();inp=torch.rand(1,3,320,320,device='cuda')
with torch.no_grad(): expected=base(inp)[0].clone()
attach_alignment(base,'align_cross');base.cuda().eval()
with torch.no_grad(): actual=base(inp)[0];assert torch.equal(expected,actual)
stream=io.BytesIO();torch.save(base,stream);stream.seek(0);loaded=torch.load(stream,weights_only=False)
with torch.no_grad():assert torch.equal(actual,loaded(inp)[0])
out=Path('reports/alignment');out.mkdir(parents=True,exist_ok=True)
report['detector']={'cuda_identity':'pass','serialization':'pass'}
(out/'prototype_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
