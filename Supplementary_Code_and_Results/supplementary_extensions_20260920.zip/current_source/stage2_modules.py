"""Post-stage-one mechanism extensions; historical modules remain unchanged."""
import torch
from torch.nn import functional as F
from phase_modules import PhaseInjection, PhaseBlock
from ultralytics.models.yolo.detect import DetectionTrainer


class CapacityInjection(PhaseInjection):
    """Equally parameterized shallow transform; not an isolated conditioning intervention."""
    def __init__(self, shallow_channels, channels):
        super().__init__(shallow_channels, channels, 'phase')
        self.mode = 'phase_capacity'

    def packed(self, shallow, semantic):
        p = F.pixel_unshuffle(self.compress(shallow), 2)
        assert p.shape == semantic.shape
        return p + .5 * self.condition(p).tanh()


def attach_stage2(model, variant, init_seed=1016):
    original = model.model[16]
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        dims = (model.model[2].cv2.conv.out_channels, original.cv2.conv.out_channels)
        addition = CapacityInjection(*dims) if variant == 'phase_capacity' else PhaseInjection(*dims, variant)
    model.model[16] = PhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    model.branch_init_seed = init_seed
    return model


class Stage2Trainer(DetectionTrainer):
    variant = 'phase'
    init_seed = 1016

    def get_model(self, cfg=None, weights=None, verbose=True):
        wrapped = weights is not None and isinstance(weights.model[16], PhaseBlock)
        if wrapped:
            assert weights.refinement_variant == self.variant
            assert weights.branch_init_seed == self.init_seed
        model = attach_stage2(super().get_model(cfg, None if wrapped else weights, verbose),
                              self.variant, self.init_seed)
        if wrapped:
            model.load(weights)
        return model
