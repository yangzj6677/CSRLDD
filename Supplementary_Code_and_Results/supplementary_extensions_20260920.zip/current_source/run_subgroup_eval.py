"""Run the frozen subgroup recall diagnostic without training or model changes."""
import json
from pathlib import Path

import cv2
import numpy as np
import torch
from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/subgroups"


def load_plan():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    for path, expected in plan["source_hashes"].items():
        actual = __import__("hashlib").sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == expected, path
    return plan


def image_paths(dataset, split):
    directory = ROOT / "data" / f"{dataset}_yolo/images/{split}"
    return sorted(
        path
        for path in directory.iterdir()
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp"}
    )


def read_labels(dataset, split, paths):
    labels = {}
    for image_path in paths:
        label_path = (
            ROOT
            / "data"
            / f"{dataset}_yolo/labels/{split}"
            / f"{image_path.stem}.txt"
        )
        rows = []
        if label_path.exists():
            for line in label_path.read_text(encoding="utf-8").splitlines():
                values = line.split()
                if len(values) != 5:
                    continue
                rows.append(
                    {
                        "class_id": int(float(values[0])),
                        "xywhn": [float(value) for value in values[1:]],
                    }
                )
        labels[image_path] = rows
    return labels


def ground_truth(dataset, split, plan, paths):
    labels = read_labels(dataset, split, paths)
    records = {}
    thresholds = plan["thresholds"][dataset]
    for image_path in paths:
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            raise RuntimeError(f"Could not read {image_path}")
        height, width = image.shape[:2]
        boxes = []
        for row in labels[image_path]:
            x_center, y_center, box_width, box_height = row["xywhn"]
            x1 = (x_center - box_width / 2.0) * width
            y1 = (y_center - box_height / 2.0) * height
            x2 = (x_center + box_width / 2.0) * width
            y2 = (y_center + box_height / 2.0) * height
            reference_width = box_width * plan["reference_input"]
            reference_height = box_height * plan["reference_input"]
            shorter = min(reference_width, reference_height)
            longer = max(reference_width, reference_height)
            aspect = longer / max(shorter, 1e-9)
            is_narrow = shorter <= thresholds["narrow_min_side_px"]
            is_elongated = aspect >= thresholds["elongated_aspect_ratio"]
            is_small = reference_width * reference_height < 32.0 * 32.0
            groups = []
            if is_narrow:
                groups.append("narrow")
            if is_elongated:
                groups.append("elongated")
            if is_narrow or is_elongated:
                groups.append("narrow_or_elongated")
            if is_small:
                groups.append("small_area")
            if not groups:
                groups.append("other")
            boxes.append(
                {
                    "class_id": row["class_id"],
                    "xyxy": [x1, y1, x2, y2],
                    "groups": groups,
                    "shorter": shorter,
                    "aspect": aspect,
                }
            )
        records[image_path] = boxes
    return records


def predict_boxes(model, paths, batch):
    output = {}
    for start in range(0, len(paths), batch):
        batch_paths = paths[start : start + batch]
        images = [cv2.imread(str(path), cv2.IMREAD_COLOR) for path in batch_paths]
        results = model.predict(
            images,
            imgsz=320,
            conf=0.25,
            iou=0.7,
            max_det=300,
            device=0,
            workers=0,
            batch=batch,
            verbose=False,
        )
        for path, result in zip(batch_paths, results):
            boxes = result.boxes
            if boxes is None or len(boxes) == 0:
                output[path] = np.empty((0, 5), dtype=np.float32)
                continue
            output[path] = np.column_stack(
                [
                    boxes.xyxy.detach().cpu().numpy(),
                    boxes.cls.detach().cpu().numpy(),
                ]
            ).astype(np.float32)
    return output


def iou_matrix(left, right):
    if len(left) == 0 or len(right) == 0:
        return np.empty((len(left), len(right)), dtype=np.float32)
    lt = np.maximum(left[:, None, :2], right[None, :, :2])
    rb = np.minimum(left[:, None, 2:4], right[None, :, 2:4])
    wh = np.clip(rb - lt, 0, None)
    intersection = wh[..., 0] * wh[..., 1]
    left_area = np.clip(left[:, 2] - left[:, 0], 0, None) * np.clip(
        left[:, 3] - left[:, 1], 0, None
    )
    right_area = np.clip(right[:, 2] - right[:, 0], 0, None) * np.clip(
        right[:, 3] - right[:, 1], 0, None
    )
    union = left_area[:, None] + right_area[None, :] - intersection
    return intersection / np.clip(union, 1e-9, None)


def match_ground_truth(gt_boxes, predictions, threshold):
    matches = np.zeros(len(gt_boxes), dtype=bool)
    best_iou = np.zeros(len(gt_boxes), dtype=np.float32)
    if len(gt_boxes) == 0 or len(predictions) == 0:
        return matches, best_iou
    gt_xyxy = np.asarray([box["xyxy"] for box in gt_boxes], dtype=np.float32)
    gt_classes = np.asarray([box["class_id"] for box in gt_boxes], dtype=np.int32)
    ious = iou_matrix(gt_xyxy, predictions)
    for gt_index in range(len(gt_boxes)):
        class_matches = predictions[:, 4].astype(np.int32) == gt_classes[gt_index]
        if class_matches.any():
            best_iou[gt_index] = float(ious[gt_index, class_matches].max())
    candidates = []
    for gt_index, pred_index in np.argwhere(ious >= threshold):
        if gt_classes[gt_index] == int(predictions[pred_index, 4]):
            candidates.append((float(ious[gt_index, pred_index]), gt_index, pred_index))
    candidates.sort(reverse=True)
    used_gt = set()
    used_pred = set()
    for _, gt_index, pred_index in candidates:
        if gt_index in used_gt or pred_index in used_pred:
            continue
        used_gt.add(gt_index)
        used_pred.add(pred_index)
        matches[gt_index] = True
    return matches, best_iou


def main():
    torch.set_num_threads(4)
    plan = load_plan()
    batch = plan["protocol"]["batch"]
    raw = {
        "plan_sha256": __import__("hashlib").sha256(
            (OUT / "plan.json").read_bytes()
        ).hexdigest(),
        "records": [],
    }
    cache = {}
    for dataset in sorted({job["dataset"] for job in plan["models"]}):
        for split in plan["splits"]:
            paths = image_paths(dataset, split)
            cache[(dataset, split)] = (
                paths,
                ground_truth(dataset, split, plan, paths),
            )

    for job in plan["models"]:
        model = YOLO(str(ROOT / job["run"] / "weights/best.pt"))
        model.model.cuda().float().eval()
        for split in plan["splits"]:
            paths, gt_by_image = cache[(job["dataset"], split)]
            predictions = predict_boxes(model, paths, batch)
            for path in paths:
                gt_boxes = gt_by_image[path]
                match_50, best_iou = match_ground_truth(
                    gt_boxes, predictions[path], 0.50
                )
                match_75, _ = match_ground_truth(
                    gt_boxes, predictions[path], 0.75
                )
                for index, gt_box in enumerate(gt_boxes):
                    raw["records"].append(
                        {
                            "dataset": job["dataset"],
                            "split": split,
                            "variant": job["variant"],
                            "seed": job["seed"],
                            "image": str(path.relative_to(ROOT)),
                            "groups": gt_box["groups"],
                            "matched_50": bool(match_50[index]),
                            "matched_75": bool(match_75[index]),
                            "best_iou": float(best_iou[index]),
                        }
                    )
        print(f"completed {job['dataset']}/{job['variant']}/s{job['seed']}", flush=True)
    (OUT / "raw_results.json").write_text(
        json.dumps(raw, indent=2), encoding="utf-8"
    )
    print(f"wrote {len(raw['records'])} ground-truth records")


if __name__ == "__main__":
    main()
