"""Exploratory budgeted phase correction; no performance or novelty claim."""
import torch
from torch import nn
from torch.nn import functional as F
from phase_modules import PhaseInjection, PhaseBlock
from ultralytics.models.yolo.detect import DetectionTrainer


def budget_correction(detail, correction, rho=0.25, eps=1e-8):
    """Project each four-phase correction onto a relative L2 ball."""
    radius = rho * torch.linalg.vector_norm(detail, dim=2, keepdim=True)
    norm = torch.linalg.vector_norm(correction, dim=2, keepdim=True)
    return correction * (radius / norm.clamp_min(eps)).clamp(max=1)


class BudgetInjection(PhaseInjection):
    def __init__(self, shallow_channels, channels, variant='budget_full', rho=0.25):
        super().__init__(shallow_channels, channels, 'phase')
        if variant not in ('budget_full', 'budget_gate', 'budget_project', 'budget_constant'):
            raise ValueError(variant)
        self.variant, self.rho = variant, rho
        # Shared spatial gate: detail ratio, local energy contrast, semantic RMS.
        self.gate = nn.Conv2d(3, 1, 1)
        nn.init.zeros_(self.gate.weight)
        nn.init.zeros_(self.gate.bias)

    def packed(self, shallow, semantic):
        packed = F.pixel_unshuffle(self.compress(shallow), 2)
        b, c, h, w = packed.shape
        phases = packed.reshape(b, c // 4, 4, h, w)
        mean = phases.mean(2, keepdim=True)
        detail = phases - mean
        weights = .5 * self.condition(semantic).reshape_as(phases).tanh()
        delta = detail * weights
        delta = delta - delta.mean(2, keepdim=True)
        if self.variant in ('budget_full', 'budget_gate'):
            energy = detail.square().mean((1, 2))[:, None]
            dc = mean.square().mean((1, 2))[:, None]
            local = F.avg_pool2d(energy, 3, 1, 1, count_include_pad=False)
            sem = (semantic.square().mean(1, keepdim=True) + 1e-8).sqrt()
            sem = sem / sem.mean((2, 3), keepdim=True).clamp_min(1e-8)
            cues = torch.cat((energy / (energy + dc + 1e-8),
                              (energy - local) / (energy + local + 1e-8),
                              sem / (1 + sem)), 1)
            delta = delta * self.gate(cues).sigmoid()[:, :, None]
        elif self.variant == 'budget_constant':
            delta = delta * .5
        if self.variant in ('budget_full', 'budget_project', 'budget_constant'):
            delta = budget_correction(detail, delta, self.rho)
        return (phases + delta).reshape(b, c, h, w)


def attach_budget(model, variant='budget_full', init_seed=1016, rho=0.25):
    original = model.model[16]
    if isinstance(original, PhaseBlock):
        raise ValueError('Expected an unwrapped baseline model')
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(init_seed)
        addition = BudgetInjection(model.model[2].cv2.conv.out_channels,
                                   original.cv2.conv.out_channels, variant, rho)
    model.model[16] = PhaseBlock(original, addition)
    model.save = sorted(set(model.save + [2]))
    model.refinement_variant = variant
    model.branch_init_seed = init_seed
    return model


class BudgetTrainer(DetectionTrainer):
    variant = 'budget_full'
    init_seed = 1016

    def get_model(self, cfg=None, weights=None, verbose=True):
        wrapped = weights is not None and isinstance(weights.model[16], PhaseBlock)
        if wrapped:
            assert weights.refinement_variant == self.variant
            assert weights.branch_init_seed == self.init_seed
        model = attach_budget(super().get_model(cfg, None if wrapped else weights, verbose),
                              self.variant, self.init_seed)
        if wrapped:
            model.load(weights)
        return model
