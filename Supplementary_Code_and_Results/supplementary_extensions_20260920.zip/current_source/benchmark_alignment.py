"""Paired GPU-event latency check for the frozen alignment validation screen."""
import json
import random
import statistics
import time
from pathlib import Path

import torch
from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/alignment"
CYCLES = 7
FORWARDS_PER_CYCLE = 100
WARMUP_FORWARDS = 30


def main():
    torch.set_num_threads(4)
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    jobs = plan["jobs"]
    models = {}
    for job in jobs:
        checkpoint = ROOT / job["run"] / "weights/best.pt"
        models[job["id"]] = (
            YOLO(str(checkpoint)).model.cuda().float().eval().fuse(),
            job,
            checkpoint,
        )

    x = torch.rand(1, 3, 320, 320, device="cuda")
    event_ms = {key: [] for key in models}
    wall_ms = {key: [] for key in models}
    orders = []
    rng = random.Random(20260917)

    with torch.inference_mode():
        for model, _, _ in models.values():
            for _ in range(WARMUP_FORWARDS):
                model(x)
        torch.cuda.synchronize()

        for _ in range(CYCLES):
            order = list(models)
            rng.shuffle(order)
            orders.append(order)
            for key in order:
                model = models[key][0]
                for _ in range(5):
                    model(x)
                start_event = torch.cuda.Event(enable_timing=True)
                end_event = torch.cuda.Event(enable_timing=True)
                torch.cuda.synchronize()
                wall_start = time.perf_counter()
                start_event.record()
                for _ in range(FORWARDS_PER_CYCLE):
                    model(x)
                end_event.record()
                torch.cuda.synchronize()
                wall_ms[key].append(
                    (time.perf_counter() - wall_start) * 1000 / FORWARDS_PER_CYCLE
                )
                event_ms[key].append(
                    start_event.elapsed_time(end_event) / FORWARDS_PER_CYCLE
                )

    model_results = {}
    for key, (_, job, checkpoint) in models.items():
        event_trials = event_ms[key]
        wall_trials = wall_ms[key]
        event_median = statistics.median(event_trials)
        event_cv = statistics.pstdev(event_trials) / statistics.fmean(event_trials)
        first_two = statistics.fmean(event_trials[:2])
        last_two = statistics.fmean(event_trials[-2:])
        model_results[key] = {
            "job": job,
            "checkpoint": str(checkpoint),
            "event_trials_ms": event_trials,
            "wall_trials_ms": wall_trials,
            "event_median_ms": event_median,
            "event_min_ms": min(event_trials),
            "event_max_ms": max(event_trials),
            "event_cv": event_cv,
            "event_last_two_vs_first_two": last_two / first_two - 1,
            "wall_median_ms": statistics.median(wall_trials),
        }

    pair_results = {}
    for dataset in sorted({job["dataset"] for job in jobs}):
        keys = {
            job["variant"]: job["id"]
            for job in jobs
            if job["dataset"] == dataset
        }
        phase_key = keys["phase"]
        cross_key = keys["align_cross"]
        phase_trials = event_ms[phase_key]
        cross_trials = event_ms[cross_key]
        paired_deltas = [cross - phase for phase, cross in zip(phase_trials, cross_trials)]
        paired_ratios = [
            cross / phase - 1.0 for phase, cross in zip(phase_trials, cross_trials)
        ]
        pair_results[dataset] = {
            "phase_median_ms": statistics.median(phase_trials),
            "align_cross_median_ms": statistics.median(cross_trials),
            "median_relative_increase": (
                statistics.median(cross_trials) / statistics.median(phase_trials) - 1.0
            ),
            "paired_delta_ms": paired_deltas,
            "paired_delta_median_ms": statistics.median(paired_deltas),
            "paired_relative_increase": paired_ratios,
            "paired_relative_median": statistics.median(paired_ratios),
        }

    model_cvs = [result["event_cv"] for result in model_results.values()]
    model_drifts = [
        abs(result["event_last_two_vs_first_two"])
        for result in model_results.values()
    ]
    median_cv = statistics.median(model_cvs)
    max_abs_drift = max(model_drifts)
    timing_reliable = median_cv <= 0.05 and max_abs_drift <= 0.05

    result = {
        "protocol": (
            "validation checkpoints only; batch1 320 FP32 fused; "
            f"{WARMUP_FORWARDS} warmup; {CYCLES} randomized cycles x "
            f"{FORWARDS_PER_CYCLE} forward-only passes"
        ),
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "orders": orders,
        "models": model_results,
        "pairs": pair_results,
        "drift": {
            "model_event_cv": model_cvs,
            "median_model_event_cv": median_cv,
            "model_abs_first_last_drift": model_drifts,
            "max_abs_first_last_drift": max_abs_drift,
            "reliability_rule": "median CV <= 5% and max abs first/last drift <= 5%",
            "timing_reliable": timing_reliable,
        },
        "latency_gate": {
            "frozen_max_relative_increase": plan["gate"][
                "forward_latency_increase_max_fraction"
            ],
            "result": (
                "inconclusive_timing_drift"
                if not timing_reliable
                else (
                    "pass"
                    if all(
                        pair["median_relative_increase"]
                        <= plan["gate"]["forward_latency_increase_max_fraction"]
                        for pair in pair_results.values()
                    )
                    else "fail"
                )
            ),
        },
    }
    (OUT / "latency.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "timing_reliable": timing_reliable,
                "median_model_event_cv": median_cv,
                "max_abs_first_last_drift": max_abs_drift,
                "pairs": pair_results,
                "latency_gate": result["latency_gate"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
