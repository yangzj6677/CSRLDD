"""All-or-none test evaluation after all 24 validation runs complete."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/budget_experiment'
plan=json.loads((OUT/'plan.json').read_text())
test_plan=json.loads((OUT/'test_plan.json').read_text())
for source,expected in test_plan['source_hashes'].items():
    assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest()==expected,source
assert test_plan['jobs']==[j['id'] for j in plan['jobs']]
missing=[j['id'] for j in plan['jobs'] if not (ROOT/j['run']/'val_summary.json').exists()]
assert not missing,f'Validation matrix incomplete: {len(missing)} jobs'
state=json.loads((OUT/'state.json').read_text())
assert state['status']=='complete' and len(state['completed'])==24
status={'total':24,'completed':[],'active':None,'failures':[]}
def save():
    p=OUT/'test_state.tmp'; p.write_text(json.dumps(status,indent=2)); p.replace(OUT/'test_state.json')
for job in plan['jobs']:
    target=ROOT/job['run']/'posthoc_test_summary.json'
    if target.exists():
        assert json.loads(target.read_text())['job']==job
        status['completed'].append(job['id']); continue
    status['active']=job['id']; save()
    with (OUT/(job['id']+'_test.log')).open('a',encoding='utf-8') as log:
        code=subprocess.call([sys.executable,str(ROOT/'run_budget_test_job.py'),'--job',job['id']],
                             cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    if code or not target.exists():
        status['failures'].append({'job':job['id'],'exit_code':code}); save(); raise SystemExit(1)
    status['completed'].append(job['id']); status['active']=None; save()
status['status']='complete_known_test_reuse'; save()
