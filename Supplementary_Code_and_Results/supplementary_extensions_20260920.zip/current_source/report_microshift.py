"""Aggregate the frozen micro-shift diagnostic and evaluate its decision gate."""
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/microshift"


def load_results():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    raw = json.loads((OUT / "raw_results.json").read_text(encoding="utf-8"))
    return plan, raw


def grouped(records):
    output = {}
    for record in records:
        key = (record["dataset"], record["model"])
        output.setdefault(key, []).append(record)
    return output


def image_means(records):
    grouped_images = {}
    for record in records:
        grouped_images.setdefault(record["image"], []).append(record["f1_50"])
    return {
        image: float(np.mean(values))
        for image, values in sorted(grouped_images.items())
    }


def bootstrap_ci(values, samples, confidence, seed):
    values = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(values), size=(samples, len(values)))
    means = values[indices].mean(axis=1)
    alpha = (1.0 - confidence) / 2.0
    return {
        "mean": float(values.mean()),
        "ci_lower": float(np.quantile(means, alpha)),
        "ci_upper": float(np.quantile(means, 1.0 - alpha)),
    }


def main():
    plan, raw = load_results()
    records = raw["records"]
    grouped_records = grouped(records)
    shifts = {
        (int(dx), int(dy))
        for dx, dy in plan["shifts_pixels"]
    }

    per_shift = {}
    for (dataset, model), rows in grouped_records.items():
        for dx, dy in sorted(shifts):
            selected = [
                row["f1_50"]
                for row in rows
                if row["dx"] == dx and row["dy"] == dy
            ]
            per_shift.setdefault((dataset, model), {})[f"{dx:+d},{dy:+d}"] = {
                "mean_f1_50": float(np.mean(selected)),
                "mean_f1_75": float(
                    np.mean(
                        [
                            row["f1_75"]
                            for row in rows
                            if row["dx"] == dx and row["dy"] == dy
                        ]
                    )
                ),
            }

    gate_results = {}
    for dataset in sorted(plan["models"]):
        baseline = image_means(
            [
                row
                for row in grouped_records[(dataset, "baseline")]
            ]
        )
        phase = image_means(
            [
                row
                for row in grouped_records[(dataset, "phase")]
            ]
        )
        assert list(baseline) == list(phase)
        differences = 100.0 * np.asarray(
            [baseline[image] - phase[image] for image in baseline]
        )
        bootstrap = bootstrap_ci(
            differences,
            plan["gate"]["paired_bootstrap_samples"],
            plan["gate"]["paired_bootstrap_confidence"],
            plan["gate"]["paired_bootstrap_seed"],
        )
        bootstrap["drop_pp"] = bootstrap["mean"]
        bootstrap["ci_lower_pp"] = bootstrap["ci_lower"]
        bootstrap["ci_upper_pp"] = bootstrap["ci_upper"]
        gate_results[dataset] = bootstrap

    minimum = plan["gate"]["both_datasets_min_phase_specific_drop_pp"]
    passed = all(
        result["drop_pp"] >= minimum and result["ci_lower_pp"] > 0.0
        for result in gate_results.values()
    )
    gate = {
        "passed": passed,
        "minimum_drop_pp": minimum,
        "requires_ci_lower_above_zero": True,
        "datasets": gate_results,
    }

    summary = {
        "plan_sha256": raw["plan_sha256"],
        "determinism": raw["determinism"],
        "per_shift": {
            f"{dataset}/{model}": values
            for (dataset, model), values in per_shift.items()
        },
        "gate": gate,
    }
    (OUT / "diagnostic_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    lines = [
        "# 微平移一致性诊断",
        "",
        "使用验证集，对输入执行轴向 ±1/±2 像素平移，并把预测框逆变换回原坐标。",
        "匹配指标为类别一致的贪心 IoU 匹配 F1；本诊断不评估测试集。",
        "",
        "|数据集|baseline 平均 F1|phase 平均 F1|phase 额外下降(pp)|95% bootstrap CI|",
        "|---|---:|---:|---:|---:|",
    ]
    for dataset, result in sorted(gate_results.items()):
        baseline_mean = float(
            np.mean(
                [
                    row["f1_50"]
                    for row in grouped_records[(dataset, "baseline")]
                ]
            )
        )
        phase_mean = float(
            np.mean(
                [
                    row["f1_50"]
                    for row in grouped_records[(dataset, "phase")]
                ]
            )
        )
        lines.append(
            f"|{dataset}|{baseline_mean:.4f}|{phase_mean:.4f}|"
            f"{result['drop_pp']:+.4f}|"
            f"[{result['ci_lower_pp']:+.4f}, {result['ci_upper_pp']:+.4f}]|"
        )
    lines.extend(
        [
            "",
            f"冻结门槛结果：{'支持' if passed else '不支持'}。",
            "支持要求两个数据集均达到至少 0.5 个百分点的 phase 额外下降，"
            "且图像配对 bootstrap 的 95% 下界大于 0。",
            "",
            "该诊断是单种子、单检查点的探索性证据；bootstrap 只反映验证图像差异，"
            "不恢复训练种子差异，也不构成统计显著性或独立确认。",
        ]
    )
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
