"""Freeze the P2-self-condition mechanism ablation."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/self_condition"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / "plan.json").exists(), "Do not overwrite frozen plan"
    phase_controls = {
        "neu": {
            42: "runs/alignment/neu_phase_s42_r320_120e",
            43: "runs/confirmation/phase_s43_120e",
            44: "runs/confirmation/phase_s44_120e",
        },
        "deeppcb": {
            42: "runs/confirmation/deeppcb_phase_s42_120e",
            43: "runs/confirmation/deeppcb_phase_s43_120e",
            44: "runs/confirmation/deeppcb_phase_s44_120e",
        },
    }
    jobs = []
    for dataset in ("deeppcb", "neu"):
        for seed in (42, 43, 44):
            name = (
                f"{dataset}_phase_self_s{seed}_120e"
                if dataset != "neu"
                else f"phase_self_s{seed}_120e"
            )
            jobs.append(
                {
                    "id": f"{dataset}_phase_self_s{seed}_r320_120e",
                    "dataset": dataset,
                    "variant": "phase_self",
                    "seed": seed,
                    "init_seed": 1016,
                    "imgsz": 320,
                    "epochs": 120,
                    "batch": 16,
                    "run": f"runs/self_condition/{name}",
                    "phase_control": phase_controls[dataset][seed],
                }
            )
    for job in jobs:
        assert (ROOT / job["phase_control"] / "val_summary.json").exists()

    sources = [
        "prepare_self_condition.py",
        "run_self_condition_queue.py",
        "report_self_condition.py",
        "run_innovation.py",
        "innovation_modules.py",
        "phase_modules.py",
        "head_detail_modules.py",
        "requirements-lock.txt",
        "models/yolo11n.pt",
        "data/neu_yolo/data.yaml",
        "data/deeppcb_yolo/data.yaml",
        "data/neu_yolo/manifest.json",
        "data/deeppcb_yolo/manifest.json",
    ]
    sources.extend(job["phase_control"] + "/val_summary.json" for job in jobs)
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "stage": "p2_self_condition_mechanism_screen",
        "jobs": jobs,
        "project": "runs/self_condition",
        "selection": "validation only; no test evaluation",
        "primary_comparison": "phase - phase_self",
        "primary_endpoint": "mAP50-95",
        "gate": {
            "both_datasets_min_pp": 0.0,
            "at_least_one_dataset_min_pp": 0.5,
        },
        "source_hashes": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in sources
        },
        "caveats": [
            "phase controls are reused from the frozen main matrix rather than retrained in this queue",
            "both branches have the same condition-layer parameter count",
            "three training seeds are paired optimization runs, not independent data samples",
            "only validation is used for this mechanism decision",
        ],
    }
    (OUT / "plan.json").write_text(
        json.dumps(plan, indent=2), encoding="utf-8"
    )
    print(f"Frozen {len(jobs)} phase_self jobs")


if __name__ == "__main__":
    main()
