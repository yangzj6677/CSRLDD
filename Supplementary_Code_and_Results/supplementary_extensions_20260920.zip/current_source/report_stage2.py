"""Report observed stage-two progress; never label planned jobs as completed."""
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reports/stage2'
plan=json.loads((OUT/'plan.json').read_text())
records=[]
progress=[]
for job in plan['jobs']:
    run=ROOT/job['run']
    rows=list(csv.DictReader((run/'results.csv').open())) if (run/'results.csv').exists() else []
    summary=run/'val_summary.json'
    item={'job':job,'epochs_observed':int(rows[-1]['epoch']) if rows else 0,'complete':summary.exists()}
    if summary.exists():
        r=json.loads(summary.read_text())
        assert r['job']==job and item['epochs_observed']==120
        records.append(r)
        test_summary=run/'posthoc_test_summary.json'
        if test_summary.exists():
            t=json.loads(test_summary.read_text())
            assert t['job']==job
            records.append(t)
    progress.append(item)
groups={}
for row in records:
    j=row['job']; key=(j['family'],j['dataset'],row['split'],j['variant'],j['imgsz'])
    groups.setdefault(key,[]).append(100*row['metrics']['metrics/mAP50-95(B)'])
aggregates=[{'family':k[0],'dataset':k[1],'split':k[2],'variant':k[3],'imgsz':k[4],'n':len(v),'mean':statistics.mean(v),
             'sd':statistics.stdev(v) if len(v)>1 else None,'complete_three_seeds':len(v)==3} for k,v in groups.items()]
indexed={(r['job']['family'],r['job']['dataset'],r['split'],r['job']['variant'],r['job']['seed'],
          r['job']['imgsz'],r['job']['init_seed']):100*r['metrics']['metrics/mAP50-95(B)'] for r in records}
paired=[]
for split in ('val','test'):
    for dataset in ('neu','deeppcb'):
        for candidate,control in (('phase','phase_uniform'),('phase','phase_capacity'),
                                  ('phase','phase_uncentered'),('phase_capacity','phase_uniform'),
                                  ('phase_uncentered','phase_uniform')):
            values=[]
            for seed in (42,43,44):
                keys=[('mechanism',dataset,split,v,seed,320,1016) for v in (candidate,control)]
                if all(k in indexed for k in keys): values.append(indexed[keys[0]]-indexed[keys[1]])
            paired.append({'family':'mechanism','dataset':dataset,'split':split,'candidate':candidate,'control':control,
                           'differences_pp':values,'n':len(values),'mean_pp':statistics.mean(values) if values else None,
                           'sd_pp':statistics.stdev(values) if len(values)>1 else None,'complete_three_seeds':len(values)==3})
# Resolution contrasts and paired difference-in-differences relative to the new 320 runs.
for split in ('val','test'):
    for candidate,control in (('phase','phase_uniform'),('phase','baseline'),('phase_uniform','baseline')):
        values=[]
        for seed in (42,43,44):
            keys=[('resolution','deeppcb',split,v,seed,640,1016) for v in (candidate,control)]
            if all(k in indexed for k in keys): values.append(indexed[keys[0]]-indexed[keys[1]])
        paired.append({'family':'resolution','dataset':'deeppcb','split':split,'candidate':candidate,'control':control,
                       'differences_pp':values,'n':len(values),'mean_pp':statistics.mean(values) if values else None,
                       'sd_pp':statistics.stdev(values) if len(values)>1 else None,'complete_three_seeds':len(values)==3})
did=[]
for seed in (42,43,44):
    k640=[('resolution','deeppcb','val',v,seed,640,1016) for v in ('phase','phase_uniform')]
    k320=[('mechanism','deeppcb','val',v,seed,320,1016) for v in ('phase','phase_uniform')]
    if all(k in indexed for k in k640+k320):
        did.append((indexed[k640[0]]-indexed[k640[1]])-(indexed[k320[0]]-indexed[k320[1]]))
paired.append({'family':'resolution_interaction','dataset':'deeppcb','candidate':'phase-minus-uniform@640',
               'control':'phase-minus-uniform@320','differences_pp':did,'n':len(did),
               'mean_pp':statistics.mean(did) if did else None,
               'sd_pp':statistics.stdev(did) if len(did)>1 else None,'complete_three_seeds':len(did)==3})
# Each alternate branch initialization is compared to the fixed-1016 run at the same training seed.
for variant in ('phase_uniform','phase'):
    values=[]
    for seed in (42,43,44):
        alt=('initialization','deeppcb',variant,seed,320,2000+seed)
        alt=('initialization','deeppcb','val',variant,seed,320,2000+seed)
        fixed=('mechanism','deeppcb','val',variant,seed,320,1016)
        if alt in indexed and fixed in indexed: values.append(indexed[alt]-indexed[fixed])
    paired.append({'family':'initialization','dataset':'deeppcb','candidate':variant+'@alternative',
                   'control':variant+'@1016','differences_pp':values,'n':len(values),
                   'mean_pp':statistics.mean(values) if values else None,
                   'sd_pp':statistics.stdev(values) if len(values)>1 else None,'complete_three_seeds':len(values)==3})
test_completed=sum(1 for r in records if r['split']=='test')
result={'updated_utc':datetime.now(timezone.utc).isoformat(),'complete':sum(1 for r in records if r['split']=='val')==39 and test_completed==39,'planned':39,
        'completed':sum(1 for r in records if r['split']=='val'),'test_completed':test_completed,'records':records,'progress':progress,'aggregates':aggregates,'paired':paired}
(OUT/'results.json').write_text(json.dumps(result,indent=2))
val_completed=sum(1 for r in records if r['split']=='val')
text=f'# 第二阶段实验进度\n\n完整验证完成 **{val_completed}/39**；冻结测试完成 **{test_completed}/39**；已记录训练轮数 **{sum(p["epochs_observed"] for p in progress)}/4680**。\n\n'
text+='指标为验证集结果；未完成三种子的组不作定稿结论。\n\n| 运行 | 已记录轮数 | 完整验证 |\n|---|---:|---|\n'
text+='\n'.join(f'| {p["job"]["id"]} | {p["epochs_observed"]} | {"完成" if p["complete"] else "待完成"} |' for p in progress)
(OUT/'实验进度.md').write_text(text+'\n',encoding='utf-8')
print(f'validation {val_completed}/39; test {test_completed}/39; {sum(p["epochs_observed"] for p in progress)}/4680 epochs recorded.')
