"""Report the frozen P4-context and P3-SE validation comparisons."""
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "reports/context_experiment"


def map5095(path):
    summary = json.loads(path.read_text(encoding="utf-8"))
    return 100.0 * summary["metrics"]["metrics/mAP50-95(B)"]


def paired(candidate, control, dataset):
    rows = [
        job
        for job in candidate
        if job["dataset"] == dataset
    ]
    values = []
    per_seed = {}
    for job in sorted(rows, key=lambda item: item["seed"]):
        candidate_ap = map5095(ROOT / job["run"] / "val_summary.json")
        control_job = next(
            item
            for item in control
            if item["dataset"] == dataset and item["seed"] == job["seed"]
        )
        control_ap = map5095(
            ROOT / control_job["run"] / "val_summary.json"
        )
        difference = candidate_ap - control_ap
        values.append(difference)
        per_seed[str(job["seed"])] = difference
    return {
        "per_seed_pp": per_seed,
        "mean_pp": statistics.fmean(values),
        "sample_sd_pp": statistics.stdev(values),
        "positive_seeds": sum(value > 0.0 for value in values),
    }


def gate_passed(results, config):
    return all(
        result["mean_pp"] >= config["both_datasets_min_pp"]
        for result in results.values()
    ) and any(
        result["mean_pp"] >= config["at_least_one_dataset_min_pp"]
        for result in results.values()
    )


def main():
    plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
    candidates = {job["variant"]: [] for job in plan["jobs"]}
    for job in plan["jobs"]:
        candidates[job["variant"]].append(job)
    phase_jobs = [
        {
            **job,
            "run": job["phase_control"],
        }
        for job in plan["jobs"]
        if job["variant"] == "phase_p4ctx"
    ]
    results = {}
    for dataset in ("deeppcb", "neu"):
        p4 = [
            job
            for job in candidates["phase_p4ctx"]
            if job["dataset"] == dataset
        ]
        se = [
            job
            for job in candidates["phase_se"]
            if job["dataset"] == dataset
        ]
        phase = [
            job
            for job in phase_jobs
            if job["dataset"] == dataset
        ]
        results[dataset] = {
            "p4ctx_minus_phase": paired(p4, phase, dataset),
            "p4ctx_minus_se": paired(p4, se, dataset),
        }
    gate = {
        "vs_phase": {
            "passed": gate_passed(
                {
                    dataset: values["p4ctx_minus_phase"]
                    for dataset, values in results.items()
                },
                plan["gate"]["vs_phase"],
            ),
            **plan["gate"]["vs_phase"],
        },
        "vs_phase_se": {
            "passed": gate_passed(
                {
                    dataset: values["p4ctx_minus_se"]
                    for dataset, values in results.items()
                },
                plan["gate"]["vs_phase_se"],
            ),
            **plan["gate"]["vs_phase_se"],
        },
    }
    output = {"results": results, "gate": gate}
    (OUT / "results.json").write_text(
        json.dumps(output, indent=2), encoding="utf-8"
    )
    lines = [
        "# P4上下文条件模块：验证筛选",
        "",
        "比较 `phase_p4ctx` 与同种子 `phase`、近参数量 `phase_se`。仅使用验证集。",
        "",
        "|数据集|比较|逐种子差值(pp)|均值±样本SD|正向种子|",
        "|---|---|---|---:|---:|",
    ]
    for dataset, values in results.items():
        for name, comparison in values.items():
            per_seed = ", ".join(
                f"{value:+.3f}" for value in comparison["per_seed_pp"].values()
            )
            lines.append(
                f"|{dataset}|{name}|{per_seed}|"
                f"{comparison['mean_pp']:+.3f} ± "
                f"{comparison['sample_sd_pp']:.3f}|"
                f"{comparison['positive_seeds']}/3|"
            )
    lines.extend(
        [
            "",
            f"相对 phase 门槛：{'支持' if gate['vs_phase']['passed'] else '不支持'}。",
            f"相对 phase_se 对照门槛：{'支持' if gate['vs_phase_se']['passed'] else '不支持'}。",
            "",
            "只有两个比较均支持时，才把增益解释为P4跨层上下文，而不是任意通道注意力。",
            "该筛选不回看测试集；失败则停止该候选。",
        ]
    )
    (OUT / "结论.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(gate, indent=2))


if __name__ == "__main__":
    main()
