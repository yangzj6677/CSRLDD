# NEU phase_head recovery

- Date: 2026-09-19
- Event: the external monitor session was interrupted, which terminated the background queue during `neu_phase_head_s42_120e` near epoch 81.
- Damage: both `last.pt` and `best.pt` were truncated and could not be loaded.
- Preserved: the interrupted run, log, and state snapshot are archived under `runs/head_detail_experiment/failures/` and `reports/head_detail_experiment/failures/`.
- Decision: the user explicitly requested continuation. The affected NEU `phase_head` jobs are rebuilt from the original frozen plan and weights; the other nine completed jobs are retained and skipped.
- Scope: no hyperparameter, source, or threshold changes. This is a recovery rerun after checkpoint corruption, not an automatic retry of an accuracy failure.
