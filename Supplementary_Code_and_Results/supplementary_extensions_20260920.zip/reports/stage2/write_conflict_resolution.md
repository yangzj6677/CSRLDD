# Stage2 测试状态写入冲突处理记录

- 发生位置：`evaluate_stage2_tests.py` 保存第 39 项测试的 active 状态时。
- 错误：Windows `os.replace(test_state.tmp, test_state.json)` 返回 `WinError 5`。
- 完整性检查：前 38 项 `posthoc_test_summary.json` 已存在；`test_state.json` 记录 38 项完成，残留 `test_state.tmp` 记录第 39 项为 active；失败列表为空。
- 处理：保留所有已完成测试输出，仅删除残留临时状态文件，然后重新调用冻结评估入口。入口会验证源文件哈希、扫描并跳过已有 38 项结果，只执行缺失的第 39 项。
- 说明：未修改冻结模型、实验计划、训练结果或测试实现。
