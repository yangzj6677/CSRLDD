## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: validate
- Origin Date: 2026-09-14
- Verification Status: ANALYZED
- Version Label: validation_v1
- Upstream Dependencies: stage2 `plan.json`, `results.json`, `module_checks.json`; stage-one `confirmation_plan.json`

## Validation Report

- **Source**: stage2-mechanism-24-run-block
- **Overall Confidence**: CAUTION
- **Coverage**: 24/24 planned mechanism runs; two datasets × four variants × three training seeds
- **Analysis unit**: one independently trained model under a fixed dataset split
- **Primary endpoint**: validation mAP50–95; percentage-point differences paired by training seed

The mechanism block completed without a missing run. This is a post-stage-one, test-informed extension and does not provide a fresh independent test set. With three seeds, the report remains descriptive: it does not estimate population-level significance, equivalence, or tail behavior.

### Statistical Findings

| Metric | Test | Value | Effect Size | Confidence |
|---|---|---:|---|---|
| NEU conditioned − unconditional | Three paired seed differences | +0.357 ± 0.565 pp | Descriptive; no standardized effect | CAUTION |
| NEU conditioned − capacity-matched | Three paired seed differences | +0.763 ± 0.389 pp; all three positive | Descriptive; no standardized effect | CAUTION |
| NEU conditioned − uncentered | Three paired seed differences | +0.739 ± 0.669 pp; all three positive | Descriptive; no standardized effect | CAUTION |
| DeepPCB conditioned − unconditional | Three paired seed differences | +2.209 ± 1.542 pp; all three positive | Descriptive; no standardized effect | CAUTION |
| DeepPCB conditioned − capacity-matched | Three paired seed differences | +2.240 ± 1.610 pp; all three positive | Descriptive; no standardized effect | CAUTION |
| DeepPCB conditioned − uncentered | Three paired seed differences | +2.569 ± 1.753 pp; all three positive | Descriptive; no standardized effect | CAUTION |

Values are mean ± sample SD of paired differences, not confidence intervals. No p-values or multiplicity-adjusted tests are reported because the three fixed-seed repeats do not justify strong population inference.

### Warnings

| Type | Detail | Affected |
|---|---|---|
| Test-informed design | The mechanism extension was designed after stage-one test results were known. | All stage-two claims |
| Validation selection | Every reported model uses its validation-selected EMA checkpoint, so the same split selects and describes performance. | Validation mAP50–95 |
| Small repeat count | Three training seeds reveal direction and dispersion but weakly characterize the training distribution. | All paired contrasts |
| Capacity-control interpretation | The capacity-matched operation also changes the conditioning input and transform, so the contrast does not isolate semantic conditioning alone. | Conditioned − capacity-matched |
| Fixed data partitions | Seeds change training stochasticity, not image membership. | External validity |
| Multiple descriptive contrasts | Several predeclared contrasts are shown without a confirmatory familywise error claim. | Mechanism comparisons |

### Fallacy Scan

- **Coverage**: 11/11 fallacy types checked

| Fallacy | Severity | Detail | Handling |
|---|---|---|---|
| Simpson's paradox | NOTE | No direction reversal was found between the two dataset-specific summaries; pooled cross-dataset averaging is not used. | Keep datasets separate. |
| Ecological fallacy | NOTE | Results concern trained models on fixed benchmark splits, not individual defects or factories. | Do not infer object- or factory-level effects. |
| Berkson's paradox | NOTE | Public benchmark selection limits representativeness, but no unexpected correlation is estimated. | Retain benchmark-selection limitation. |
| Collider bias | NOTE | No covariate-adjusted causal model is fitted. | Not applicable to the reported paired summaries. |
| Base-rate neglect | CAUTION | Class-wise prevalence differs and aggregate mAP does not describe operational defect prevalence. | Retain per-class AP and avoid deployment PPV claims. |
| Regression to the mean | NOTE | Variants were not selected for this block from extreme stage-two scores; stage-one-informed design remains separately disclosed. | Do not frame stage-two validation as untouched confirmation. |
| Survivorship bias | NOTE | All 24 planned mechanism runs completed and are retained. | Continue all-run reporting. |
| Look-elsewhere effect | CAUTION | Multiple variants and contrasts exist after earlier exploration. | Keep the frozen contrast list and report unfavorable results. |
| Garden of forking paths | CAUTION | The broader project includes prior exploratory screens; the stage-two plan was frozen only after stage-one results. | Preserve chronology, plan hash, and exploratory label. |
| Correlation != causation | CAUTION | Higher AP for the conditioned model does not prove mean preservation caused the gain. | Describe an empirical contrast, not a unique internal mechanism. |
| Reverse causality | NOTE | Temporal reverse causality is not applicable to randomized training interventions. | No action beyond avoiding observational causal analogies. |

### Reproducibility

- **Method**: deterministic re-run comparison for the 12 phase/phase-uniform dataset-seed configurations; first execution for capacity-matched and uncentered variants
- **Verdict**: PARTIALLY_REPRODUCIBLE

| Metric set | Original | Re-run | Difference | Status |
|---|---|---|---:|---|
| 12 phase/phase-uniform validation mAP50–95 values | Stage-one records | Stage-two mechanism records | Exact maximum difference 0.0 | MATCH |
| 12 capacity-matched/uncentered values | No prior full run | Stage-two records | Not applicable | CANNOT VERIFY |

The exact match verifies deterministic replay for the repeated subset under the available environment. It does not verify the new variants twice or prove the authenticity of raw data. Therefore the passport remains `ANALYZED`, rather than upgrading the complete mechanism block to `VERIFIED`.
