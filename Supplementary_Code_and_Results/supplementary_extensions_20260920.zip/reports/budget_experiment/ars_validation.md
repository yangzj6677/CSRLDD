## Material Passport

- Origin Skill: experiment-agent
- Origin Mode: validate
- Origin Date: 2026-09-15
- Verification Status: VERIFIED
- Version Label: validation_v1

## Validation Report

- **Source**: frozen Stage2 tests (39/39) and budget experiment validation/test matrix (24/24)
- **Overall Confidence**: CAUTION

### Statistical Findings

All values are paired seed differences in mAP50–95 percentage points, reported as mean ± sample SD for seeds 42/43/44. With only three paired seeds, no p-values or claims of statistical significance are made.

| Metric | Test | Value | Interpretation | Confidence |
|---|---|---:|---|---|
| Original phase vs phase-uniform, NEU test | paired descriptive, n=3 | +0.284 ± 1.355 | small and directionally inconsistent (1/3 positive) | CAUTION |
| Original phase vs phase-uniform, DeepPCB test | paired descriptive, n=3 | +3.311 ± 3.486 | positive mean but one negative seed | CAUTION |
| Original phase vs capacity control, NEU test | paired descriptive, n=3 | +0.821 ± 0.696 | all three seeds positive | CAUTION |
| Original phase vs uncentered control, NEU test | paired descriptive, n=3 | +0.698 ± 0.230 | all three seeds positive | CAUTION |
| Original phase vs capacity control, DeepPCB test | paired descriptive, n=3 | +2.881 ± 3.725 | one negative seed | CAUTION |
| Original phase vs uncentered control, DeepPCB test | paired descriptive, n=3 | +2.401 ± 2.249 | one negative seed | CAUTION |
| Budget-full vs phase, NEU validation | paired descriptive, n=3 | -0.263 ± 0.282 | budget-full lower on all seeds | SOLID descriptive direction |
| Budget-full vs phase, NEU test | paired descriptive, n=3 | -0.627 ± 0.765 | budget-full lower on 2/3 seeds | CAUTION |
| Budget-full vs phase, DeepPCB validation | paired descriptive, n=3 | -3.089 ± 1.037 | budget-full lower on all seeds | SOLID descriptive direction |
| Budget-full vs phase, DeepPCB test | paired descriptive, n=3 | -4.906 ± 1.811 | budget-full lower on all seeds | SOLID descriptive direction |

### Decision

The new budget-constrained full mechanism does **not** improve the existing phase-conditioned model. It should not replace the current main method or be presented as a performance contribution. Its most defensible use is a negative ablation showing that explicit local energy projection can over-constrain useful detail transfer, especially on DeepPCB. The original phase-conditioned, mean-preserving mechanism remains the paper's main method.

The budget ablation still adds useful scientific evidence: the learned gate alone and the projected variants do not explain the original gain, while the strong DeepPCB degradation under the full constraint identifies a boundary condition. This supports a restrained claim about preserving local mean without imposing a hard detail-energy cap.

### Warnings

| Type | Detail | Affected |
|---|---|---|
| Small sample | Three paired seeds estimate direction and variability but do not support reliable significance testing | all comparisons |
| Multiple comparisons | Many ablation contrasts were inspected; no correction was applied because results are descriptive | all secondary contrasts |
| Known test reuse | Test sets were evaluated after the validation matrix and are labeled exploratory/confirmatory reuse; they must not be used for further model selection | Stage2 and budget tests |
| Dataset dependence | Original phase benefit is much larger on DeepPCB than NEU and disappears at 640 resolution | generalization claim |
| Negative mechanism result | Budget-full underperforms phase on both datasets and especially DeepPCB | budget mechanism claim |

### Fallacy Scan

- **Coverage**: 11/11 fallacy types checked

| Fallacy | Severity | Detail | Recommendation |
|---|---|---|---|
| Simpson's paradox | NOTE | Aggregate claims are separated by dataset and split; no direction reversal is hidden by pooling | keep dataset-specific results |
| Ecological fallacy | NOTE | Inference remains at run/dataset level | avoid image-level causal claims |
| Berkson's paradox | NOTE | Not applicable to the fixed benchmark sampling design | document dataset construction |
| Collider bias | NOTE | No post-treatment covariate adjustment is used | no action |
| Base-rate neglect | CAUTION | mAP does not expose deployment prevalence or false-alarm burden | add precision/recall and deployment discussion |
| Regression to the mean | NOTE | Models were not selected from extreme seeds for the frozen matrix | keep all seeds |
| Survivorship bias | NOTE | All planned runs and tests completed; no failed runs were excluded | report 24/24 and 39/39 completion |
| Look-elsewhere effect | CAUTION | Numerous ablations could invite selective reporting | disclose the complete frozen matrix, including negative results |
| Garden of forking paths | CAUTION | Budget mechanism was designed after Stage2 observations | label it as a subsequent ablation, not preregistered confirmation |
| Correlation != causation | CAUTION | Ablations support component attribution only within this training setup | use “is associated with” or “supports,” not universal causal language |
| Reverse causality | NOTE | Not applicable to controlled architecture interventions | no action |

### Reproducibility

- **Method**: re-run stochastic with frozen source hashes, fixed data splits, fixed initialization seed, and three training seeds
- **Verdict**: PARTIALLY_REPRODUCIBLE

All 39 Stage2 validation/test pairs and all 24 budget validation/test pairs completed. Source hashes and checkpoint identities are recorded in per-run summaries. Reproducibility remains partial because results were not independently rerun on another machine or software stack.

