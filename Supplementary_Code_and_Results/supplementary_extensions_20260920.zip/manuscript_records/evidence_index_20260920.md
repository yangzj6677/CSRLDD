# 已完成实验的证据索引与稿件缺口

更新：本索引初版漏列自条件、P4上下文、检测头与困难组诊断，详见[遗漏阶段补记](omitted_stage_addendum_20260920.md)。扩展归档现覆盖135项后续训练、204份摘要。同环境12项已完成；全部AP与历史对应结果相同，不能计为新增独立种子。正文4.5–4.6和补充S8已同步。

## Material Passport
- Origin Skill: academic-research-suite
- Origin Mode: evidence organization / manuscript update
- Origin Date: 2026-09-20（北京时间）
- Verification Status: ANALYZED；非独立复现、非投稿就绪证明

以下路径相对于本文件。汇总中的百分点差值不能混同于相对百分比；三种子离散度为配对差值样本SD。

|阶段|主要证据入口|范围及解释边界|稿件状态|
|---|---|---|---|
|原主实验|[主结果](confirmation_results.json)、[计划](confirmation_plan.json)|24训练；原四模型矩阵；NEU此前已接触测试，不能称全研究预注册|原摘要及4.1–4.4保留|
|第二阶段|[机制验证](../stage2/机制实验结果.md)、[完整结果](../stage2/results.json)、[进度](../stage2/实验进度.md)、[测试计划](../stage2/test_plan.json)|39训练及39复用测试；容量、去中心化、分辨率与初始化；后验扩展|4.5加入机制验证；分辨率/初始化及复用测试完整表已纳入补充S9|
|预算约束|[全部结果](../budget_experiment/实验结果.md)、[设计](../budget_experiment/性能实验设计.md)|24训练/验证/复用测试；full、gate、project、constant均保留；失败不归因于投影单因素|4.6加入full负结果；全部消融保留原报告|
|旋转|[结论](../frontier/阶段结论.md)、[全部结果](../frontier/results.json)、[计划](../frontier/plan.json)|8项单种子验证；动态候选两数据集下降；静态DeepPCB正向未选为替代赢家|4.6简述，全部候选见原始表|
|局部对齐|[结论](../alignment/结论.md)、[结果](../alignment/results.json)、[执行说明](../alignment/执行说明.md)|10项单种子验证；所有新增变体两数据集均未超phase；恢复及环境变更保留记录|4.6加入，计时明确不可靠|
|微平移|[诊断结论](../microshift/结论.md)、[原始输出](../microshift/raw_results.json)、[计划](../microshift/plan.json)|预测匹配F1，不是AP；图像bootstrap不覆盖训练种子方差；未支持一致性训练|4.6说明诊断边界|
|多尺度|[结果](../multiscale_experiment/结论.md)、[逐模型核查](../multiscale_experiment/artifact_audit.json)、[限制](../multiscale_experiment/核查说明.md)、[原始计时](../multiscale_experiment/latency_audit.json)|12训练；两数据集×两变体×三种子；相对phase和等参数控制门槛均失败；phase历史对照|4.6及讨论加入完整比较与限制|

## 稿件更新与尚存缺口

本次以manuscript.md为工作主稿，新增4.5–4.6及讨论限制，替换“机制对照仍完全属于未来工作”的过时段落。新增数字来自上表本地结果，未新增外部文献或优先权主张。所有候选保留，未筛选正向种子。此段最初记录更新中状态；截至2026-09-20 21:08（北京时间），带图Markdown、TeX、正文及补充PDF和扩展压缩包均已重新生成并核查，详见pdf_qa_20260920.md和review_package_manifest.json。此同步不等于投稿就绪，作者声明及目标期刊要求仍待确认。

仍需完成：第二阶段分辨率、初始化及复用测试的逐项数值校核和方法定义；摘要、结论与扩展研究范围的最终统一；补充材料与图表同步；正文表图编号及引用检查；重建并视觉核查PDF；独立来源/数值完整性复核。作者信息、基金、利益冲突、最终目标期刊与公开归档标识仍需作者确认。现阶段不标记ready_to_submit。

已发现旧预算ars_validation.md存在NEU验证“全部种子负向”的表述问题：实际full−phase为+0.037、−0.303、−0.524。以完整结果为准，不能沿用该旧句。第二阶段机制实验结果.md只覆盖验证子集，不能误认为39项完整结果表。

## 版本与环境限制

本次不改训练冻结文件。多尺度的冻结代码、摘要、检查点哈希已在前一轮核查；本索引只建立证据位置，未重跑训练或宣称所有历史记录均已独立重验。旧phase对照与新实验的源码/数据一致性不等于实际软件环境完全一致。连续使用同一验证集探索仍有选择偏差，测试复用不能升级为独立确认。

## 方法命名更正

历史phase_p4ctx实际读取P5/32而非P4/16；依据冻结源码哈希及原始模型CPU形状核验。详见[方法一致性核查](method_consistency_audit_20260920.md)。保留历史文件名及原始记录；正文和补充已更正，不能把此实验解释为P4条件验证。

## 新增对照算术核查

[数值核查](numeric_audit_20260920.md)：context/head_detail/matched_condition共10项验证比较，从逐模型摘要重算与报告一致，48个输入留存哈希。没有新增性能结论，不是全项目数值审计。

[多尺度与预算验证算术核查](negative_numeric_audit_20260920.md)：30项比较、52个输入；仅验证集，不覆盖复用测试。正文所引比较一致。

## 引用核查

[引用核查记录](citation_audit_20260920.md)：正文20个唯一引用键与20条参考文献一一对应。已移除1条未引用条目，并将COCO预印本条目替换为正式ECCV论文及DOI。该记录不等于逐句语义蕴含审计或撤稿状态证明。

[论断—引用支撑核查](claim_citation_audit_20260920.md)：检查正文第1、2及3.1–3.2节的14组外部论断，均得到保存的出版方、作者数据页、官方数据集README或论文全文支持；本轮未修改正文。核查不覆盖撤稿状态或外部模型独立复现。
