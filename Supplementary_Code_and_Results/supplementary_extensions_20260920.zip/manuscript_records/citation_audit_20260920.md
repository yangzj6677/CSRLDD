# Citation audit (2026-09-20)

Origin Skill: academic-research-suite, academic-paper `citation-check` mode. This is a bibliographic audit of the current manuscript, not a scientific endorsement of every cited claim.

## Summary

| Check | Result |
|---|---:|
| Unique in-text citation keys | 20 |
| Reference entries after correction | 20 |
| Missing reference entries | 0 |
| Uncited reference entries | 0 |
| Deterministic corrections | 2 |
| Sources dated 2022-2026 | 11/20 (55%) |
| Sources older than 10 years | 3/20 |

The manuscript uses Pandoc citation keys and a numbered reference list. Every current citation key resolves to one entry and every remaining entry is cited. Self-citation cannot be calculated because author identities have not been supplied.

## Corrections

1. Removed `UAV2025DeepSemantic` from `references.bib`. It was not cited anywhere in the manuscript and was therefore an orphan reference. Its removal changes no manuscript claim.
2. Replaced the `Lin2014COCO` arXiv-only record with the formal ECCV 2014 proceedings record and DOI `10.1007/978-3-319-10602-1_48`.

## Existence and metadata evidence

The project source cache and `literature_source_manifest.json` retain authoritative or publisher copies for the principal datasets, reproducibility references, and recent comparison papers. This turn additionally checked selected recent/high-risk records against publisher or authoritative index pages:

- WTCFNet: Scientific Reports, DOI `10.1038/s41598-025-27745-9`.
- PCB-MMF: Scientific Reports, DOI `10.1038/s41598-026-49734-2`.
- GRACE: Scientific Reports, DOI `10.1038/s41598-026-36543-w`.
- YOLOv11-WBD: PLOS One, DOI `10.1371/journal.pone.0331025`.
- OAD-YOLOv8n: Metals, DOI `10.3390/met16060666`.
- Edge-Enhance YOLO: Journal of Imaging, DOI `10.3390/jimaging12060259`.
- FDFNet: Digital Signal Processing, DOI `10.1016/j.dsp.2025.105432`.
- Show Your Work: ACL Anthology, DOI `10.18653/v1/D19-1224`.

## Items requiring later review

- This pass establishes key/reference consistency and selected bibliographic existence. It does not prove that every sentence is semantically entailed by the cited source.
- No retraction-database certificate was produced. Absence of a detected issue must not be described as a clean retraction status.
- The working target journal remains unconfirmed, so final punctuation and reference styling must be regenerated against the selected journal template.
- The three pre-2016 sources are retained as foundational dataset/evaluation references; their age is visible rather than treated as an error.

