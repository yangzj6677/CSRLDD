---
title: "Supplementary Information for Controlled Evaluation of Shallow-Feature Refinement in Lightweight Industrial Defect Detection"
lang: en-US
---

# S1 Complete main results

The study comprises 24 main runs at 120 epochs plus 23 distinct exploratory runs at 30 epochs. Four NEU seed 42 main runs predate the frozen matrix; 20 main runs were added afterward. These 47 distinct runs represent 3, 570 training epochs. The earlier tutorial demonstration is not included in this study matrix. All planned main models were evaluated; the retained historical NEU test contact is disclosed in the manuscript.

Table S1. Every pooled test result in the fixed main matrix. AP75 is the mean of exported rounded class AP75 values; all other metrics use full-precision summary values.

| Dataset | Model | Seed | mAP50 | AP75 | mAP50–95 |
| --- | --- | --- | --- | --- | --- |
| NEU-DET | Base | 42 | 75.470 | 43.977 | 43.111 |
| NEU-DET | Base | 43 | 77.180 | 44.404 | 45.027 |
| NEU-DET | Base | 44 | 74.046 | 40.319 | 41.814 |
| NEU-DET | Residual | 42 | 75.058 | 44.809 | 43.831 |
| NEU-DET | Residual | 43 | 74.252 | 42.967 | 42.597 |
| NEU-DET | Residual | 44 | 76.362 | 45.032 | 43.842 |
| NEU-DET | Unconditional | 42 | 75.779 | 43.889 | 43.648 |
| NEU-DET | Unconditional | 43 | 76.986 | 46.818 | 45.201 |
| NEU-DET | Unconditional | 44 | 76.031 | 46.210 | 44.035 |
| NEU-DET | Conditioned | 42 | 77.232 | 47.391 | 45.455 |
| NEU-DET | Conditioned | 43 | 76.959 | 44.796 | 45.036 |
| NEU-DET | Conditioned | 44 | 74.227 | 44.679 | 43.247 |
| DeepPCB | Base | 42 | 93.067 | 65.295 | 59.366 |
| DeepPCB | Base | 43 | 94.902 | 69.166 | 60.557 |
| DeepPCB | Base | 44 | 93.537 | 78.431 | 66.465 |
| DeepPCB | Residual | 42 | 94.079 | 73.987 | 63.025 |
| DeepPCB | Residual | 43 | 94.229 | 81.487 | 68.970 |
| DeepPCB | Residual | 44 | 93.852 | 76.285 | 64.117 |
| DeepPCB | Unconditional | 42 | 93.528 | 71.117 | 59.981 |
| DeepPCB | Unconditional | 43 | 94.275 | 71.820 | 62.349 |
| DeepPCB | Unconditional | 44 | 93.532 | 79.118 | 66.011 |
| DeepPCB | Conditioned | 42 | 93.976 | 79.245 | 66.649 |
| DeepPCB | Conditioned | 43 | 93.516 | 78.004 | 65.905 |
| DeepPCB | Conditioned | 44 | 93.930 | 79.212 | 65.720 |


Table S2. Per-class test AP50–95 (%) across three seeds, from the framework’s rounded per-class export.

| Dataset | Class | Base | Residual | Unconditional | Conditioned |
| --- | --- | --- | --- | --- | --- |
| NEU-DET | crazing | 15.82 ± 3.74 | 13.50 ± 0.27 | 16.59 ± 3.02 | 16.13 ± 2.95 |
| NEU-DET | inclusion | 46.14 ± 0.45 | 45.14 ± 0.79 | 46.07 ± 1.86 | 46.06 ± 1.48 |
| NEU-DET | patches | 61.89 ± 1.23 | 63.26 ± 0.90 | 64.36 ± 0.73 | 64.21 ± 0.29 |
| NEU-DET | pitted_surface | 55.77 ± 0.51 | 54.97 ± 2.12 | 54.88 ± 0.80 | 55.22 ± 0.46 |
| NEU-DET | rolled-in_scale | 28.08 ± 2.68 | 29.53 ± 2.95 | 30.51 ± 3.23 | 30.75 ± 3.11 |
| NEU-DET | scratches | 52.21 ± 2.15 | 54.15 ± 2.90 | 53.35 ± 1.98 | 55.11 ± 1.65 |
| DeepPCB | open | 57.43 ± 2.78 | 59.74 ± 2.17 | 59.22 ± 1.51 | 60.51 ± 0.97 |
| DeepPCB | short | 50.79 ± 2.54 | 51.36 ± 2.37 | 50.80 ± 1.27 | 51.61 ± 0.98 |
| DeepPCB | mousebite | 59.04 ± 5.51 | 63.32 ± 3.99 | 61.13 ± 3.15 | 64.56 ± 0.73 |
| DeepPCB | spur | 59.16 ± 2.89 | 62.07 ± 1.47 | 59.91 ± 2.31 | 62.62 ± 0.29 |
| DeepPCB | copper | 78.96 ± 3.36 | 82.43 ± 2.97 | 76.70 ± 5.44 | 81.98 ± 1.42 |
| DeepPCB | pin-hole | 67.41 ± 7.45 | 73.30 ± 7.03 | 68.93 ± 6.94 | 75.27 ± 0.51 |


# S2 Development history

The screens below explore centered contrast, shallow subgrid detail, mechanism ablations and head-specific routing. They are not independent confirmations of the final design. Single-seed 30/120 comparisons do not establish a general training-budget interaction. The four previously completed 120-epoch main runs are listed in Table S1, not counted twice here.

Table S3. All 23 exploratory study runs not reused in the 24-run main matrix. These validation screens were used during development; missing tests were not imputed.

| Dataset | Variant | Seed | Epochs | Val mAP50 | Val mAP50–95 |
|---|---|---|---|---|---|
| deeppcb | baseline | 42 | 30 | 93.120 | 61.762 |
| deeppcb | phase | 42 | 30 | 94.574 | 59.999 |
| deeppcb | phase_avg | 42 | 30 | 93.708 | 56.298 |
| deeppcb | phase_box | 42 | 30 | 92.738 | 60.831 |
| deeppcb | phase_head | 42 | 30 | 92.791 | 62.010 |
| deeppcb | phase_uniform | 42 | 30 | 92.856 | 62.318 |
| neu | baseline | 42 | 30 | 70.129 | 40.000 |
| neu | baseline | 43 | 30 | 71.838 | 40.164 |
| neu | guided | 42 | 30 | 70.080 | 39.640 |
| neu | guided_ungated | 42 | 30 | 71.024 | 40.719 |
| neu | guided_ungated | 43 | 30 | 70.947 | 40.301 |
| neu | phase | 42 | 30 | 70.891 | 40.542 |
| neu | phase_avg | 42 | 30 | 70.578 | 39.263 |
| neu | phase_box | 42 | 30 | 70.787 | 40.734 |
| neu | phase_content | 42 | 30 | 69.547 | 39.946 |
| neu | phase_head | 42 | 30 | 70.832 | 39.816 |
| neu | phase_self | 42 | 30 | 70.803 | 40.273 |
| neu | phase_uncentered | 42 | 30 | 70.109 | 39.605 |
| neu | phase_uniform | 42 | 30 | 71.001 | 39.723 |
| neu | plain | 42 | 30 | 71.801 | 40.552 |
| neu | plain | 43 | 30 | 71.199 | 40.432 |
| neu | sccr | 42 | 30 | 70.046 | 39.278 |
| neu | ungated | 42 | 30 | 70.701 | 39.778 |


# S3 Learning trajectories and training geometry

The prescribed 120-epoch budget is a longer common budget, not a certificate of convergence. In particular, DeepPCB validation trajectories fluctuate substantially; the highest-validation-fitness checkpoint is retained for every run. The final checkpoint evaluation is separate from the rounded per-epoch training log.

![Validation-log learning trajectories across three seeds; bands show sample standard deviation, not confidence intervals.](figures/FigureS1_learning_curves.pdf){width=100%}

![Training-label box geometry at 320 input. Small-box status is based on annotated box area, not actual defect line width or image contrast.](figures/FigureS2_training_geometry.pdf){width=100%}

# S4 Frozen source-group analysis

The official DeepPCB test remains 500 images. The source-seen stratum contains 168 images from groups 20085(34),  13000(18),  00041(21),  77000(7),  92000(9),  50600(29) and 44000(50). The source-unseen stratum contains 332 images from groups 90100(74),  12100(146),  12300(98) and 12000(14). The partition was defined from manifest membership before inspecting the main test predictions. It is not claimed to isolate physical boards, acquisition batches or causal domain shifts. Stratum AP and pooled AP use their own global prediction rankings and need not be image-count-weighted averages of one another.

All image identifiers, partitions, decoded-image hashes and annotation hashes are provided in the accompanying supplementary code/data archive. Original images remain obtainable from the dataset authors; they are not redistributed in this supplement.

# S5 Reproducibility and computational measurement

The accompanying archive includes frozen training source, environment lock, reconstruction instructions, complete training arguments and learning curves, per-run metric summaries, and saved predictions. It also describes provenance limitations for reused exploratory runs, relocates machine-specific paths in distributed records and retains hashes of originals. It is a supplementary archive, not a claimed public repository or DOI. Trained weights and the original image archives are omitted from the initial submission archive to control size; training commands and weight checksums remain available.

Timing uses FP32, batch 1, 320 input, Conv/BN fusion, 30 initial warm-up forwards, 5 randomized-order trials and 100 forwards per trial. Values are wall times synchronized at trial boundaries. They exclude image loading, preprocessing, transfer and NMS. Resource profiling reports peak PyTorch allocation including weights, input and cached model inference state, and excludes CUDA-context and desktop allocations. Normal Windows desktop applications remained active; experimental training and evaluation jobs were not run concurrently with these resource measurements. THOP-based GFLOPs omit some tensor rearrangement and elementwise memory costs.

# S6 Local operator and mechanism checks

The local modulation has the form $q=(J+PDP)p$, where $J=\mathbf1\mathbf1^T/4$, $P=I-J$, and each diagonal entry of $D$ lies between 0.5 and 1.5. Therefore $Jq=Jp$. On the centered subspace, the fixed-condition symmetric operator $PDP$ has eigenvalues in this interval. These properties apply after channel compression and before branch refinement; they do not imply lossless input processing, network-wide mean preservation or a whole-network Lipschitz bound. Independent numerical checks and serialization/gradient/initial-output checks are included in the code archive.

# S7 Evidence and declaration boundaries

The source-level literature matrix accompanying the code archive records six inspected industrial-detection full texts and distinguishes unreported fields from access-limited fields. It does not establish exhaustive novelty or turn published scores from differing protocols into comparable baselines. No commercial inspection deployment, independent factory cohort, additional backbone, complete initialization marginalization or population-level equivalence claim is made.

Generative AI assisted the research workflow, including design suggestions, code, analysis, figures and drafting. The final paper requires named human authors and their actual review, contribution, funding and competing-interest declarations. Those facts are not supplied by the experiment record.


# S 8 Post-exploration extension record

The following experiments were conducted after the original main comparison. They do not increase the number of independent main-study repeats. Stage two added 39 training runs at 120 epochs: 24 mechanism comparisons, nine DeepPCB resolution comparisons, and six initialization comparisons. Every checkpoint received validation and secondary evaluation on previously inspected test sets. The attached complete tables report all 78 summaries, including unfavorable seeds. Training seeds remain conditional on fixed dataset partitions.

The capacity reference uses an additive transformation of the rearranged shallow feature and matches the conditioned branch's parameter count. It changes both input and transformation, so it cannot isolate semantic context alone. The uncentered control removes final residual recentering. Resolution comparisons pair the conditioning difference at 640 with the newly trained 320 difference. Alternative initialization pairs training seeds 42/43/44 with branch seeds 2042/2043/2044, rather than crossing all seed combinations.

## S 8.1 Subsequent negative screens

|Stage|Scope|NEU difference (pp)|DeepPCB difference (pp)|Disposition|
|---|---|---:|---:|---|
|Full budget constraint vs phase|Three seeds, validation|−0.263 ± 0.282|−3.089 ± 1.037|No mean improvement|
|Full budget constraint vs phase|Three seeds, reused test|−0.627 ± 0.765|−4.906 ± 1.811|Secondary reused-test evidence|
|Dynamic rotation vs phase|Single seed, validation|−0.211|−0.829|Frozen accuracy gate failed|
|Cross-level alignment vs phase|Single seed, validation|−0.037|−4.814|Frozen accuracy gate failed|
|Parallel-scale vs phase|Three seeds, validation|−0.299 ± 0.186|−2.495 ± 2.041|Frozen accuracy gate failed|
|Parallel-scale vs equal-parameter control|Three seeds, validation|−0.070 ± 0.667|−0.501 ± 0.515|Frozen accuracy gate failed|

Three-seed values are paired means ± sample SD. The budget stage included 24 training runs across full, gate-only, projection-only, and constant-budget variants; all results are retained in the evidence index. Rotation included eight runs across phase, static rotation, dynamic rotation, and directional gain. Alignment included ten runs across phase, uniform, depthwise, self-conditioned, and cross-level variants. Parallel-scale refinement included 12 runs and reused historical phase controls. Static rotation improved only DeepPCB in its single-seed screen and was not substituted for the failed dynamic candidate. No significance or general mechanism-ineffectiveness claim follows from these screens.

The separate microtranslation diagnostic compared class-consistent prediction-matching F1 after inverse-transforming predictions for axial ±1/±2-pixel translations. Phase excess degradation was −0.1118 pp on DeepPCB (image-bootstrap 95% interval −1.1333 to +1.2015) and +0.8759 pp on NEU (−0.6669 to +2.4234). The joint criterion was not met. This diagnostic is not detection AP, and its image bootstrap does not quantify training-seed uncertainty. It did not justify initiating consistency training.

## S 8.2 Additional conditioning and geometry controls

Six P2-self-conditioning runs compared conditioning sources with equal condition-layer parameter counts. P3-minus-P2 validation differences were +3.061 ± 3.472 pp on DeepPCB and +0.229 ± 0.341 on NEU; reused-test differences were +4.419 ± 3.180 and +0.146 ± 0.567. A separate contemporaneous 12-run validation rerun reproduced all corresponding historical AP values exactly at saved precision. Repeated identical seeds are not additional independent samples. No additional tests were initiated for this rerun.

Twelve deep-context/channel-attention runs and twelve head-routing runs failed their joint validation criteria. All means and seed values remain in the context and head-detail stage reports. Deep-context-minus-phase means were −2.676 pp on DeepPCB and −0.429 on NEU. Box-path-minus-phase means were −0.830 and +0.060, while head-minus-phase means were +0.326 and −0.170. The head-detail recovery record documents a terminated run with damaged checkpoints and the subsequent authorized recovery; completed-run counts do not include that interrupted attempt as an independent replicate.

The narrow-or-elongated subgroup diagnostic failed its validation criterion: phase-minus-uniform recall at IoU 0.50 was +0.288 ± 2.017 pp on DeepPCB and −2.867 ± 1.643 on NEU. Thresholds came from training geometry. Positive reused-test means do not reverse a failed validation decision, and this recall endpoint is not AP.

The self-conditioned variant uses 2-by-2 average pooling of the uncompressed P2 feature as the input to the existing condition convolution. The deep-context variant retains the historical identifier `phase_p4ctx`, but its frozen source routes backbone layer 8, whose output is P5/32 (10-by-10 at 320 input). Thus, this is not a P4 experiment. Context is nearest-neighbor resized to P3, projected by a 1-by-1 convolution, and used to multiply the P3 condition by one plus 0.5 times a tanh correction. The near-parameter-count control instead combines global average and maximum pooling of P3 before a two-layer channel transform; it is not exactly parameter matched. The historical labels are retained in raw records for traceability.

The head variants omit the original shared-path injection and refine only the smallest-scale detector input: `phase_box` supplies it to regression, whereas `phase_head` supplies it to regression and classification. This changes downstream feature propagation as well as task routing, so it is not a strict location-only ablation. These screens used 120 epochs, 320 input, batch 16, and seeds 42/43/44 on each dataset. Their phase references were historical runs; the later contemporaneous rerun directly addresses the phase-versus-self comparison only.

Subgroup predictions use confidence 0.25 and NMS IoU 0.70. Narrowness is defined by the training 10th percentile of the shorter reference box side; elongation by the training 90th percentile of aspect ratio. The union is evaluated by class-consistent one-to-one matching at IoU 0.50. Its frozen progression rule requires at least +0.5 pp mean recall difference and two positive seeds in each dataset. This thresholded recall must not be compared numerically with full precision-recall AP.

## S 8.3 Provenance and efficiency limits

Rotation, alignment, and parallel-scale timing runs showed instability under their recorded protocols. Their raw timings are retained, but do not establish reliable relative speed or passage of a latency budget. Historical phase controls introduce environment-comparability limits beyond source, weight, and dataset hashes. Later changes to installed compatibility packages are documented in the alignment execution record. No failed candidate was advanced to new test screening in the rotation, alignment, or parallel-scale stages.

The original main-study ZIP is accompanied by a separate extension archive containing 135 completed training runs, including the 12 contemporaneous reruns, and the diagnostic records. It contains 204 saved result summaries. These are workload and archive counts, not independent-sample counts. The archive excludes weights, full predictions, and console logs; it is not a self-contained executable environment. A separate table-provenance file records source hashes. The evidence index and omitted-stage addendum identify all recorded stages.




```{=latex}
\clearpage
\begin{landscape}
\footnotesize
```

# S 9 Complete stage-two tables

All 39 validation and 39 reused-test summaries; post-exploration evidence, not independent confirmation. AP and differences are in percentage units. Seeds are 42, 43, 44; SD is sample SD.

|Family|Dataset|Split|Variant|Input|Seed 42|Seed 43|Seed 44|Mean ± SD|
|---|---|---|---|---:|---:|---:|---:|---:|
|init.|deeppcb|test|phase|320|65.426|65.516|68.883|66.608 ± 1.970|
|init.|deeppcb|test|Uniform|320|63.911|59.872|58.936|60.906 ± 2.644|
|init.|deeppcb|val|phase|320|69.409|69.688|70.189|69.762 ± 0.395|
|init.|deeppcb|val|Uniform|320|68.308|63.885|64.221|65.471 ± 2.462|
|mech.|deeppcb|test|phase|320|66.649|65.905|65.720|66.091 ± 0.492|
|mech.|deeppcb|test|Capacity|320|62.117|60.411|67.105|63.211 ± 3.478|
|mech.|deeppcb|test|Uncentered|320|62.406|62.840|65.826|63.691 ± 1.862|
|mech.|deeppcb|test|Uniform|320|59.981|62.349|66.011|62.780 ± 3.038|
|mech.|deeppcb|val|phase|320|70.112|70.057|70.018|70.062 ± 0.047|
|mech.|deeppcb|val|Capacity|320|68.328|66.027|69.110|67.822 ± 1.603|
|mech.|deeppcb|val|Uncentered|320|67.838|65.606|69.036|67.493 ± 1.741|
|mech.|deeppcb|val|Uniform|320|66.201|68.242|69.114|67.853 ± 1.495|
|mech.|neu|test|phase|320|45.455|45.036|43.247|44.579 ± 1.173|
|mech.|neu|test|Capacity|320|44.507|43.592|43.176|43.759 ± 0.681|
|mech.|neu|test|Uncentered|320|44.619|44.211|42.815|43.881 ± 0.946|
|mech.|neu|test|Uniform|320|43.648|45.201|44.035|44.295 ± 0.808|
|mech.|neu|val|phase|320|42.930|43.145|42.854|42.976 ± 0.151|
|mech.|neu|val|Capacity|320|42.576|42.339|41.725|42.213 ± 0.439|
|mech.|neu|val|Uncentered|320|42.065|43.129|41.519|42.238 ± 0.819|
|mech.|neu|val|Uniform|320|42.869|43.143|41.846|42.619 ± 0.684|
|res.|deeppcb|test|baseline|640|77.285|74.216|73.070|74.857 ± 2.179|
|res.|deeppcb|test|phase|640|76.055|75.531|75.446|75.677 ± 0.330|
|res.|deeppcb|test|Uniform|640|75.370|75.208|75.183|75.254 ± 0.102|
|res.|deeppcb|val|baseline|640|77.915|76.220|77.530|77.222 ± 0.889|
|res.|deeppcb|val|phase|640|76.751|77.379|78.428|77.519 ± 0.848|
|res.|deeppcb|val|Uniform|640|76.975|78.388|77.327|77.564 ± 0.735|

## S 9.1 Resolution interaction and init. sensitivity

|Split|Contrast|Seed differences (42,43,44)|Mean ± SD (pp)|
|---|---|---|---:|
|val|res. interaction (640−320)|-4.135, -2.824, +0.198|-2.254 ± 2.222|
|val|Uniform alternative−fixed init.|+2.106, -4.357, -4.893|-2.381 ± 3.896|
|val|phase alternative−fixed init.|-0.703, -0.369, +0.171|-0.300 ± 0.441|
|val|phase−uniform with alternative init.|+1.101, +5.803, +5.967|+4.290 ± 2.763|
|test|res. interaction (640−320)|-5.984, -3.232, +0.554|-2.887 ± 3.282|
|test|Uniform alternative−fixed init.|+3.930, -2.477, -7.075|-1.874 ± 5.527|
|test|phase alternative−fixed init.|-1.223, -0.389, +3.162|+0.517 ± 2.329|
|test|phase−uniform with alternative init.|+1.515, +5.644, +9.947|+5.702 ± 4.216|


```{=latex}
\end{landscape}
\normalsize
```
