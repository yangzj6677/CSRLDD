# 多尺度与预算验证数值核查

Origin Skill: academic-research-suite。逐模型验证摘要重算，保留输入SHA256。未修改冻结文件，未重新推理。

共30项比较与既有报告匹配（容差1e-10 pp）。正文引用的多尺度和预算full对phase均值/样本SD三位小数一致。

|阶段|数据集|比较|均值±样本SD（pp）|负向种子|
|---|---|---|---:|---:|
|multiscale|deeppcb|msd_minus_phase|-2.495 ± 2.041|3/3|
|multiscale|deeppcb|msd_minus_control|-0.501 ± 0.515|3/3|
|multiscale|neu|msd_minus_phase|-0.299 ± 0.186|3/3|
|multiscale|neu|msd_minus_control|-0.070 ± 0.667|1/3|
|budget|neu|budget_full - phase|-0.263 ± 0.282|2/3|
|budget|neu|budget_full - budget_gate|+0.911 ± 0.733|0/3|
|budget|neu|budget_full - budget_project|+0.021 ± 0.539|2/3|
|budget|neu|budget_full - budget_constant|+0.162 ± 0.272|1/3|
|budget|neu|budget_gate - phase|-1.174 ± 0.678|3/3|
|budget|neu|budget_gate - budget_project|-0.890 ± 0.746|3/3|
|budget|neu|budget_gate - budget_constant|-0.749 ± 0.671|2/3|
|budget|neu|budget_project - phase|-0.284 ± 0.257|3/3|
|budget|neu|budget_project - budget_gate|+0.890 ± 0.746|0/3|
|budget|neu|budget_project - budget_constant|+0.141 ± 0.269|1/3|
|budget|neu|budget_constant - phase|-0.425 ± 0.013|3/3|
|budget|neu|budget_constant - budget_gate|+0.749 ± 0.671|1/3|
|budget|neu|budget_constant - budget_project|-0.141 ± 0.269|2/3|
|budget|deeppcb|budget_full - phase|-3.089 ± 1.037|3/3|
|budget|deeppcb|budget_full - budget_gate|+0.674 ± 1.923|2/3|
|budget|deeppcb|budget_full - budget_project|-1.760 ± 3.981|2/3|
|budget|deeppcb|budget_full - budget_constant|-1.120 ± 2.685|2/3|
|budget|deeppcb|budget_gate - phase|-3.763 ± 2.027|3/3|
|budget|deeppcb|budget_gate - budget_project|-2.434 ± 3.061|3/3|
|budget|deeppcb|budget_gate - budget_constant|-1.794 ± 3.197|2/3|
|budget|deeppcb|budget_project - phase|-1.329 ± 3.150|2/3|
|budget|deeppcb|budget_project - budget_gate|+2.434 ± 3.061|0/3|
|budget|deeppcb|budget_project - budget_constant|+0.640 ± 2.485|1/3|
|budget|deeppcb|budget_constant - phase|-1.969 ± 1.657|3/3|
|budget|deeppcb|budget_constant - budget_gate|+1.794 ± 3.197|1/3|
|budget|deeppcb|budget_constant - budget_project|-0.640 ± 2.485|2/3|

预算full对phase在NEU为2/3负向，不能写成所有种子下降；当前正文只写平均下降，符合结果。多尺度对phase两数据集各3/3负向。既有ars_validation.md的历史文字问题不改写原记录。

本核查不覆盖测试集数值、文献、时延或全部论文数值；不是独立重复实验。
