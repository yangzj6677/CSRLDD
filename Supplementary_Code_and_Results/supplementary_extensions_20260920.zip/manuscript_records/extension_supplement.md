# S 8 Post-exploration extension record

The following experiments were conducted after the original main comparison. They do not increase the number of independent main-study repeats. Stage two added 39 training runs at 120 epochs: 24 mechanism comparisons, nine DeepPCB resolution comparisons, and six initialization comparisons. Every checkpoint received validation and secondary evaluation on previously inspected test sets. The attached complete tables report all 78 summaries, including unfavorable seeds. Training seeds remain conditional on fixed dataset partitions.

The capacity reference uses an additive transformation of the rearranged shallow feature and matches the conditioned branch's parameter count. It changes both input and transformation, so it cannot isolate semantic context alone. The uncentered control removes final residual recentering. Resolution comparisons pair the conditioning difference at 640 with the newly trained 320 difference. Alternative initialization pairs training seeds 42/43/44 with branch seeds 2042/2043/2044, rather than crossing all seed combinations.

## S 8.1 Subsequent negative screens

|Stage|Scope|NEU difference (pp)|DeepPCB difference (pp)|Disposition|
|---|---|---:|---:|---|
|Full budget constraint vs phase|Three seeds, validation|−0.263 ± 0.282|−3.089 ± 1.037|No mean improvement|
|Full budget constraint vs phase|Three seeds, reused test|−0.627 ± 0.765|−4.906 ± 1.811|Secondary reused-test evidence|
|Dynamic rotation vs phase|Single seed, validation|−0.211|−0.829|Frozen accuracy gate failed|
|Cross-level alignment vs phase|Single seed, validation|−0.037|−4.814|Frozen accuracy gate failed|
|Parallel-scale vs phase|Three seeds, validation|−0.299 ± 0.186|−2.495 ± 2.041|Frozen accuracy gate failed|
|Parallel-scale vs equal-parameter control|Three seeds, validation|−0.070 ± 0.667|−0.501 ± 0.515|Frozen accuracy gate failed|

Three-seed values are paired means ± sample SD. The budget stage included 24 training runs across full, gate-only, projection-only, and constant-budget variants; all results are retained in the evidence index. Rotation included eight runs across phase, static rotation, dynamic rotation, and directional gain. Alignment included ten runs across phase, uniform, depthwise, self-conditioned, and cross-level variants. Parallel-scale refinement included 12 runs and reused historical phase controls. Static rotation improved only DeepPCB in its single-seed screen and was not substituted for the failed dynamic candidate. No significance or general mechanism-ineffectiveness claim follows from these screens.

The separate microtranslation diagnostic compared class-consistent prediction-matching F1 after inverse-transforming predictions for axial ±1/±2-pixel translations. Phase excess degradation was −0.1118 pp on DeepPCB (image-bootstrap 95% interval −1.1333 to +1.2015) and +0.8759 pp on NEU (−0.6669 to +2.4234). The joint criterion was not met. This diagnostic is not detection AP, and its image bootstrap does not quantify training-seed uncertainty. It did not justify initiating consistency training.

## S 8.2 Additional conditioning and geometry controls

Six P2-self-conditioning runs compared conditioning sources with equal condition-layer parameter counts. P3-minus-P2 validation differences were +3.061 ± 3.472 pp on DeepPCB and +0.229 ± 0.341 on NEU; reused-test differences were +4.419 ± 3.180 and +0.146 ± 0.567. A separate contemporaneous 12-run validation rerun reproduced all corresponding historical AP values exactly at saved precision. Repeated identical seeds are not additional independent samples. No additional tests were initiated for this rerun.

Twelve deep-context/channel-attention runs and twelve head-routing runs failed their joint validation criteria. All means and seed values remain in the context and head-detail stage reports. Deep-context-minus-phase means were −2.676 pp on DeepPCB and −0.429 on NEU. Box-path-minus-phase means were −0.830 and +0.060, while head-minus-phase means were +0.326 and −0.170. The head-detail recovery record documents a terminated run with damaged checkpoints and the subsequent authorized recovery; completed-run counts do not include that interrupted attempt as an independent replicate.

The narrow-or-elongated subgroup diagnostic failed its validation criterion: phase-minus-uniform recall at IoU 0.50 was +0.288 ± 2.017 pp on DeepPCB and −2.867 ± 1.643 on NEU. Thresholds came from training geometry. Positive reused-test means do not reverse a failed validation decision, and this recall endpoint is not AP.

The self-conditioned variant uses 2-by-2 average pooling of the uncompressed P2 feature as the input to the existing condition convolution. The deep-context variant retains the historical identifier `phase_p4ctx`, but its frozen source routes backbone layer 8, whose output is P5/32 (10-by-10 at 320 input). Thus, this is not a P4 experiment. Context is nearest-neighbor resized to P3, projected by a 1-by-1 convolution, and used to multiply the P3 condition by one plus 0.5 times a tanh correction. The near-parameter-count control instead combines global average and maximum pooling of P3 before a two-layer channel transform; it is not exactly parameter matched. The historical labels are retained in raw records for traceability.

The head variants omit the original shared-path injection and refine only the smallest-scale detector input: `phase_box` supplies it to regression, whereas `phase_head` supplies it to regression and classification. This changes downstream feature propagation as well as task routing, so it is not a strict location-only ablation. These screens used 120 epochs, 320 input, batch 16, and seeds 42/43/44 on each dataset. Their phase references were historical runs; the later contemporaneous rerun directly addresses the phase-versus-self comparison only.

Subgroup predictions use confidence 0.25 and NMS IoU 0.70. Narrowness is defined by the training 10th percentile of the shorter reference box side; elongation by the training 90th percentile of aspect ratio. The union is evaluated by class-consistent one-to-one matching at IoU 0.50. Its frozen progression rule requires at least +0.5 pp mean recall difference and two positive seeds in each dataset. This thresholded recall must not be compared numerically with full precision-recall AP.

## S 8.3 Provenance and efficiency limits

Rotation, alignment, and parallel-scale timing runs showed instability under their recorded protocols. Their raw timings are retained, but do not establish reliable relative speed or passage of a latency budget. Historical phase controls introduce environment-comparability limits beyond source, weight, and dataset hashes. Later changes to installed compatibility packages are documented in the alignment execution record. No failed candidate was advanced to new test screening in the rotation, alignment, or parallel-scale stages.

The original main-study ZIP is accompanied by a separate extension archive containing 135 completed training runs, including the 12 contemporaneous reruns, and the diagnostic records. It contains 204 saved result summaries. These are workload and archive counts, not independent-sample counts. The archive excludes weights, full predictions, and console logs; it is not a self-contained executable environment. A separate table-provenance file records source hashes. The evidence index and omitted-stage addendum identify all recorded stages.
