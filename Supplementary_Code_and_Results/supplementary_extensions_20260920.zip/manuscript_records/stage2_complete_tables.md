# Stage-two complete descriptive tables

All 39 validation and 39 reused-test summaries; post-exploration evidence, not independent confirmation. AP and differences are in percentage units. Seeds are 42, 43, 44; SD is sample SD.

|Family|Dataset|Split|Variant|Input|Seed 42|Seed 43|Seed 44|Mean ± SD|
|---|---|---|---|---:|---:|---:|---:|---:|
|initialization|deeppcb|test|phase|320|65.426|65.516|68.883|66.608 ± 1.970|
|initialization|deeppcb|test|phase_uniform|320|63.911|59.872|58.936|60.906 ± 2.644|
|initialization|deeppcb|val|phase|320|69.409|69.688|70.189|69.762 ± 0.395|
|initialization|deeppcb|val|phase_uniform|320|68.308|63.885|64.221|65.471 ± 2.462|
|mechanism|deeppcb|test|phase|320|66.649|65.905|65.720|66.091 ± 0.492|
|mechanism|deeppcb|test|phase_capacity|320|62.117|60.411|67.105|63.211 ± 3.478|
|mechanism|deeppcb|test|phase_uncentered|320|62.406|62.840|65.826|63.691 ± 1.862|
|mechanism|deeppcb|test|phase_uniform|320|59.981|62.349|66.011|62.780 ± 3.038|
|mechanism|deeppcb|val|phase|320|70.112|70.057|70.018|70.062 ± 0.047|
|mechanism|deeppcb|val|phase_capacity|320|68.328|66.027|69.110|67.822 ± 1.603|
|mechanism|deeppcb|val|phase_uncentered|320|67.838|65.606|69.036|67.493 ± 1.741|
|mechanism|deeppcb|val|phase_uniform|320|66.201|68.242|69.114|67.853 ± 1.495|
|mechanism|neu|test|phase|320|45.455|45.036|43.247|44.579 ± 1.173|
|mechanism|neu|test|phase_capacity|320|44.507|43.592|43.176|43.759 ± 0.681|
|mechanism|neu|test|phase_uncentered|320|44.619|44.211|42.815|43.881 ± 0.946|
|mechanism|neu|test|phase_uniform|320|43.648|45.201|44.035|44.295 ± 0.808|
|mechanism|neu|val|phase|320|42.930|43.145|42.854|42.976 ± 0.151|
|mechanism|neu|val|phase_capacity|320|42.576|42.339|41.725|42.213 ± 0.439|
|mechanism|neu|val|phase_uncentered|320|42.065|43.129|41.519|42.238 ± 0.819|
|mechanism|neu|val|phase_uniform|320|42.869|43.143|41.846|42.619 ± 0.684|
|resolution|deeppcb|test|baseline|640|77.285|74.216|73.070|74.857 ± 2.179|
|resolution|deeppcb|test|phase|640|76.055|75.531|75.446|75.677 ± 0.330|
|resolution|deeppcb|test|phase_uniform|640|75.370|75.208|75.183|75.254 ± 0.102|
|resolution|deeppcb|val|baseline|640|77.915|76.220|77.530|77.222 ± 0.889|
|resolution|deeppcb|val|phase|640|76.751|77.379|78.428|77.519 ± 0.848|
|resolution|deeppcb|val|phase_uniform|640|76.975|78.388|77.327|77.564 ± 0.735|

## Resolution interaction and initialization sensitivity

|Split|Contrast|Seed differences (42,43,44)|Mean ± SD (pp)|
|---|---|---|---:|
|val|resolution interaction (640−320)|-4.135, -2.824, +0.198|-2.254 ± 2.222|
|val|phase_uniform alternative−fixed initialization|+2.106, -4.357, -4.893|-2.381 ± 3.896|
|val|phase alternative−fixed initialization|-0.703, -0.369, +0.171|-0.300 ± 0.441|
|val|phase−uniform with alternative initialization|+1.101, +5.803, +5.967|+4.290 ± 2.763|
|test|resolution interaction (640−320)|-5.984, -3.232, +0.554|-2.887 ± 3.282|
|test|phase_uniform alternative−fixed initialization|+3.930, -2.477, -7.075|-1.874 ± 5.527|
|test|phase alternative−fixed initialization|-1.223, -0.389, +3.162|+0.517 ± 2.329|
|test|phase−uniform with alternative initialization|+1.515, +5.644, +9.947|+5.702 ± 4.216|
