# Claim–citation support audit: related work and datasets

Origin Skill: academic-research-suite, academic-paper `citation-check` mode. Scope: manuscript Sections 1, 2, and 3.1–3.2. Evidence was checked against the project’s saved publisher/author pages, full-text extracts, official dataset README, and bibliographic metadata. This is not a full-paper entailment certificate.

## Results

| Manuscript claim group | Cited source(s) | Saved evidence checked | Result |
|---|---|---|---|
| NEU image collection and later detection annotations are distinct sources | Song 2013; He 2020 | Crossref metadata, NEU author dataset page | Supported; wording remains appropriately bounded |
| NEU has 1,800 grayscale 200×200 images in six named classes | Song 2013; He 2020 | NEU author dataset page states 1,800 images, 300 per class, 200×200, and lists the six classes | Supported |
| DeepPCB contains 1,500 template/tested-image pairs, 640×640 crops and six defect categories | Tang 2019 | Official DeepPCB README | Supported |
| DeepPCB’s original division is 1,000 training images and 500 remaining test images | Tang 2019 | Official DeepPCB README | Supported |
| DeepPCB contains manually augmented artificial defects and is restricted to research use | Tang 2019 | Official DeepPCB README annotation and notification sections | Supported |
| SPD-Conv uses spatial rearrangement for low-resolution images and small objects | Sunkara 2022 | Bibliographic title/abstract record | Supported at the stated high level |
| Surface-defect precedents include space-to-depth with coordinate attention, and wavelet/bidirectional processing | Wan 2024; Guan 2025 | Publisher metadata/full-text extract | Supported |
| WSO-YOLO11 contains wavelet and space-to-depth components | WSO 2026 | Saved Scientific Reports abstract explicitly names Wavelet–Space-to-Depth Hybrid Stem | Supported |
| FreqFusion addresses frequency-aware dense-prediction fusion and boundary/intra-class inconsistency | Chen 2024 | Publisher metadata and cited abstract | Supported |
| OAD uses 7:1:2 splits, 640 input, 300 epochs, and five repeated main NEU runs | OAD 2026 | Saved full-text extract, Sections 4.1–4.3 | Supported; manuscript correctly limits repetition to the main comparison |
| Edge-Enhance uses a 3:1:1 NEU split, 320 input and 220 epochs | Edge-Enhance 2026 | Saved publisher full text | Supported |
| GRACE removes the identical patches_101/patches_105 pair and uses an 8:2 train/validation split without a separate NEU test set | GRACE 2026 | Saved Scientific Reports methods text | Supported |
| PCB-MMF repartitions DeepPCB 7:2:1 and reports no repeated-training variance analysis | PCB-MMF 2026 | Saved Scientific Reports dataset and conclusion text | Supported |
| Validation search can cause selection bias and run variation is only one component of benchmark uncertainty | Cawley 2010; Bouthillier 2021 | Saved JMLR/MLSys papers | Supported |

## Corrections

No manuscript correction was required in this pass. The prose already distinguishes precedent from reproduced evidence, does not compare heterogeneous external scores as a leaderboard, and limits protocol statements to the inspected comparison in each source.

## Residual boundaries

- `He2020NEUDET` metadata verifies the detection-paper identity; dataset size/class evidence is additionally grounded in the saved NEU author page. This audit does not claim that every dataset detail appears in the article abstract.
- Claims about recent external models are descriptive architecture/protocol summaries. Their reported performance was not independently reproduced.
- Source excerpts do not establish absence of corrections, expressions of concern, or later retractions.
- Sections 3.3 onward mainly describe this project’s implementation and results; they require source-code/result provenance rather than external citation entailment and are outside this report’s citation scope.

