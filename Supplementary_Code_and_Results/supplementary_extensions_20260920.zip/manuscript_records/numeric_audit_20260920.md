# 新增对照数值核查

academic-research-suite；范围：context、head_detail、matched_condition三个阶段，验证集10项配对比较。直接读取逐模型val_summary.json，重新计算42/43/44三个种子的差值、均值和样本SD；未调用原报告计算函数，未重新训练或推理。

|阶段|数据集|比较|均值±样本SD（pp）|负向种子|
|---|---|---|---:|---:|
|context_experiment|deeppcb|p4ctx_minus_phase|-2.676 ± 2.426|3/3|
|context_experiment|deeppcb|p4ctx_minus_se|-2.010 ± 0.417|3/3|
|context_experiment|neu|p4ctx_minus_phase|-0.429 ± 0.335|3/3|
|context_experiment|neu|p4ctx_minus_se|-0.683 ± 0.334|3/3|
|head_detail_experiment|deeppcb|phase_box - phase|-0.830 ± 1.559|2/3|
|head_detail_experiment|deeppcb|phase_head - phase|+0.326 ± 0.359|1/3|
|head_detail_experiment|neu|phase_box - phase|+0.060 ± 0.350|1/3|
|head_detail_experiment|neu|phase_head - phase|-0.170 ± 0.489|2/3|
|matched_condition|deeppcb|phase - phase_self|+3.061 ± 3.472|1/3|
|matched_condition|neu|phase - phase_self|+0.229 ± 0.341|1/3|

10项均与保存报告匹配（数值容差1e-10 pp），稿件三位小数幅值一致，人工检查比较方向和数据集顺序一致。p4ctx仍是历史标识，实际P5路由更正见方法核查说明。

范围限制：不覆盖全部论文数值、复用测试结果、引用真实性或图表坐标。不能把本次算术核验表述为独立重复实验。输入SHA256和未舍入差值见numeric_audit_20260920.json。
