# 正文内部论断—项目证据映射（2026-09-22）

范围：`manuscript.md` 第3.3–4.4节的主要可核查方法和结果论断。依据已归档原始结果、参数文件与前期核查记录，再核对正文读数和解释边界。此项是项目内部一致性检查，不是重新训练、独立复现、外部文献逐句核查或投稿就绪证明。

| 正文位置 | 论断与证据入口 | 本轮核查及边界 |
|---|---|---|
| 3.3–3.4 | P2→P3分支、条件卷积、四分量中心化和固定初始化：`source_snapshot_20260913/phase_modules.py`；参数数：`resource_profile.json` | 保存的源码确实先压缩、`pixel_unshuffle`、以P3产生条件系数，再对中心化四分量调制并回加原均值。原模型2,591,010、无条件2,597,058、条件2,601,218参数，差4,160；相对原模型差10,208。局部代数不证明整个网络保均值或检测增益。四个历史NEU运行的原始训练时完整源码未保存，见`review_methodology.md`。 |
| 3.5–3.6 | 训练设置与选择：24个主实验`args.yaml`、`confirmation_plan.json`、`review_methodology.md` | 抽查DeepPCB及NEU条件分支原始`args.yaml`，均为120轮、320输入、batch16、AdamW、lr0=0.001、lrf=0.01、weight_decay=0.0005、warmup_epochs=3、hsv_v=0.2、translate=0.1、scale=0.5、fliplr=0.5、close_mosaic=5。此前方法核查比较过全部24项可变键及验证fitness与CSV最大值；本轮不把该核查扩展为重新复现训练。NEU先前测试接触和四个历史运行在正文中保留。 |
| 3.7及4.1–4.2 | 主实验测试均值、样本SD与同种子差值：`confirmation_results.json` 的`aggregates`与`paired`，以及各`records` | 直接读取保存的汇总重新核对正文所有八项mAP50–95均值/SD和两数据集条件减无条件的三个逐种子差值、均值/样本SD；三位小数均吻合。NEU差值为+1.807、−0.166、−0.788，均值+0.284±1.355百分点；DeepPCB为+6.668、+3.555、−0.291，均值+3.311±3.486。负向种子不能省略，三种子描述不能称显著性或群体稳定性。 |
| 3.7及4.3 | DeepPCB来源分层：`confirmation_results.json` 的`test_source_seen`及`test_source_unseen`记录、`test_analysis_plan.json` | 四模型两组均值和条件减无条件的逐种子差值、均值/SD均与正文三位小数相符。已见来源组不等于经验证的实体电路板身份；分层AP不能按样本量线性合并成总体AP。 |
| 3.8及4.4 | 参数、GFLOPs、峰值分配：`resource_profile.json`；五轮前向计时：`../publication/supplement_latency.json` | 正文四模型参数、GFLOPs、MiB及四个延迟中位数与保存值按三位小数吻合。五轮计时范围交叠；约0.097 ms仅为同一测量方案下两个中位数的差，不是置信区间、端到端吞吐或跨设备常数。后续候选阶段另有计时漂移，不应由本项推断统一速度优势。 |
| 3.9 | 第二阶段设计与39个训练项：`../stage2/plan.json`、`../stage2/results.json`、`stage2_complete_tables.md` | 正文明确为后验扩展，39项由24机制、9分辨率、6初始化构成；复用测试不是独立确认。参数容量对照同时改变输入和变换；初始化与训练种子未全因子交叉。这两点不能被解释为单因素因果识别。 |

结果：以上抽查未发现需改动正文/PDF的数值或方法性矛盾。现有引文核查只覆盖第1、2及3.1–3.2节的外部论断；本文件不补称全篇引用已验证。作者身份、基金、利益冲突、AI披露与目标期刊格式仍需作者确认。

## 第4.5–6节续核

| 正文位置 | 证据入口 | 核查结果与解释边界 |
|---|---|---|
| 4.5机制验证 | `../stage2/results.json`、`stage2_complete_tables.md`、`../stage2/机制实验结果.md` | 容量与去中心化对照的验证均值/SD、复用测试均值/SD及负向种子说明均与保存的逐种子表吻合。容量对照改变输入和变换，不能解释为仅改变语义条件。 |
| 4.5分辨率、初始化 | `stage2_complete_tables.md`、`stage2_table_provenance.json`、`../stage2/results.json` | 640输入的条件减无条件验证−0.044±1.066、复用测试+0.424±0.228，以及640减320交互验证−2.254±2.222、复用测试−2.887±3.282均有逐种子表；替代初始化的−2.381±3.896、−0.300±0.441、+4.290±2.763及对应复用测试读数亦一致。测试均为已接触测试集的复用，初始化与训练种子耦合，不能推断独立或总体方差。 |
| 4.5自条件 | `../self_condition/结论.md`、`../matched_condition/结论.md`、`../matched_condition/historical_comparison.json` | P3减池化P2的两数据集验证/复用测试均值及负向种子与原报告一致；同环境12次运行与历史保存AP精度完全相同，故不是新增六个独立种子，也不证明权重逐位一致。 |
| 4.6失败候选 | `../frontier/阶段结论.md`、`../alignment/结论.md`、`../multiscale_experiment/结论.md`、`../budget_experiment/实验结果.md`、`../microshift/结论.md`、`numeric_audit_20260920.md`、`negative_numeric_audit_20260920.md` | 正文保留旋转、对齐、多尺度、预算的联合门槛失败与负向结果；既有10项和30项原始输入算术核查覆盖相应验证读数，未重复运行。微平移终点是预测匹配F1，不能混同AP。历史phase对照及不稳定计时的限制已写出。 |
| 4.6深上下文及检测头 | `../context_experiment/结论.md`、`../head_detail_experiment/结论.md`、`method_consistency_audit_20260920.md` | 保存源码与CPU前向已证明历史`phase_p4ctx`实际取P5/32；正文保留原标识但改称deep-context。检测头改动并非严格位置单因素消融；两数据集结果和失败门槛均保留。 |
| 4.6困难组及讨论 | `../subgroups/结论.md`、`../subgroups/summary.json`、`../publication/training_geometry.json` | 困难组验证召回差值DeepPCB+0.288±2.017、NEU−2.867±1.643，联合门槛失败。训练框按320输入的COCO小框比例DeepPCB为97.63%、NEU为0.72%，支持正文“几乎全部/极少”的描述，但框面积不证明纹理信息损失。困难组召回不是AP，复用测试描述不能推翻验证门槛。 |
| 5–6讨论与结论 | `confirmation_results.json`及以上阶段报告 | 结论保留NEU弱增益、三种子方向不一致、DeepPCB较大但有负向种子、原始与后验实验界限；没有把局部代数、来源分层或候选失败推成普遍检测性能结论。延迟仅指前向计时。 |

续核未发现需改动正文/PDF的实质性矛盾。此结论仅限保存证据与稿件内部的一致性；没有重新计算每一项原始预测、复现训练、证明所有外部文献的语义支撑或验证作者声明。
