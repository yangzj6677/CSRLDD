# Extension evidence archive

Use alongside the original supplementary_code_data.zip, which covers the main study.
This archive contains subsequent exploratory plans, metric summaries, training histories,
current support code, and available frozen snapshots. It excludes images, annotations,
weights, full prediction arrays, and full console logs. All omitted originals remain local.
It is not a self-contained runnable environment or a claim of independent replication.
Do not launch queues merely to inspect this archive.

Current_source is a packaging-time copy; plan hashes and stage snapshots govern training
provenance. Source hashes are recorded before path portability transformations. Differences
between original and export hashes are documented in the manifest. Do not substitute
portable plan bytes for the original frozen plan hash. See execution notes for environment
changes and recovery. Known test reuse and failed candidates remain disclosed.

PDFs are distributed separately. Author declarations and final release rights still need
author confirmation; this local archive assigns no new software or dataset license.
